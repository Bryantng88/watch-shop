import { NextResponse } from "next/server";
import { getTechnicalAssessmentPanelWithCatalogs } from "@/app/(admin)/admin/services/_server/technical.assessment.panel.service";

type RouteContext = {
    params: Promise<{ id: string }>;
};

export async function GET(_req: Request, context: RouteContext) {
    try {
        const { id } = await context.params;
        const serviceRequestId = String(id || "").trim();

        if (!serviceRequestId) {
            return NextResponse.json({ error: "Missing id" }, { status: 400 });
        }

        const data = await getTechnicalAssessmentPanelWithCatalogs(serviceRequestId);

        return NextResponse.json({
            ok: true,
            data,
        });
    } catch (error: any) {
        console.error(error);
        return NextResponse.json(
            { error: error?.message ?? "Load technical panel failed" },
            { status: 500 }
        );
    }
}