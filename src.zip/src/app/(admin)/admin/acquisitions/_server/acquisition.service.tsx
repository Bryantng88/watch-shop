"use server";

import { prisma, DB } from "@/server/db/client";
import * as dto from "./acquisition.dto";
import { buildAcqWhere, buildAcqOrderBy, DEFAULT_PAGE_SIZE } from "./filters";
import * as repoAcq from "./acquisition.repo";
//mport { CreateAcqWithItemInput } from "./acquisition.dto";
import { AcquisitionType, ProductType } from "@prisma/client";
import * as repoProd from "../../products/_server/product.repo";
import * as repoVendor from "../../vendors/_server/vendor.repo";
import { convertOffsetToTimes } from "framer-motion";
import { Prisma } from "@prisma/client";
import { createInvoiceFromAcquisition } from "../../invoices/_servers/invoices.repo";
import { ItemInput } from "./acquisition.dto";

type AcqViewKey = "all" | "draft" | "posted" | "canceled";

const firstValue = (v: unknown) => (Array.isArray(v) ? v[0] : v);

function asString(v: unknown) {
    const raw = firstValue(v);
    if (raw == null || raw === "") return undefined;
    return String(raw);
}

function asNumber(v: unknown, fallback: number) {
    const raw = firstValue(v);
    const n = Number(raw);
    return Number.isFinite(n) && n > 0 ? n : fallback;
}

function normalizeSort(v: unknown) {
    const raw = String(firstValue(v) ?? "updatedDesc");
    if (
        raw === "updatedDesc" ||
        raw === "updatedAsc" ||
        raw === "createdDesc" ||
        raw === "createdAsc" ||
        raw === "acquiredDesc" ||
        raw === "acquiredAsc"
    ) {
        return raw;
    }
    return "updatedDesc";
}

function normalizeView(v: unknown): AcqViewKey {
    const raw = String(firstValue(v) ?? "all").toLowerCase();
    if (raw === "draft" || raw === "posted" || raw === "canceled") return raw;
    return "all";
}

function normalizeType(v: unknown) {
    const raw = String(firstValue(v) ?? "").toUpperCase();
    if (
        raw === "PURCHASE" ||
        raw === "CONSIGNMENT" ||
        raw === "TRADE_IN" ||
        raw === "BUY_BACK"
    ) {
        return raw;
    }
    return undefined;
}

function normalizeStatus(v: unknown) {
    const raw = String(firstValue(v) ?? "").toUpperCase();
    if (raw === "DRAFT" || raw === "POSTED" || raw === "CANCELED") return raw;
    return undefined;
}

function statusFromView(view: AcqViewKey) {
    switch (view) {
        case "draft":
            return "DRAFT";
        case "posted":
            return "POSTED";
        case "canceled":
            return "CANCELED";
        default:
            return undefined;
    }
}

// List cho admin table
export async function getAdminAcquisitionList(raw: Record<string, unknown>) {
    const page = Math.max(1, asNumber(raw.page, 1));
    const pageSize = Math.max(1, Math.min(200, asNumber(raw.pageSize, DEFAULT_PAGE_SIZE)));

    const q = asString(raw.q)?.trim();
    const vendorId = asString(raw.vendorId);
    const type = normalizeType(raw.type);
    const sort = normalizeSort(raw.sort);
    const acquiredFrom = asString(raw.from ?? raw.acquiredFrom);
    const acquiredTo = asString(raw.to ?? raw.acquiredTo);
    const view = normalizeView(raw.view);
    const explicitStatus = normalizeStatus(raw.status);
    const activeStatus = explicitStatus ?? statusFromView(view);

    const baseFilters = {
        page,
        pageSize,
        q,
        vendorIds: vendorId ? [vendorId] : undefined,
        customerIds: undefined,
        type: type ? [type] : undefined,
        status: undefined,
        acquiredFrom,
        acquiredTo,
        hasInvoice: undefined,
        sort,
    } as any;

    const listFilters = {
        ...baseFilters,
        status: activeStatus ? [activeStatus] : undefined,
    } as any;

    const whereBase = buildAcqWhere(baseFilters);
    const whereList = buildAcqWhere(listFilters);

    const [{ rows, total }, all, draft, posted, canceled] = await Promise.all([
        repoAcq.getAcqList(
            whereList,
            buildAcqOrderBy(sort as any),
            (page - 1) * pageSize,
            pageSize
        ),
        prisma.acquisition.count({ where: whereBase }),
        prisma.acquisition.count({
            where: buildAcqWhere({ ...baseFilters, status: ["DRAFT"] } as any),
        }),
        prisma.acquisition.count({
            where: buildAcqWhere({ ...baseFilters, status: ["POSTED"] } as any),
        }),
        prisma.acquisition.count({
            where: buildAcqWhere({ ...baseFilters, status: ["CANCELED"] } as any),
        }),
    ]);

    const items = rows.map((a) => ({
        id: a.id,
        refNo: a.refNo,
        notes: a.notes,
        type: a.type,
        status: a.accquisitionStt,
        vendorName: a.vendor?.name ?? null,
        itemCount: a._count.acquisitionItem,
        hasInvoice: a._count.invoice > 0,
        createdAt: a.createdAt,
        cost: a.cost,
        updatedAt: a.updatedAt,
        currency: a.currency ?? "VND",
    }));

    return {
        items,
        total,
        page,
        pageSize,
        counts: {
            all,
            draft,
            posted,
            canceled,
        },
    };
}

// Chi tiết
export async function getAcquisitionDetail(id: string) {
    const acq = await repoAcq.getAcqtById(id);
    if (!acq) throw new Error("Không tìm thấy phiếu nhập");
    return acq;
}

// Tạo mới (Draft)

// Tạo phiếu nhập mới (DRAFT) và thêm item đầu tiên
export async function createAcquisitionWithItem(input: dto.CreateAcquisitionInput) {
    return await prisma.$transaction(async (tx) => {
        let vendorId = input.vendorId;

        if (!vendorId && input.quickVendorName) {
            const newVendor = await tx.vendor.create({
                data: { name: input.quickVendorName },
            });
            vendorId = newVendor.id;
        }

        if (!vendorId) {
            throw new Error("Thiếu vendor");
        }

        const acq = await repoAcq.createDraft(tx, {
            vendorId,
            currency: input.currency,
            type: input.type,
            createdAt: input.createdAt ? new Date(input.createdAt) : undefined,
            notes: input.notes,
        });

        let total = 0;

        for (const it of input.items) {
            await repoAcq.createAcqItem(tx, acq.id, it);
            total += (it.quantity ?? 1) * (it.unitCost ?? 0);
        }

        await repoAcq.updateAcquisitionCost(tx, acq.id, total);
        return { id: acq.id };
    });
}
function parseStrapSpecFromDescription(description?: string | null) {
    if (!description) return null;
    try {
        const parsed = JSON.parse(description);
        if (!parsed || typeof parsed !== "object") return null;
        return parsed as {
            material?: string;
            lugWidthMM?: number;
            buckleWidthMM?: number;
            color?: string;
            quickRelease?: boolean;
            sellPrice?: number;
        };
    } catch {
        return null;
    }
}
// Chuyển phiếu sang POSTED
export async function postAcquisition(acqId: string, vendorName: string) {
    return prisma.$transaction(async (tx) => {
        const acq = await repoAcq.getAcqtById(acqId, tx);
        if (!acq) throw new Error("Không tìm thấy phiếu nhập");

        let vendorId = acq.vendorId ?? null;

        if (!vendorId && vendorName) {
            const vendor = await tx.vendor.findFirst({
                where: { name: vendorName },
                select: { id: true },
            });
            vendorId = vendor?.id ?? null;
        }

        if (!vendorId) {
            throw new Error("Không tìm thấy vendor để post phiếu");
        }

        const items = acq.acquisitionItem ?? [];

        for (const item of items) {
            if (item.productId) {
                if (!item.variantId) {
                    const resolvedVariantId = await repoAcq.resolveVariantIdForProduct(
                        tx,
                        item.productId
                    );

                    if (resolvedVariantId) {
                        await tx.acquisitionItem.update({
                            where: { id: item.id },
                            data: { variantId: resolvedVariantId },
                        });
                    }
                }
                continue;
            }

            if (item.productType === "WATCH_STRAP") {
                const strapSpec = parseStrapSpecFromDescription(item.description);

                const created = await tx.product.create({
                    data: {
                        title: item.productTitle,
                        status: "DRAFT" as any,
                        type: "WATCH_STRAP" as any,
                        vendor: { connect: { id: vendorId } },
                        variants: {
                            create: [
                                {
                                    stockQty: Number(item.quantity ?? 1),
                                    price: new Prisma.Decimal(
                                        strapSpec?.sellPrice != null
                                            ? Number(strapSpec.sellPrice)
                                            : Number(item.unitCost ?? 0)
                                    ),
                                    availabilityStatus: "HIDDEN" as any,
                                    strapSpec: {
                                        create: {
                                            lugWidthMM: Number(strapSpec?.lugWidthMM ?? 20),
                                            buckleWidthMM: Number(strapSpec?.buckleWidthMM ?? 18),
                                            color: strapSpec?.color ?? "Black",
                                            material: (strapSpec?.material as any) ?? "LEATHER",
                                            quickRelease:
                                                strapSpec?.quickRelease == null
                                                    ? true
                                                    : Boolean(strapSpec.quickRelease),
                                        },
                                    },
                                },
                            ],
                        },
                    },
                    select: {
                        id: true,
                        variants: {
                            select: { id: true },
                            take: 1,
                        },
                    },
                });

                await tx.acquisitionItem.update({
                    where: { id: item.id },
                    data: {
                        productId: created.id,
                        variantId: created.variants?.[0]?.id ?? null,
                    },
                });

                continue;
            }

            const created = await tx.product.create({
                data: {
                    title: item.productTitle,
                    status: "DRAFT" as any,
                    type: (item.productType ?? "WATCH") as any,
                    vendor: { connect: { id: vendorId } },
                    variants: {
                        create: [
                            {
                                stockQty: Number(item.quantity ?? 1),
                                availabilityStatus: "HIDDEN" as any,
                            },
                        ],
                    },
                },
                select: {
                    id: true,
                    variants: {
                        select: { id: true },
                        take: 1,
                    },
                },
            });

            await tx.acquisitionItem.update({
                where: { id: item.id },
                data: {
                    productId: created.id,
                    variantId: created.variants?.[0]?.id ?? null,
                },
            });
        }

        await createInvoiceFromAcquisition(tx, acqId);
        return repoAcq.changeDraftToPost(tx, acqId);
    });
}
export async function postMultipleAcquisitions(items: { id: string; vendor: string }[]) {
    const results = [];
    for (const acq of items) {
        try {
            await postAcquisition(acq.id, acq.vendor);
            results.push({ id: acq.id, ok: true });
        } catch (e) {
            results.push({ id: acq.id, ok: false, error: (e as Error).message });
        }
    }
    return results;
}

// Hủy phiếu
export async function cancelAcquisition(id: string) {
    const acq = await repoAcq.acqGetById(id);
    if (!acq) throw new Error("Không tìm thấy phiếu nhập");
    if (acq.acquisitionStt === "POSTED") throw new Error("Không thể huỷ phiếu đã đăng");
    return repoAcq.acqUpdate(id, { acquisitionStt: "CANCELED" });
}

//Update acquisition item
export async function updateAcqItem(tx: DB, it: any) {
    return tx.acquisitionItem.update({
        where: { id: it.id },
        data: {
            productTitle: it.title,
            quantity: it.quantity,
            unitCost: it.unitPrice,
        },
    });
}

export async function updateAcquisitionItems(tx: DB, acqId: string, items: ItemInput[]) {
    const existing = await repoAcq.findAcqItems(tx, acqId);

    const existingIds = new Set(existing.map((i) => i.id));
    const receivedIds = new Set(items.map((i) => i.id));

    const toDelete = [...existingIds].filter((id) => !receivedIds.has(id));

    if (toDelete.length > 0) {
        await repoAcq.deleteAcqItems(tx, toDelete);
    }

    for (const it of items) {
        console.log("in ra id : " + it.id, it.unitPrice);
        if (it.id.startsWith("tmp-")) {
            await repoAcq.createAcqItem(tx, acqId, it);
        } else {
            await updateAcqItem(tx, it);
        }
    }

    const all = await repoAcq.findAcqItems(tx, acqId);

    const total = all.reduce((s, r) => s + Number(r.quantity) * Number(r.unitCost ?? 0), 0);

    await repoAcq.updateAcqTotal(tx, acqId, total);

    return { success: true, total };
}