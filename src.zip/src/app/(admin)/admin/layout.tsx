import AdminTopbar from "./_client/AdminTopBar";
import AdminSidebar from "./_client/AdmidSideBar";
import { getCurrentUser } from "@/server/auth/getCurrentUser";
import { redirect } from "next/navigation";
import { AppToastProvider } from "@/components/feedback/AppToastProvider";
import { getSideMenuNotificationCounts } from "./_server/sidebar-notifications";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
    const user = await getCurrentUser();

    if (!user) {
        redirect("/login");
    }

    const permissions = Array.from(new Set(user.permissions ?? []));
    const canEnterAdmin = user.roles.includes("ADMIN") || permissions.length > 0;

    if (!canEnterAdmin) {
        redirect("/403");
    }

    const notificationCounts = await getSideMenuNotificationCounts();

    return (
        <div className="flex h-screen overflow-hidden">
            <div className="hidden lg:block w-52 shrink-0 bg-[#11191f]">
                <AdminSidebar
                    user={{ permissions }}
                    notifications={notificationCounts}
                />
            </div>

            <div className="lg:hidden">
                <AdminSidebar
                    user={{ permissions }}
                    notifications={notificationCounts}
                    variant="mobile"
                />
            </div>

            <div className="flex-1 min-w-0 flex flex-col">
                <AdminTopbar title="Admin" user={{ name: user.name, roles: user.roles }} />

                <AppToastProvider>
                    <main className="flex-1 min-h-0 overflow-y-auto p-6">
                        {children}
                    </main>
                </AppToastProvider>
            </div>
        </div>
    );
}