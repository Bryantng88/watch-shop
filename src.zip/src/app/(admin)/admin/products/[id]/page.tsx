import Link from "next/link";
import { notFound } from "next/navigation";

import ProductDetailClient from "./_client/ProductDetailClient";

import { prisma } from "@/server/db/client";
import { requirePermission } from "@/server/auth/requirePermission";
import { PERMISSIONS } from "@/constants/permissions";

export const metadata = {
    title: "Chi tiết sản phẩm · Admin",
};

function serialize<T>(value: T): T {
    return JSON.parse(
        JSON.stringify(value, (_key, v) => {
            if (v instanceof Date) return v.toISOString();
            if (typeof v === "object" && v?._isDecimal) return Number(v);
            return v;
        })
    );
}

async function getProductDetailPageData(id: string) {
    const product = await prisma.product.findUnique({
        where: { id },
        include: {
            brand: {
                select: { id: true, name: true },
            },
            vendor: {
                select: { id: true, name: true },
            },
            ProductCategory: {
                select: { id: true, name: true, scope: true },
            },
            watchSpec: {
                include: {
                    complication: {
                        select: { id: true, name: true },
                    },
                },
            },
            image: {
                orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
                select: {
                    id: true,
                    fileKey: true,
                    alt: true,
                    role: true,
                    sortOrder: true,
                    createdAt: true,
                },
            },
            variants: {
                orderBy: [{ updatedAt: "desc" }, { createdAt: "asc" }],
                select: {
                    id: true,
                    sku: true,
                    name: true,
                    price: true,
                    salePrice: true,
                    costPrice: true,
                    stockQty: true,
                    availabilityStatus: true,
                    createdAt: true,
                    updatedAt: true,
                    strapSpec: {
                        select: {
                            lugWidthMM: true,
                            buckleWidthMM: true,
                            color: true,
                            material: true,
                            quickRelease: true,
                        },
                    },
                    acquisitionItem: {
                        orderBy: [{ createdAt: "desc" }],
                        take: 1,
                        select: {
                            id: true,
                            unitCost: true,
                            createdAt: true,
                            acquisition: {
                                select: {
                                    id: true,
                                    refNo: true,
                                    acquiredAt: true,
                                },
                            },
                        },
                    },
                },
            },
        },
    });

    if (!product) return null;

    const [serviceHistory, acquisitionHistory, orderHistory] = await Promise.all([
        prisma.serviceRequest.findMany({
            where: { productId: id },
            orderBy: [{ updatedAt: "desc" }, { createdAt: "desc" }],
            select: {
                id: true,
                refNo: true,
                status: true,
                scope: true,
                notes: true,
                createdAt: true,
                updatedAt: true,
                vendorNameSnap: true,
                serviceCatalog: {
                    select: {
                        id: true,
                        code: true,
                        name: true,
                    },
                },
                orderItem: {
                    select: {
                        id: true,
                        order: {
                            select: {
                                id: true,
                                refNo: true,
                            },
                        },
                    },
                },
                maintenance: {
                    orderBy: [{ createdAt: "desc" }],
                    take: 3,
                    select: {
                        id: true,
                        eventType: true,
                        vendorName: true,
                        notes: true,
                        totalCost: true,
                        currency: true,
                        servicedAt: true,
                        createdAt: true,
                    },
                },
                _count: {
                    select: {
                        maintenance: true,
                    },
                },
            },
        }),

        prisma.acquisitionItem.findMany({
            where: { productId: id },
            orderBy: [
                { acquisition: { acquiredAt: "desc" } },
                { createdAt: "desc" },
            ],
            select: {
                id: true,
                quantity: true,
                unitCost: true,
                currency: true,
                status: true,
                productTitle: true,
                createdAt: true,
                returnedAt: true,
                acquisition: {
                    select: {
                        id: true,
                        refNo: true,
                        type: true,
                        accquisitionStt: true,
                        acquiredAt: true,
                        vendor: {
                            select: { id: true, name: true },
                        },
                        customer: {
                            select: { id: true, name: true },
                        },
                    },
                },
            },
        }),

        prisma.orderItem.findMany({
            where: { productId: id },
            orderBy: [
                { order: { createdAt: "desc" } },
                { createdAt: "desc" },
            ],
            select: {
                id: true,
                title: true,
                quantity: true,
                unitPriceAgreed: true,
                subtotal: true,
                kind: true,
                productType: true,
                createdAt: true,
                order: {
                    select: {
                        id: true,
                        refNo: true,
                        status: true,
                        paymentStatus: true,
                        source: true,
                        customerName: true,
                        createdAt: true,
                    },
                },
            },
        }),
    ]);

    return serialize({
        product,
        serviceHistory,
        acquisitionHistory,
        orderHistory,
    });
}

export default async function ProductDetailPage({
    params,
}: {
    params: Promise<{ id: string }>;
}) {
    await requirePermission(PERMISSIONS.PRODUCT_VIEW);

    const { id } = await params;
    const data = await getProductDetailPageData(id);

    if (!data) notFound();

    return (
        <div className="mx-auto w-full max-w-[1500px] px-4 pt-6 lg:px-6">
            <ProductDetailClient data={data} />
        </div>
    );
}