"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import {
    ChevronDown,
    ChevronRight,
    ExternalLink,
    FileText,
    History,
    Pencil,
    Save,
    Settings2,
    ShoppingCart,
    Sparkles,
    Wrench,
} from "lucide-react";

import DotLabel from "@/app/(admin)/admin/__components/DotLabel";
import { useNotify } from "@/components/feedback/AppToastProvider";

type ProductDetailData = {
    product: {
        id: string;
        slug?: string | null;
        title: string;
        primaryImageUrl?: string | null;
        type: string;
        tag?: string | null;
        status: string;
        contentStatus?: string | null;
        postContent?: string | null;
        aiPromptUsed?: string | null;
        aiGeneratedAt?: string | null;
        seoDescription?: string | null;
        createdAt: string;
        updatedAt: string;
        brand?: { id: string; name: string } | null;
        vendor?: { id: string; name: string } | null;
        ProductCategory?: { id: string; name: string; scope?: string | null } | null;
        image: Array<{
            id: string;
            fileKey: string;
            alt?: string | null;
            role?: string | null;
            sortOrder?: number | null;
            createdAt?: string | null;
        }>;
        variants: Array<{
            id: string;
            sku?: string | null;
            name?: string | null;
            price?: number | null;
            salePrice?: number | null;
            costPrice?: number | null;
            stockQty?: number | null;
            availabilityStatus?: string | null;
            createdAt?: string | null;
            updatedAt?: string | null;
            strapSpec?: {
                lugWidthMM?: number | null;
                buckleWidthMM?: number | null;
                color?: string | null;
                material?: string | null;
                quickRelease?: boolean | null;
            } | null;
            acquisitionItem?: Array<{
                id: string;
                unitCost?: number | null;
                createdAt?: string | null;
                acquisition?: {
                    id: string;
                    refNo?: string | null;
                    acquiredAt?: string | null;
                } | null;
            }>;
        }>;
        watchSpec?: {
            ref?: string | null;
            model?: string | null;
            year?: string | null;
            caseType?: string | null;
            gender?: string | null;
            movement?: string | null;
            caliber?: string | null;
            caseMaterial?: string | null;
            goldKarat?: number | null;
            goldColor?: string | null;
            length?: number | null;
            width?: number | null;
            thickness?: number | null;
            strap?: string | null;
            glass?: string | null;
            boxIncluded?: boolean | null;
            bookletIncluded?: boolean | null;
            cardIncluded?: boolean | null;
            hasStrap?: boolean | null;
            hasClasp?: boolean | null;
            isServiced?: boolean | null;
            isSpa?: boolean | null;
            complication?: Array<{ id: string; name: string }>;
        } | null;
    };
    serviceHistory: Array<{
        id: string;
        refNo?: string | null;
        status?: string | null;
        scope?: string | null;
        notes?: string | null;
        createdAt?: string | null;
        updatedAt?: string | null;
        vendorNameSnap?: string | null;
        serviceCatalog?: {
            id: string;
            code?: string | null;
            name: string;
        } | null;
        orderItem?: {
            id: string;
            order?: {
                id: string;
                refNo?: string | null;
            } | null;
        } | null;
        maintenance?: Array<{
            id: string;
            eventType?: string | null;
            vendorName?: string | null;
            notes?: string | null;
            totalCost?: number | null;
            currency?: string | null;
            servicedAt?: string | null;
            createdAt?: string | null;
        }>;
        _count?: {
            maintenance?: number;
        };
    }>;
    acquisitionHistory: Array<{
        id: string;
        quantity: number;
        unitCost?: number | null;
        currency?: string | null;
        status?: string | null;
        productTitle?: string | null;
        createdAt?: string | null;
        returnedAt?: string | null;
        acquisition?: {
            id: string;
            refNo?: string | null;
            type?: string | null;
            accquisitionStt?: string | null;
            acquiredAt?: string | null;
            vendor?: { id: string; name: string } | null;
            customer?: { id: string; name: string } | null;
        } | null;
    }>;
    orderHistory: Array<{
        id: string;
        title: string;
        quantity: number;
        unitPriceAgreed?: number | null;
        subtotal?: number | null;
        kind?: string | null;
        productType?: string | null;
        createdAt?: string | null;
        order?: {
            id: string;
            refNo?: string | null;
            status?: string | null;
            paymentStatus?: string | null;
            source?: string | null;
            customerName?: string | null;
            createdAt?: string | null;
        } | null;
    }>;
};

function cls(...xs: Array<string | false | null | undefined>) {
    return xs.filter(Boolean).join(" ");
}

function fmtDate(value?: string | null) {
    if (!value) return "-";
    const d = new Date(value);
    if (!Number.isFinite(d.getTime())) return "-";
    return d.toLocaleString("vi-VN", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
    });
}

function fmtMoney(value?: number | null, currency = "VND") {
    if (value == null) return "-";
    return `${new Intl.NumberFormat("vi-VN").format(Number(value))} ${currency}`;
}

function boolText(value?: boolean | null) {
    if (value == null) return "-";
    return value ? "Có" : "Không";
}

function signedImageUrl(key?: string | null) {
    if (!key) return "";
    return `/api/media/sign?key=${encodeURIComponent(key)}`;
}

function toneForProductStatus(status?: string | null): "green" | "blue" | "gray" | "orange" {
    const s = String(status ?? "").toUpperCase();
    if (["AVAILABLE", "ACTIVE", "READY"].includes(s)) return "green";
    if (["HOLD", "IN_SERVICE", "RESERVED", "CONSIGNED_FROM", "CONSIGNED_TO"].includes(s)) return "orange";
    if (["SOLD", "ARCHIVED", "HIDDEN"].includes(s)) return "gray";
    return "blue";
}

function toneForServiceStatus(status?: string | null): "green" | "blue" | "gray" | "orange" {
    const s = String(status ?? "").toUpperCase();
    if (["COMPLETED", "DELIVERED"].includes(s)) return "green";
    if (["CANCELED", "CANCELLED"].includes(s)) return "gray";
    if (["WAIT_APPROVAL", "DIAGNOSING"].includes(s)) return "orange";
    return "blue";
}

function toneForContentStatus(status?: string | null): "green" | "blue" | "gray" | "orange" {
    const s = String(status ?? "").toUpperCase();
    if (["PUBLISHED"].includes(s)) return "green";
    if (["DRAFT"].includes(s)) return "orange";
    return "gray";
}

function CollapsibleSection({
    title,
    desc,
    icon,
    defaultOpen = true,
    right,
    children,
}: {
    title: string;
    desc?: string;
    icon: React.ReactNode;
    defaultOpen?: boolean;
    right?: React.ReactNode;
    children: React.ReactNode;
}) {
    const [open, setOpen] = useState(defaultOpen);

    return (
        <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
            <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                className="flex w-full items-center justify-between gap-4 border-b border-slate-200 px-5 py-4 text-left"
            >
                <div className="flex min-w-0 items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-slate-100 text-slate-700">
                        {icon}
                    </div>
                    <div className="min-w-0">
                        <h2 className="truncate text-base font-semibold text-slate-900">{title}</h2>
                        {desc ? <p className="mt-1 text-sm text-slate-500">{desc}</p> : null}
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    {right}
                    <span className="text-slate-400">
                        {open ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                    </span>
                </div>
            </button>

            {open ? <div className="p-5">{children}</div> : null}
        </section>
    );
}

function Field({
    label,
    value,
    mono = false,
}: {
    label: string;
    value: React.ReactNode;
    mono?: boolean;
}) {
    return (
        <div className="space-y-1.5">
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</div>
            <div className={cls("text-sm text-slate-900", mono && "font-mono")}>{value}</div>
        </div>
    );
}

function TinyStat({
    label,
    value,
    hint,
}: {
    label: string;
    value: React.ReactNode;
    hint?: React.ReactNode;
}) {
    return (
        <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</div>
            <div className="mt-1 text-base font-semibold text-slate-900">{value}</div>
            {hint ? <div className="mt-1 text-xs text-slate-500">{hint}</div> : null}
        </div>
    );
}

export default function ProductDetailClient({ data }: { data: ProductDetailData }) {
    const notify = useNotify();

    const gallery = useMemo(() => {
        const keys = new Set<string>();
        const out: string[] = [];

        if (data.product.primaryImageUrl) {
            keys.add(data.product.primaryImageUrl);
            out.push(data.product.primaryImageUrl);
        }

        for (const img of data.product.image ?? []) {
            if (!img.fileKey || keys.has(img.fileKey)) continue;
            keys.add(img.fileKey);
            out.push(img.fileKey);
        }

        return out;
    }, [data.product.image, data.product.primaryImageUrl]);

    const [activeImage, setActiveImage] = useState<string>(gallery[0] ?? "");
    const [content, setContent] = useState(data.product.postContent ?? "");
    const [promptNote, setPromptNote] = useState(data.product.aiPromptUsed ?? "");
    const [saving, setSaving] = useState(false);
    const [contentStatus, setContentStatus] = useState<string | null>(data.product.contentStatus ?? null);
    const [aiGeneratedAt, setAiGeneratedAt] = useState<string | null>(data.product.aiGeneratedAt ?? null);

    const latestVariant = data.product.variants?.[0] ?? null;
    const latestAcquisition = data.acquisitionHistory?.[0] ?? null;
    const latestOrder = data.orderHistory?.[0] ?? null;
    const openService = data.serviceHistory.find((x) =>
        !["COMPLETED", "DELIVERED", "CANCELED", "CANCELLED"].includes(String(x.status ?? "").toUpperCase())
    );

    const serviceCostTotal = useMemo(() => {
        return (data.serviceHistory ?? []).reduce((sum, sr) => {
            const local = (sr.maintenance ?? []).reduce((s, log) => s + Number(log.totalCost ?? 0), 0);
            return sum + local;
        }, 0);
    }, [data.serviceHistory]);

    async function handleSaveContent() {
        try {
            setSaving(true);

            const res = await fetch(`/api/admin/products/${data.product.id}/content`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    postContent: content,
                    aiPromptUsed: promptNote,
                }),
            });

            const json = await res.json().catch(() => null);

            if (!res.ok) {
                throw new Error(json?.error || "Không lưu được nội dung sản phẩm");
            }

            setContentStatus(json?.product?.contentStatus ?? "DRAFT");
            setAiGeneratedAt(json?.product?.aiGeneratedAt ?? new Date().toISOString());

            notify.success({
                title: "Đã lưu",
                message: "Nội dung bài đăng của sản phẩm đã được cập nhật.",
            });
        } catch (error: any) {
            notify.error({
                title: "Lưu thất bại",
                message: error?.message || "Không lưu được nội dung sản phẩm",
            });
        } finally {
            setSaving(false);
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0 space-y-3">
                    <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
                        <Link href="/admin/products" className="hover:text-slate-700">
                            Sản phẩm
                        </Link>
                        <ChevronRight className="h-4 w-4" />
                        <span className="truncate">{data.product.title}</span>
                    </div>

                    <div className="space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                            <h1 className="text-2xl font-semibold tracking-tight text-slate-900">
                                {data.product.title}
                            </h1>

                            <DotLabel label={data.product.status || "-"} tone={toneForProductStatus(data.product.status)} />
                            <DotLabel label={contentStatus || "-"} tone={toneForContentStatus(contentStatus)} />
                            {openService ? (
                                <DotLabel label={`Service ${openService.status || ""}`} tone={toneForServiceStatus(openService.status)} />
                            ) : null}
                        </div>

                        <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-slate-500">
                            <span>ID: <span className="font-mono text-slate-700">{data.product.id}</span></span>
                            <span>Brand: <span className="font-medium text-slate-700">{data.product.brand?.name || "-"}</span></span>
                            <span>Category: <span className="font-medium text-slate-700">{data.product.ProductCategory?.name || "-"}</span></span>
                            <span>Updated: <span className="font-medium text-slate-700">{fmtDate(data.product.updatedAt)}</span></span>
                        </div>
                    </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    <Link
                        href="/admin/products"
                        className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                    >
                        ← Quay lại
                    </Link>

                    <Link
                        href={`/admin/products/${data.product.id}/edit`}
                        className="inline-flex items-center gap-2 rounded-2xl border border-slate-900 bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
                    >
                        <Pencil className="h-4 w-4" />
                        Chỉnh sửa sản phẩm
                    </Link>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
                <div className="space-y-6 xl:col-span-8">
                    <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
                        <div className="grid grid-cols-1 gap-0 lg:grid-cols-[1.1fr_0.9fr]">
                            <div className="border-b border-slate-200 p-5 lg:border-b-0 lg:border-r">
                                <div className="overflow-hidden rounded-3xl border border-slate-200 bg-slate-50">
                                    {activeImage ? (
                                        <img
                                            src={signedImageUrl(activeImage)}
                                            alt={data.product.title}
                                            className="h-[420px] w-full object-cover"
                                        />
                                    ) : (
                                        <div className="flex h-[420px] items-center justify-center text-sm text-slate-400">
                                            Chưa có ảnh
                                        </div>
                                    )}
                                </div>

                                {gallery.length > 1 ? (
                                    <div className="mt-4 flex flex-wrap gap-3">
                                        {gallery.map((imgKey) => {
                                            const active = imgKey === activeImage;
                                            return (
                                                <button
                                                    key={imgKey}
                                                    type="button"
                                                    onClick={() => setActiveImage(imgKey)}
                                                    className={cls(
                                                        "overflow-hidden rounded-2xl border p-1 transition",
                                                        active
                                                            ? "border-slate-900 ring-2 ring-slate-200"
                                                            : "border-slate-200 hover:border-slate-300"
                                                    )}
                                                >
                                                    <img
                                                        src={signedImageUrl(imgKey)}
                                                        alt="thumb"
                                                        className="h-16 w-16 rounded-xl object-cover"
                                                    />
                                                </button>
                                            );
                                        })}
                                    </div>
                                ) : null}
                            </div>

                            <div className="p-5">
                                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                                    <TinyStat
                                        label="Giá bán"
                                        value={fmtMoney(latestVariant?.salePrice ?? latestVariant?.price, "VND")}
                                        hint={latestVariant?.salePrice ? `Giá gốc ${fmtMoney(latestVariant?.price, "VND")}` : undefined}
                                    />
                                    <TinyStat
                                        label="Giá vốn"
                                        value={fmtMoney(latestVariant?.costPrice, "VND")}
                                        hint={latestVariant?.acquisitionItem?.[0]?.acquisition?.refNo ? `Theo ${latestVariant.acquisitionItem[0].acquisition.refNo}` : undefined}
                                    />
                                    <TinyStat
                                        label="SKU"
                                        value={latestVariant?.sku || "-"}
                                        hint={latestVariant?.availabilityStatus || "-"}
                                    />
                                    <TinyStat
                                        label="Tồn kho"
                                        value={latestVariant?.stockQty ?? 0}
                                        hint={data.product.type}
                                    />
                                </div>

                                <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
                                    <Field label="Brand" value={data.product.brand?.name || "-"} />
                                    <Field label="Vendor" value={data.product.vendor?.name || "-"} />
                                    <Field label="Danh mục" value={data.product.ProductCategory?.name || "-"} />
                                    <Field label="Tag" value={data.product.tag || "-"} />
                                    <Field label="Slug" value={data.product.slug || "-"} mono />
                                    <Field label="Tạo lúc" value={fmtDate(data.product.createdAt)} />
                                </div>

                                {data.product.seoDescription ? (
                                    <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                                        <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
                                            SEO description
                                        </div>
                                        <div className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-700">
                                            {data.product.seoDescription}
                                        </div>
                                    </div>
                                ) : null}
                            </div>
                        </div>
                    </section>

                    <CollapsibleSection
                        title="Thông số & cấu hình"
                        desc="Hiển thị snapshot hiện tại của sản phẩm để kiểm tra nhanh trước khi post / bán."
                        icon={<Settings2 className="h-5 w-5" />}
                        defaultOpen
                    >
                        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                            <Field label="Ref" value={data.product.watchSpec?.ref || "-"} />
                            <Field label="Model" value={data.product.watchSpec?.model || "-"} />
                            <Field label="Năm" value={data.product.watchSpec?.year || "-"} />
                            <Field label="Giới tính" value={data.product.watchSpec?.gender || "-"} />
                            <Field label="Kiểu vỏ" value={data.product.watchSpec?.caseType || "-"} />
                            <Field label="Chất liệu vỏ" value={data.product.watchSpec?.caseMaterial || "-"} />
                            <Field label="Bộ máy" value={data.product.watchSpec?.movement || "-"} />
                            <Field label="Caliber" value={data.product.watchSpec?.caliber || "-"} />
                            <Field label="Mặt kính" value={data.product.watchSpec?.glass || "-"} />
                            <Field label="Loại dây" value={data.product.watchSpec?.strap || "-"} />
                            <Field label="Dài" value={data.product.watchSpec?.length ?? "-"} />
                            <Field label="Ngang" value={data.product.watchSpec?.width ?? "-"} />
                            <Field label="Dày" value={data.product.watchSpec?.thickness ?? "-"} />
                            <Field label="Gold karat" value={data.product.watchSpec?.goldKarat ?? "-"} />
                            <Field label="Gold color" value={data.product.watchSpec?.goldColor || "-"} />
                            <Field label="Có dây" value={boolText(data.product.watchSpec?.hasStrap)} />
                            <Field label="Có khóa" value={boolText(data.product.watchSpec?.hasClasp)} />
                            <Field label="Đã service" value={boolText(data.product.watchSpec?.isServiced)} />
                            <Field label="Đã spa" value={boolText(data.product.watchSpec?.isSpa)} />
                            <Field label="Có box" value={boolText(data.product.watchSpec?.boxIncluded)} />
                            <Field label="Có booklet" value={boolText(data.product.watchSpec?.bookletIncluded)} />
                            <Field label="Có card" value={boolText(data.product.watchSpec?.cardIncluded)} />
                        </div>

                        {data.product.watchSpec?.complication?.length ? (
                            <div className="mt-5">
                                <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
                                    Complication
                                </div>
                                <div className="mt-2 flex flex-wrap gap-2">
                                    {data.product.watchSpec.complication.map((item) => (
                                        <span
                                            key={item.id}
                                            className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-slate-700"
                                        >
                                            {item.name}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        ) : null}

                        {latestVariant?.strapSpec ? (
                            <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                                <div className="text-sm font-semibold text-slate-900">Thông tin dây gắn với variant</div>
                                <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                                    <Field label="Material" value={latestVariant.strapSpec.material || "-"} />
                                    <Field label="Color" value={latestVariant.strapSpec.color || "-"} />
                                    <Field label="Lug width" value={latestVariant.strapSpec.lugWidthMM ?? "-"} />
                                    <Field label="Buckle width" value={latestVariant.strapSpec.buckleWidthMM ?? "-"} />
                                    <Field label="Quick release" value={boolText(latestVariant.strapSpec.quickRelease)} />
                                </div>
                            </div>
                        ) : null}
                    </CollapsibleSection>

                    <CollapsibleSection
                        title="Nội dung bài đăng"
                        desc="Tạm thời bạn có thể dán nội dung lấy từ ChatGPT/OpenAI vào đây rồi lưu lại."
                        icon={<Sparkles className="h-5 w-5" />}
                        defaultOpen
                        right={
                            <div className="hidden text-xs text-slate-500 sm:block">
                                {aiGeneratedAt ? `Lưu lần cuối: ${fmtDate(aiGeneratedAt)}` : "Chưa có nội dung"}
                            </div>
                        }
                    >
                        <div className="space-y-4">
                            <div className="grid grid-cols-1 gap-4">
                                <div>
                                    <label className="mb-2 block text-sm font-medium text-slate-700">
                                        Nội dung
                                    </label>
                                    <textarea
                                        value={content}
                                        onChange={(e) => setContent(e.target.value)}
                                        rows={14}
                                        placeholder="Dán nội dung bài đăng tại đây..."
                                        className="w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-slate-900"
                                    />
                                </div>

                                <div>
                                    <label className="mb-2 block text-sm font-medium text-slate-700">
                                        Prompt / ghi chú gen nội dung
                                    </label>
                                    <textarea
                                        value={promptNote}
                                        onChange={(e) => setPromptNote(e.target.value)}
                                        rows={4}
                                        placeholder="Ví dụ: viết theo tone vintage, nhấn mạnh case tank, mặt linen, hàng NOS..."
                                        className="w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-slate-900"
                                    />
                                </div>
                            </div>

                            <div className="flex flex-wrap items-center justify-between gap-3">
                                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                                    <span>Content status: <b className="text-slate-700">{contentStatus || "-"}</b></span>
                                    <span>AI generated at: <b className="text-slate-700">{aiGeneratedAt ? fmtDate(aiGeneratedAt) : "-"}</b></span>
                                </div>

                                <button
                                    type="button"
                                    onClick={handleSaveContent}
                                    disabled={saving}
                                    className="inline-flex items-center gap-2 rounded-2xl border border-slate-900 bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
                                >
                                    <Save className="h-4 w-4" />
                                    {saving ? "Đang lưu..." : "Lưu nội dung"}
                                </button>
                            </div>

                            {content?.trim() ? (
                                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                                    <div className="mb-2 text-xs font-medium uppercase tracking-wide text-slate-500">
                                        Preview nhanh
                                    </div>
                                    <div className="whitespace-pre-wrap text-sm leading-6 text-slate-700">
                                        {content}
                                    </div>
                                </div>
                            ) : null}
                        </div>
                    </CollapsibleSection>

                    <CollapsibleSection
                        title="Lịch sử service"
                        desc="Theo dõi toàn bộ service request và các maintenance log gần nhất của sản phẩm."
                        icon={<Wrench className="h-5 w-5" />}
                        defaultOpen
                        right={
                            <div className="text-xs text-slate-500">
                                {data.serviceHistory.length} service • Tổng log cost: {fmtMoney(serviceCostTotal, "VND")}
                            </div>
                        }
                    >
                        {!data.serviceHistory.length ? (
                            <div className="rounded-2xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500">
                                Chưa có lịch sử service cho sản phẩm này.
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {data.serviceHistory.map((item) => (
                                    <div
                                        key={item.id}
                                        className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                                    >
                                        <div className="flex flex-wrap items-start justify-between gap-3">
                                            <div className="space-y-2">
                                                <div className="flex flex-wrap items-center gap-2">
                                                    <div className="text-base font-semibold text-slate-900">
                                                        {item.serviceCatalog?.name || item.refNo || item.id}
                                                    </div>
                                                    <DotLabel
                                                        label={item.status || "-"}
                                                        tone={toneForServiceStatus(item.status)}
                                                    />
                                                </div>

                                                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                                                    <span>RefNo: <b className="text-slate-700">{item.refNo || "-"}</b></span>
                                                    <span>Scope: <b className="text-slate-700">{item.scope || "-"}</b></span>
                                                    <span>Vendor: <b className="text-slate-700">{item.vendorNameSnap || "-"}</b></span>
                                                    <span>Order: <b className="text-slate-700">{item.orderItem?.order?.refNo || "-"}</b></span>
                                                    <span>Cập nhật: <b className="text-slate-700">{fmtDate(item.updatedAt || item.createdAt)}</b></span>
                                                </div>

                                                {item.notes ? (
                                                    <div className="whitespace-pre-wrap text-sm leading-6 text-slate-700">
                                                        {item.notes}
                                                    </div>
                                                ) : null}
                                            </div>

                                            <Link
                                                href={`/admin/services/${item.id}`}
                                                className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
                                            >
                                                Mở service
                                                <ExternalLink className="h-3.5 w-3.5" />
                                            </Link>
                                        </div>

                                        {item.maintenance?.length ? (
                                            <div className="mt-4 space-y-2 border-t border-slate-200 pt-4">
                                                <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
                                                    Maintenance log gần nhất ({item._count?.maintenance ?? item.maintenance.length})
                                                </div>

                                                {item.maintenance.map((log) => (
                                                    <div
                                                        key={log.id}
                                                        className="rounded-xl border border-slate-200 bg-white p-3"
                                                    >
                                                        <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                                                            <span>Event: <b className="text-slate-700">{log.eventType || "NOTE"}</b></span>
                                                            <span>Vendor: <b className="text-slate-700">{log.vendorName || "-"}</b></span>
                                                            <span>Ngày: <b className="text-slate-700">{fmtDate(log.servicedAt || log.createdAt)}</b></span>
                                                            <span>Cost: <b className="text-slate-700">{fmtMoney(log.totalCost, log.currency || "VND")}</b></span>
                                                        </div>

                                                        {log.notes ? (
                                                            <div className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-700">
                                                                {log.notes}
                                                            </div>
                                                        ) : null}
                                                    </div>
                                                ))}
                                            </div>
                                        ) : null}
                                    </div>
                                ))}
                            </div>
                        )}
                    </CollapsibleSection>

                    <CollapsibleSection
                        title="Lịch sử mua bán"
                        desc="Gộp cả chiều nhập hàng và chiều bán ra để nhìn được hành trình đầy đủ của sản phẩm."
                        icon={<History className="h-5 w-5" />}
                        defaultOpen
                        right={
                            <div className="text-xs text-slate-500">
                                {data.acquisitionHistory.length} nhập • {data.orderHistory.length} bán
                            </div>
                        }
                    >
                        <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
                            <div className="space-y-3">
                                <div className="flex items-center gap-2">
                                    <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-slate-100 text-slate-700">
                                        <FileText className="h-4 w-4" />
                                    </div>
                                    <h3 className="text-sm font-semibold text-slate-900">Chiều nhập / acquisition</h3>
                                </div>

                                {!data.acquisitionHistory.length ? (
                                    <div className="rounded-2xl border border-dashed border-slate-300 p-6 text-sm text-slate-500">
                                        Chưa có lịch sử nhập hàng cho sản phẩm này.
                                    </div>
                                ) : (
                                    data.acquisitionHistory.map((item) => (
                                        <div
                                            key={item.id}
                                            className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                                        >
                                            <div className="flex flex-wrap items-start justify-between gap-3">
                                                <div className="space-y-2">
                                                    <div className="flex flex-wrap items-center gap-2">
                                                        <div className="text-sm font-semibold text-slate-900">
                                                            {item.acquisition?.refNo || item.acquisition?.id || item.id}
                                                        </div>
                                                        <DotLabel
                                                            label={item.acquisition?.accquisitionStt || item.status || "-"}
                                                            tone="blue"
                                                        />
                                                    </div>

                                                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                                                        <span>Loại: <b className="text-slate-700">{item.acquisition?.type || "-"}</b></span>
                                                        <span>Ngày nhập: <b className="text-slate-700">{fmtDate(item.acquisition?.acquiredAt || item.createdAt)}</b></span>
                                                        <span>Vendor: <b className="text-slate-700">{item.acquisition?.vendor?.name || "-"}</b></span>
                                                        <span>Customer: <b className="text-slate-700">{item.acquisition?.customer?.name || "-"}</b></span>
                                                        <span>SL: <b className="text-slate-700">{item.quantity}</b></span>
                                                        <span>Giá vốn: <b className="text-slate-700">{fmtMoney(item.unitCost, item.currency || "VND")}</b></span>
                                                    </div>
                                                </div>

                                                {item.acquisition?.id ? (
                                                    <Link
                                                        href={`/admin/acquisitions/${item.acquisition.id}/edit`}
                                                        className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
                                                    >
                                                        Mở phiếu nhập
                                                        <ExternalLink className="h-3.5 w-3.5" />
                                                    </Link>
                                                ) : null}
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>

                            <div className="space-y-3">
                                <div className="flex items-center gap-2">
                                    <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-slate-100 text-slate-700">
                                        <ShoppingCart className="h-4 w-4" />
                                    </div>
                                    <h3 className="text-sm font-semibold text-slate-900">Chiều bán / order</h3>
                                </div>

                                {!data.orderHistory.length ? (
                                    <div className="rounded-2xl border border-dashed border-slate-300 p-6 text-sm text-slate-500">
                                        Chưa có lịch sử bán ra cho sản phẩm này.
                                    </div>
                                ) : (
                                    data.orderHistory.map((item) => (
                                        <div
                                            key={item.id}
                                            className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
                                        >
                                            <div className="flex flex-wrap items-start justify-between gap-3">
                                                <div className="space-y-2">
                                                    <div className="flex flex-wrap items-center gap-2">
                                                        <div className="text-sm font-semibold text-slate-900">
                                                            {item.order?.refNo || item.order?.id || item.id}
                                                        </div>
                                                        <DotLabel
                                                            label={item.order?.status || "-"}
                                                            tone={toneForProductStatus(item.order?.status)}
                                                        />
                                                    </div>

                                                    <div className="text-sm text-slate-800">{item.title}</div>

                                                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                                                        <span>Ngày bán: <b className="text-slate-700">{fmtDate(item.order?.createdAt || item.createdAt)}</b></span>
                                                        <span>Khách: <b className="text-slate-700">{item.order?.customerName || "-"}</b></span>
                                                        <span>Nguồn: <b className="text-slate-700">{item.order?.source || "-"}</b></span>
                                                        <span>Payment: <b className="text-slate-700">{item.order?.paymentStatus || "-"}</b></span>
                                                        <span>SL: <b className="text-slate-700">{item.quantity}</b></span>
                                                        <span>Đơn giá: <b className="text-slate-700">{fmtMoney(item.unitPriceAgreed, "VND")}</b></span>
                                                        <span>Subtotal: <b className="text-slate-700">{fmtMoney(item.subtotal, "VND")}</b></span>
                                                    </div>
                                                </div>

                                                {item.order?.id ? (
                                                    <Link
                                                        href={`/admin/orders/${item.order.id}`}
                                                        className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
                                                    >
                                                        Mở đơn hàng
                                                        <ExternalLink className="h-3.5 w-3.5" />
                                                    </Link>
                                                ) : null}
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </CollapsibleSection>
                </div>

                <div className="space-y-6 xl:col-span-4">
                    <div className="space-y-6 xl:sticky xl:top-4">
                        <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                            <div className="mb-4 text-sm font-semibold text-slate-900">Tóm tắt nhanh</div>

                            <div className="grid grid-cols-2 gap-3">
                                <TinyStat label="Service mở" value={openService ? "Có" : "Không"} />
                                <TinyStat label="Số lần service" value={data.serviceHistory.length} />
                                <TinyStat label="Số lần nhập" value={data.acquisitionHistory.length} />
                                <TinyStat label="Số lần bán" value={data.orderHistory.length} />
                            </div>

                            <div className="mt-5 space-y-4 border-t border-slate-200 pt-4">
                                <Field label="Trạng thái sản phẩm" value={data.product.status || "-"} />
                                <Field label="Content status" value={contentStatus || "-"} />
                                <Field label="Lần gen nội dung" value={aiGeneratedAt ? fmtDate(aiGeneratedAt) : "-"} />
                                <Field label="Loại sản phẩm" value={data.product.type || "-"} />
                            </div>
                        </section>

                        <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                            <div className="mb-4 text-sm font-semibold text-slate-900">Variant hiện tại</div>

                            {!latestVariant ? (
                                <div className="text-sm text-slate-500">Chưa có variant.</div>
                            ) : (
                                <div className="space-y-4">
                                    <Field label="Variant ID" value={latestVariant.id} mono />
                                    <Field label="SKU" value={latestVariant.sku || "-"} mono />
                                    <Field label="Availability" value={latestVariant.availabilityStatus || "-"} />
                                    <Field label="Giá bán" value={fmtMoney(latestVariant.salePrice ?? latestVariant.price, "VND")} />
                                    <Field label="Giá vốn" value={fmtMoney(latestVariant.costPrice, "VND")} />
                                    <Field label="Tồn kho" value={latestVariant.stockQty ?? 0} />
                                    <Field label="Cập nhật" value={fmtDate(latestVariant.updatedAt || latestVariant.createdAt)} />
                                </div>
                            )}
                        </section>

                        <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                            <div className="mb-4 text-sm font-semibold text-slate-900">Mốc gần nhất</div>

                            <div className="space-y-4">
                                <Field
                                    label="Nhập gần nhất"
                                    value={
                                        latestAcquisition
                                            ? `${latestAcquisition.acquisition?.refNo || "-"} • ${fmtDate(
                                                latestAcquisition.acquisition?.acquiredAt || latestAcquisition.createdAt
                                            )}`
                                            : "-"
                                    }
                                />
                                <Field
                                    label="Bán gần nhất"
                                    value={
                                        latestOrder
                                            ? `${latestOrder.order?.refNo || "-"} • ${fmtDate(
                                                latestOrder.order?.createdAt || latestOrder.createdAt
                                            )}`
                                            : "-"
                                    }
                                />
                                <Field
                                    label="Service gần nhất"
                                    value={
                                        data.serviceHistory[0]
                                            ? `${data.serviceHistory[0].refNo || data.serviceHistory[0].id} • ${fmtDate(
                                                data.serviceHistory[0].updatedAt || data.serviceHistory[0].createdAt
                                            )}`
                                            : "-"
                                    }
                                />
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    );
}