import { prisma } from "@/server/db/client";
import { ProductStatus, ProductType, DiscountType, ServiceRequestStatus } from "@prisma/client";
import * as prodRepo from "./product.repo";
import { z } from "zod";
import { computeEffectivePrice } from "../helpers/price";
import { MIN_IMAGES, REQUIRED_PRODUCT_FIELDS, REQUIRED_VARIANT_FIELDS, getRequiredWatchSpecFields, hasValue } from "./rules";

const firstValue = (v: unknown) => (Array.isArray(v) ? v[0] : v);

const asDate = (v: unknown) => {
    const raw = firstValue(v);
    if (raw == null || raw === "") return undefined;
    const d = new Date(String(raw));
    return Number.isNaN(d.getTime()) ? undefined : d;
};

const asNumber = (v: unknown) => {
    const raw = firstValue(v);
    if (raw == null || raw === "") return undefined;
    const n = Number(raw);
    return Number.isFinite(n) ? n : undefined;
};

const asString = (v: unknown) => {
    const raw = firstValue(v);
    if (raw == null || raw === "") return undefined;
    return String(raw);
};

const arrayify = (v: unknown): string[] => {
    if (Array.isArray(v)) return v.filter(Boolean).map(String);
    if (v == null || v === "") return [];
    return [String(v)];
};

function normalizeView(v: unknown) {
    const raw = String(firstValue(v) ?? "all").toLowerCase();
    if (
        raw === "all" ||
        raw === "draft" ||
        raw === "posted" ||
        raw === "in_service" ||
        raw === "hold" ||
        raw === "sold"
    ) {
        return raw;
    }
    return "all";
}

function normalizeCatalog(v: unknown): "product" | "strap" {
    const raw = String(firstValue(v) ?? "product").toLowerCase();
    return raw === "strap" ? "strap" : "product";
}

const AdminListQuerySchema = z.object({
    page: z.coerce.number().min(1).default(1),
    pageSize: z.coerce.number().min(1).max(200).default(20),
    q: z.string().optional(),
    sort: z
        .enum(["updatedDesc", "updatedAsc", "createdDesc", "createdAsc", "titleAsc", "titleDesc"])
        .optional(),
    type: z.array(z.string()).optional(),
    brandIds: z.array(z.string()).optional(),
    categoryIds: z.array(z.string()).optional(),
    hasImages: z.enum(["yes", "no"]).optional(),
    updatedFrom: z.date().optional(),
    updatedTo: z.date().optional(),
});

const OPEN_SERVICE_REQUEST_STATUSES = [
    ServiceRequestStatus.DRAFT,
    ServiceRequestStatus.DIAGNOSING,
    ServiceRequestStatus.WAIT_APPROVAL,
    ServiceRequestStatus.IN_PROGRESS,
] as const;

const STRAP_ATTACHMENT_PREFIX = '__STRAP_LINK__:';

function parseStoredStrapAttachment(raw: unknown) {
    if (typeof raw !== 'string' || !raw.startsWith(STRAP_ATTACHMENT_PREFIX)) return null;

    try {
        const parsed = JSON.parse(raw.slice(STRAP_ATTACHMENT_PREFIX.length));
        return parsed && typeof parsed === 'object' ? parsed : null;
    } catch {
        return null;
    }
}

export async function createProductDraft(title: string) {
    return prisma.$transaction(async (tx) => {
        return prodRepo.createProductDraft(
            tx,
            title,
            ProductType.WATCH,
            1,
            null as any
        );
    });
}

export async function detail(id: string) {
    return prisma.product.findUnique({
        where: { id },
    });
}


export async function getEditProductFormData(id: string) {
    const product = await prodRepo.getAdminEditProductDetail(prisma, id);
    if (!product) {
        throw new Error('Không tìm thấy sản phẩm.');
    }

    const attachedStrap = parseStoredStrapAttachment(product?.variants?.[0]?.name ?? null);
    const attachedStrapVariantId = String((attachedStrap as any)?.variantId ?? '');

    const [categoryOptions, strapInventory] = await Promise.all([
        prodRepo.listActiveProductCategories(prisma),
        prodRepo.listAvailableStrapInventory(prisma, attachedStrapVariantId),
    ]);

    const strapInventoryOptions = strapInventory
        .flatMap((item: any) =>
            (item.variants ?? []).map((variant: any) => ({
                productId: item.id,
                variantId: variant.id,
                title: item.title,
                vendorName: item.vendor?.name ?? null,
                stockQty: Number(variant.stockQty ?? 0),
                availabilityStatus: variant.availabilityStatus ?? null,
                price: variant.price != null ? Number(variant.price) : null,
                costPrice: variant.costPrice != null ? Number(variant.costPrice) : null,
                strapSpec: variant.strapSpec
                    ? {
                        lugWidthMM:
                            variant.strapSpec.lugWidthMM != null
                                ? Number(variant.strapSpec.lugWidthMM)
                                : null,
                        buckleWidthMM:
                            variant.strapSpec.buckleWidthMM != null
                                ? Number(variant.strapSpec.buckleWidthMM)
                                : null,
                        color: variant.strapSpec.color ?? null,
                        material: variant.strapSpec.material ?? null,
                        quickRelease: variant.strapSpec.quickRelease ?? null,
                    }
                    : null,
            }))
        )
        .filter(
            (item: any, index: number, arr: any[]) =>
                arr.findIndex((x: any) => x.variantId === item.variantId) === index
        );

    return {
        product,
        categoryOptions,
        strapInventoryOptions,
    };
}

export async function getAdminProductList(
    raw: Record<string, unknown>,
    opts?: { canViewCost?: boolean }
) {
    const parsedResult = AdminListQuerySchema.safeParse({
        page: asNumber(raw.page) ?? 1,
        pageSize: asNumber(raw.pageSize) ?? 20,
        q: asString(raw.q),
        sort: asString(raw.sort),
        type: arrayify(raw.type),
        brandIds: arrayify(raw.brandIds ?? raw.brandId),
        categoryIds: arrayify(raw.categoryIds ?? raw.categoryId),
        hasImages: asString(raw.hasImages),
        updatedFrom: asDate(raw.updatedFrom),
        updatedTo: asDate(raw.updatedTo),
    });

    const parsed = parsedResult.success
        ? parsedResult.data
        : {
            page: 1,
            pageSize: 20,
            q: undefined,
            sort: undefined,
            type: undefined,
            brandIds: undefined,
            categoryIds: undefined,
            hasImages: undefined,
            updatedFrom: undefined,
            updatedTo: undefined,
        };

    const catalog = normalizeCatalog(raw.catalog);
    const view = normalizeView(raw.view);

    const result = await prodRepo.listAdminProducts(prisma, {
        q: parsed.q,
        sort: parsed.sort as any,
        page: parsed.page,
        pageSize: parsed.pageSize,
        view: view as any,
        type: parsed.type?.[0],
        brandId: parsed.brandIds?.[0],
        categoryId: parsed.categoryIds?.[0],
        hasImages: parsed.hasImages,
        catalog,
        includeCost: opts?.canViewCost !== false,
    } as any);

    const items = (result.items ?? []).map((item: any) => {
        const missingProductFields = REQUIRED_PRODUCT_FIELDS
            .filter((field) => !hasValue(item?.[field.key]))
            .map((field) => field.label);

        const missingVariantFields = REQUIRED_VARIANT_FIELDS
            .filter((field) => !hasValue(item?.variantSnapshot?.[field.key]))
            .map((field) => field.label);

        const watchSpec = item?.watchSpecSnapshot ?? {};
        const missingWatchSpecFields = item?.type === ProductType.WATCH_STRAP
            ? []
            : getRequiredWatchSpecFields(watchSpec)
                .filter((field) => !hasValue(watchSpec?.[field.key]))
                .map((field) => field.label);

        const isVariantInfoComplete = missingVariantFields.length === 0;
        const isWatchSpecComplete = missingWatchSpecFields.length === 0;
        const isInfoComplete =
            missingProductFields.length === 0 &&
            isVariantInfoComplete &&
            isWatchSpecComplete;

        const {
            slug: _slug,
            categoryId: _categoryId,
            brandId: _brandId,
            vendorId: _vendorId,
            variantSnapshot: _variantSnapshot,
            watchSpecSnapshot: _watchSpecSnapshot,
            ...rest
        } = item ?? {};

        return {
            ...rest,
            isVariantInfoComplete,
            isWatchSpecComplete,
            isInfoComplete,
            missingProductFields,
            missingVariantFields,
            missingWatchSpecFields,
            hasOpenService: !!item?.openServiceStatus,
            openServiceStatus: item?.openServiceStatus ?? null,
        };
    });

    return {
        ...result,
        items,
        page: parsed.page,
        pageSize: parsed.pageSize,
    };
}

export async function updateProduct(
    id: string,
    patch: {
        title?: string;
        categoryId?: string | null;
        minPrice?: number | null;
        listPrice?: number | null;
        discountType?: DiscountType | null;
        discountValue?: number | null;
        salePrice?: number | null;
        saleStartsAt?: Date | null;
        saleEndsAt?: Date | null;
        purchasePrice?: number | null;
        primaryImageUrl?: string | null;
        status?: string;
        priceVisibility?: "SHOW" | "HIDE";
        availabilityStatus?: "ACTIVE" | "HIDDEN";
    }
) {
    return prisma.$transaction(async (tx) => {
        const current = await prodRepo.getLatestVariantForAdmin(tx, id);
        if (!current) {
            throw new Error("Không tìm thấy product.");
        }

        const variant = current.variants?.[0] ?? null;
        const currentList = variant?.listPrice != null ? Number(variant.listPrice) : Number(variant?.price ?? 0);

        const nextListPrice =
            patch.listPrice !== undefined
                ? patch.listPrice
                : patch.minPrice !== undefined
                    ? patch.minPrice
                    : currentList;

        const nextDiscountType =
            patch.discountType !== undefined ? patch.discountType : (variant?.discountType ?? null);
        const nextDiscountValue =
            patch.discountValue !== undefined
                ? patch.discountValue
                : variant?.discountValue != null
                    ? Number(variant.discountValue)
                    : null;
        const nextSalePrice =
            patch.salePrice !== undefined
                ? patch.salePrice
                : variant?.salePrice != null
                    ? Number(variant.salePrice)
                    : null;
        const nextSaleStartsAt =
            patch.saleStartsAt !== undefined ? patch.saleStartsAt : (variant?.saleStartsAt ?? null);
        const nextSaleEndsAt =
            patch.saleEndsAt !== undefined ? patch.saleEndsAt : (variant?.saleEndsAt ?? null);
        const nextCostPrice =
            patch.purchasePrice !== undefined
                ? patch.purchasePrice
                : variant?.costPrice != null
                    ? Number(variant.costPrice)
                    : null;

        const shouldTouchPricing =
            patch.minPrice !== undefined ||
            patch.listPrice !== undefined ||
            patch.discountType !== undefined ||
            patch.discountValue !== undefined ||
            patch.salePrice !== undefined ||
            patch.saleStartsAt !== undefined ||
            patch.saleEndsAt !== undefined ||
            patch.purchasePrice !== undefined ||
            patch.availabilityStatus !== undefined;

        if (shouldTouchPricing) {
            const effectivePrice = computeEffectivePrice({
                listPrice: nextListPrice,
                discountType: nextDiscountType,
                discountValue: nextDiscountValue,
                salePrice: nextSalePrice,
                saleStartsAt: nextSaleStartsAt,
                saleEndsAt: nextSaleEndsAt,
                fallbackPrice: variant?.price,
            });

            await prodRepo.updatePrimaryVariantPricing(tx, id, {
                price: effectivePrice,
                listPrice: nextListPrice,
                discountType: nextDiscountType,
                discountValue: nextDiscountValue,
                salePrice: nextSalePrice,
                saleStartsAt: nextSaleStartsAt,
                saleEndsAt: nextSaleEndsAt,
                costPrice: nextCostPrice,
                ...(patch.availabilityStatus ? { availabilityStatus: patch.availabilityStatus as any } : {}),
            } as any);
        }

        const data: any = {};
        if (patch.title !== undefined) data.title = patch.title;
        if (patch.categoryId !== undefined) data.categoryId = patch.categoryId || null;
        if (patch.primaryImageUrl !== undefined) data.primaryImageUrl = patch.primaryImageUrl;
        if (patch.status !== undefined) data.status = patch.status;
        if (patch.priceVisibility !== undefined) data.priceVisibility = patch.priceVisibility;

        return prodRepo.updateProduct(tx, id, data);
    });
}

export async function remove(id: string) {
    return prisma.$transaction(async (tx) => {
        await prodRepo.deleteProduct(tx, id);
        return { success: true };
    });
}

export async function searchProductService(q: string) {
    return prisma.$transaction(async (tx) => {
        return prodRepo.searchProductsRepo(tx, q);
    });
}

export type BulkPostProductsResult = {
    count: number;
    postedIds: string[];
    failed: Array<{
        id: string;
        title?: string | null;
        reasons: string[];
    }>;
};

function toNumberPrice(v: unknown): number {
    if (v == null) return 0;
    if (typeof v === "number") return v;

    const anyV = v as any;
    if (typeof anyV?.toNumber === "function") return anyV.toNumber();

    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
}

function hasPrice(p: { minPrice: unknown }) {
    return toNumberPrice(p.minPrice) > 0;
}

function hasEnoughImages(p: { imageCount?: number; primaryImageUrl: string | null }) {
    if (typeof p.imageCount === "number") return p.imageCount >= MIN_IMAGES;
    return !!p.primaryImageUrl && p.primaryImageUrl.trim().length > 0;
}

function buildBulkPostMissingReasons(p: any) {
    const reasons: string[] = [];

    for (const field of REQUIRED_PRODUCT_FIELDS) {
        if (!hasValue(p?.[field.key])) {
            reasons.push(`MISSING_${field.key.toUpperCase()}`);
        }
    }

    if (!hasEnoughImages(p)) {
        reasons.push(`MISSING_IMAGES_MIN_${MIN_IMAGES}`);
    }

    if (!hasPrice(p)) {
        reasons.push('MISSING_PRICE');
    }

    if (p?.type !== ProductType.WATCH_STRAP) {
        const watchSpec = p?.watchSpecSnapshot ?? {};
        for (const field of getRequiredWatchSpecFields(watchSpec)) {
            if (!hasValue(watchSpec?.[field.key])) {
                reasons.push(`MISSING_WATCHSPEC_${field.key.toUpperCase()}`);
            }
        }
    }

    return reasons;
}

export async function bulkPostProducts(productIds: string[]): Promise<BulkPostProductsResult> {
    const ids = Array.from(new Set((productIds ?? []).filter(Boolean)));

    if (!ids.length) {
        return { count: 0, postedIds: [], failed: [] };
    }

    return prisma.$transaction(async (tx) => {
        const [rows, openServices] = await Promise.all([
            prodRepo.getProductsForBulkPost(tx, ids),
            prodRepo.getOpenServiceProducts(tx, ids),
        ]);

        const openServiceMap = new Map<string, string>();
        for (const row of openServices) {
            if (!row?.productId || openServiceMap.has(row.productId)) continue;
            openServiceMap.set(row.productId, String(row.status));
        }

        const found = new Set(rows.map((x) => x.id));
        const notFound = ids.filter((id) => !found.has(id));

        const failed: BulkPostProductsResult["failed"] = [];

        for (const id of notFound) {
            failed.push({ id, title: null, reasons: ["NOT_FOUND"] });
        }

        const eligibleIds: string[] = [];

        for (const p of rows as Array<any>) {
            const reasons: string[] = [];
            const openServiceStatus = openServiceMap.get(p.id);

            if (p.status !== ProductStatus.DRAFT) {
                reasons.push(`STATUS_NOT_ALLOWED:${p.status}`);
            }
            if (openServiceStatus) {
                reasons.push(`OPEN_SERVICE:${openServiceStatus}`);
            }
            reasons.push(...buildBulkPostMissingReasons(p));

            if (reasons.length) {
                failed.push({ id: p.id, title: p.title ?? null, reasons });
            } else {
                eligibleIds.push(p.id);
            }
        }

        if (eligibleIds.length) {
            await prodRepo.markPostedMany(tx, eligibleIds);
        }

        return {
            count: eligibleIds.length,
            postedIds: eligibleIds,
            failed,
        };
    });
}

export async function getProductServiceHistory(productId: string) {
    if (!productId) return [];
    return prodRepo.getProductServiceHistory(prisma, productId);
}