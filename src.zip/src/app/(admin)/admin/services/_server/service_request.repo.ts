import { prisma, DB, dbOrTx } from "@/server/db/client";
import { Prisma, PrismaClient } from "@prisma/client";
import { ServiceRequestStatus } from "@prisma/client";
type Tx = Prisma.TransactionClient | typeof prisma;
export type ServiceRequestListRow = {
  id: string;
  refNo: string | null;
  status: string;
  createdAt: Date;
  updatedAt: Date;
  scope: string;
  productTitle: string;
  // hiển thị "Dịch vụ"
  serviceCatalog: { id: string; code: string | null; name: string } | null;
  vendorName: string;
  maintenanceCount: number;
  // hiển thị "Order", "Scope", notes đồ khách mang tới...
  orderItem: {
    id: string;
    title: string;
    serviceScope: any | null; // ServiceScope enum
    customerItemNote: string | null;
    order: { id: string; refNo: string | null } | null;
  } | null;
};

export async function listServiceCatalogRepo(
  tx: DB,
  opts?: {
    isActive?: boolean;
  }
) {
  const db = dbOrTx(tx)
  return db.serviceCatalog.findMany({
    where: {
      ...(opts?.isActive !== undefined
        ? { isActive: opts.isActive }
        : {}),
    },
    orderBy: { name: "asc" },
    select: {
      id: true,
      code: true,
      name: true,
      description: true,
      detail: true,          // enum ServiceDetail
      defaultPrice: true,
      durationMin: true,
      isActive: true,
    },
  });
}



export function createServiceRequest(
  tx: DB,
  data: {
    orderItemId: string;
    title: string;
    quantity: number;
    unitPrice: number;
  }
) {
  const db = dbOrTx(tx)
  return db.serviceRequest.create({
    data: {
      orderItemId: data.orderItemId,
      //title: data.title,
      //quantity: data.quantity,
      //unitPrice: data.unitPrice,
      status: "DRAFT",
    },
  });
}


export async function createMany(tx: DB, data: Prisma.ServiceRequestCreateManyInput[]) {
  const db = dbOrTx(tx)
  return db.serviceRequest.createMany({ data });
}

export async function getServiceRequestList(
  where: Prisma.ServiceRequestWhereInput,
  orderBy: Prisma.ServiceRequestOrderByWithRelationInput,
  skip: number,
  take: number,
  tx: DB
) {
  const db = dbOrTx(tx);

  const [rows, total] = await Promise.all([
    db.serviceRequest.findMany({
      where,
      orderBy,
      skip,
      take,
      select: {
        id: true,
        refNo: true,
        status: true,
        createdAt: true,
        updatedAt: true,
        scope: true,
        vendorNameSnap: true,
        product: {
          select: {
            id: true,
            title: true,
          }
        },
        // ✅ Dịch vụ
        ServiceCatalog: {
          select: {
            id: true,
            code: true,
            name: true,
          },
        },
        _count: { select: { maintenance: true } }, // ✅
        // ✅ Link về Order + Scope
        orderItem: {
          select: {
            id: true,
            title: true,
            serviceScope: true,
            customerItemNote: true,
            order: {
              select: {
                id: true,
                refNo: true,
              },
            },
          },
        },
      },
    }),
    db.serviceRequest.count({ where }),
  ]);

  const mapped: ServiceRequestListRow[] = rows.map((r) => ({
    id: r.id,
    refNo: r.refNo ?? null,
    createdAt: r.createdAt,
    updatedAt: r.updatedAt,
    vendorName: r.vendorNameSnap,
    scope: r.scope,
    productTitle: r.product?.title,
    status: r.status,
    serviceCatalog: r.ServiceCatalog
      ? { id: r.ServiceCatalog.id, code: r.ServiceCatalog.code ?? null, name: r.ServiceCatalog.name }
      : null,
    maintenanceCount: r._count.maintenance,
    orderItem: r.orderItem
      ? {
        id: r.orderItem.id,
        title: r.orderItem.title,
        serviceScope: (r.orderItem as any).serviceScope ?? null,
        customerItemNote: (r.orderItem as any).customerItemNote ?? null,
        order: r.orderItem.order
          ? { id: r.orderItem.order.id, refNo: r.orderItem.order.refNo ?? null }
          : null,
      }
      : null,
  }));

  return { rows: mapped, total };
}



export async function getOptions(
  prisma: PrismaClient,
  opts?: { isActive?: boolean }
) {
  const where: Prisma.ServiceCatalogWhereInput =
    typeof opts?.isActive === "boolean" ? { isActive: opts.isActive } : {};

  const rows = await prisma.serviceCatalog.findMany({
    where,
    orderBy: [{ name: "asc" }],
    select: {
      id: true,
      code: true,
      name: true,
      defaultPrice: true,
    },
  });

  return rows;
}

export async function createOne(
  tx: DB,
  data: Prisma.ServiceRequestUncheckedCreateInput
) {
  const db = dbOrTx(tx);
  return db.serviceRequest.create({ data });
}

export async function findServiceCatalogLite(tx: DB) {
  const db = dbOrTx(tx);
  return db.serviceCatalog.findMany({
    where: { isActive: true },
    select: { id: true, code: true, name: true },
    orderBy: { updatedAt: "desc" },
  });
}

export async function findProductForService(tx: DB, productId: string) {
  const db = dbOrTx(tx);
  return db.product.findUnique({
    where: { id: productId },
    select: {
      id: true,
      title: true,
      brand: { select: { name: true } }, // nếu bạn có
      model: true, // nếu bạn có
      ref: true,   // nếu bạn có
      variants: {
        orderBy: [{ stockQty: "desc" }, { createdAt: "asc" }],
        select: { id: true },
        take: 1,
      },
    },
  });
}

export type VendorLite = { id: string; name: string };

export async function findVendorsLite(tx: DB) {
  const db = dbOrTx(tx);
  return db.vendor.findMany({
    //where: { isActive: true }, // nếu schema bạn có
    select: { id: true, name: true },
    orderBy: { updatedAt: "desc" },
  });
}

export async function bulkAssignVendor(
  tx: DB,
  input: {
    ids: string[];
    vendorId: string;
    vendorNameSnap: string;
    onlyFromDraft?: boolean; // default true
  }
): Promise<number> {   // ✅ QUAN TRỌNG: khai báo return type
  const db = dbOrTx(tx);

  const where: Prisma.ServiceRequestWhereInput = {
    id: { in: input.ids },
    ...(input.onlyFromDraft !== false ? { status: ServiceRequestStatus.DRAFT } : {}),
  };

  const updated = await db.serviceRequest.updateMany({
    where,
    data: {
      vendorId: input.vendorId,
      vendorNameSnap: input.vendorNameSnap,
      status: ServiceRequestStatus.IN_PROGRESS,
      updatedAt: new Date(),
    },
  });

  return updated.count; // ✅ number
}


export async function listAssignedAfterBulk(
  tx: DB,
  input: { ids: string[]; onlyFromDraft?: boolean }
) {
  const db = dbOrTx(tx);

  return db.serviceRequest.findMany({
    where: {
      id: { in: input.ids },
      ...(input.onlyFromDraft !== false ? { status: ServiceRequestStatus.IN_PROGRESS } : {}),
    },
    select: {
      id: true,
      productId: true,
      variantId: true,
    },
  });
}


export async function findByIdForMaintenance(tx: DB, id: string) {
  const db = dbOrTx(tx);
  return db.serviceRequest.findUnique({
    where: { id },
    select: {
      id: true,
      type: true,
      billable: true,

      productId: true,
      variantId: true,

      vendorId: true,
      vendorNameSnap: true,
    },
  });
}