import {
    PrismaClient,
    ServiceRequestStatus,
    TechnicalAssessmentStatus,
} from "@prisma/client";
import * as technicalRepo from "./technical.repo";

const prisma = new PrismaClient();

export type SaveTechnicalAssessmentPayload = technicalRepo.TechnicalAssessmentPayload;

export async function saveTechnicalAssessment(
    payload: SaveTechnicalAssessmentPayload,
    opts?: {
        evaluatedById?: string | null;
        evaluatedByNameSnap?: string | null;
    }
) {
    return prisma.$transaction(async (tx) => {
        const sr = await tx.serviceRequest.findUnique({
            where: { id: payload.serviceRequestId },
            select: {
                id: true,
                productId: true,
            },
        });

        if (!sr) {
            throw new Error("Không tìm thấy service request.");
        }

        if (sr.productId) {
            const product = await tx.product.findUnique({
                where: { id: sr.productId },
                select: {
                    id: true,
                    contentStatus: true,
                },
            });

            if (String(product?.contentStatus ?? "").toUpperCase() === "ARCHIVED") {
                throw new Error("Sản phẩm đã hủy/ẩn, không thể tiếp tục quy trình service.");
            }
        }

        const assessment = await technicalRepo.upsertTechnicalAssessment(tx, payload, {
            evaluatedById: opts?.evaluatedById ?? null,
            evaluatedByNameSnap: opts?.evaluatedByNameSnap ?? null,
        });

        const issueCount = await technicalRepo.replaceTechnicalIssues(
            tx,
            assessment.id,
            payload.serviceRequestId,
            payload
        );

        const nextAssessmentStatus =
            issueCount > 0
                ? TechnicalAssessmentStatus.IN_PROGRESS
                : TechnicalAssessmentStatus.COMPLETED;

        const nextServiceStatus =
            issueCount > 0
                ? ServiceRequestStatus.IN_PROGRESS
                : ServiceRequestStatus.COMPLETED;

        await tx.technicalAssessment.update({
            where: { id: assessment.id },
            data: {
                status: nextAssessmentStatus,
            },
        });

        await tx.serviceRequest.update({
            where: { id: payload.serviceRequestId },
            data: {
                status: nextServiceStatus,
            },
        });

        return {
            ok: true,
            assessmentId: assessment.id,
            issueCount,
            assessmentStatus: nextAssessmentStatus,
            serviceRequestStatus: nextServiceStatus,
        };
    });
}