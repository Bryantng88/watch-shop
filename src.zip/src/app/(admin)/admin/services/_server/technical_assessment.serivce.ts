import crypto from "node:crypto";
import prisma from "@/server/db/client";
import * as repo from "./technical.assessment.repo";
import {
    ContentStatus,
    MaintenanceEventType,
    Prisma,
    ServiceRequestStatus,
    TechnicalAssessmentStatus,
} from "@prisma/client";

function inferMovementKind(raw?: string | null): "BATTERY" | "MECHANICAL" | "UNKNOWN" {
    const text = String(raw || "").toUpperCase();
    if (!text) return "UNKNOWN";
    if (text.includes("QUARTZ") || text.includes("PIN") || text.includes("SOLAR") || text.includes("ECO")) return "BATTERY";
    if (text.includes("AUTO") || text.includes("AUTOMATIC") || text.includes("CÓT") || text.includes("MECHANICAL")) return "MECHANICAL";
    return "UNKNOWN";
}

function marker(serviceRequestId: string) {
    return `[AUTO_TECH_ASSESSMENT:${serviceRequestId}]`;
}

function makeStatusChangeNote(nextStatus: ServiceRequestStatus, conclusion?: string | null) {
    return [
        `[AUTO_TECH_STATUS] ${nextStatus}`,
        conclusion ? `Kết luận: ${conclusion}` : null,
    ]
        .filter(Boolean)
        .join("\n");
}

async function assertServiceProductVisible(tx: Prisma.TransactionClient, serviceRequestId: string) {
    const sr = await tx.serviceRequest.findUnique({
        where: { id: serviceRequestId },
        select: {
            id: true,
            productId: true,
            product: { select: { id: true, contentStatus: true } },
        },
    });
    if (!sr) throw new Error("Service request not found");
    if (String(sr.product?.contentStatus ?? "").toUpperCase() === String(ContentStatus.ARCHIVED)) {
        throw new Error("Sản phẩm đã hủy/ẩn, không thể tiếp tục thao tác service.");
    }
    return sr;
}

function normalizeFunctionalIssues(input: any) {
    const chrono = input?.functional?.chronograph;
    const moon = input?.functional?.moonphase;
    const rows: Array<any> = [];
    if (chrono?.status === "ISSUE") {
        rows.push({
            area: "FUNCTIONAL_CHRONOGRAPH",
            issueType: "CHECK",
            actionMode: chrono.actionMode ?? "INTERNAL",
            vendorId: chrono.vendorId ?? null,
            vendorNameSnap: null,
            serviceCatalogId: chrono.serviceCatalogId ?? null,
            supplyCatalogId: null,
            mechanicalPartCatalogId: chrono.partId ?? null,
            note: chrono.note ?? "Chronograph có vấn đề",
            estimatedCost: chrono.cost ?? null,
            sortOrder: typeof chrono.sortOrder === "number" ? chrono.sortOrder : 100,
        });
    }
    if (moon?.status === "ISSUE") {
        rows.push({
            area: "FUNCTIONAL_MOONPHASE",
            issueType: "CHECK",
            actionMode: moon.actionMode ?? "INTERNAL",
            vendorId: moon.vendorId ?? null,
            vendorNameSnap: null,
            serviceCatalogId: moon.serviceCatalogId ?? null,
            supplyCatalogId: null,
            mechanicalPartCatalogId: moon.partId ?? null,
            note: moon.note ?? "Moonphase có vấn đề",
            estimatedCost: moon.cost ?? null,
            sortOrder: typeof moon.sortOrder === "number" ? moon.sortOrder : 110,
        });
    }
    return rows;
}

async function syncAutoLogsAndCost(
    tx: Prisma.TransactionClient,
    input: {
        serviceRequestId: string;
        productId?: string | null;
        variantId?: string | null;
        brandSnapshot?: string | null;
        modelSnapshot?: string | null;
        refSnapshot?: string | null;
        serialSnapshot?: string | null;
        technicianId?: string | null;
        technicianNameSnap?: string | null;
        issues: Array<any>;
        conclusion?: string | null;
    }
) {
    const mark = marker(input.serviceRequestId);
    const oldAutoLogs = await tx.maintenanceRecord.findMany({
        where: { serviceRequestId: input.serviceRequestId, notes: { startsWith: mark } },
        select: { id: true, totalCost: true },
    });
    const oldAutoTotal = oldAutoLogs.reduce((sum, x) => sum + Number(x.totalCost ?? 0), 0);
    if (oldAutoLogs.length) {
        await tx.maintenanceRecord.deleteMany({ where: { id: { in: oldAutoLogs.map((x) => x.id) } } });
    }

    const vendorIds = Array.from(new Set(input.issues.map((x) => x.vendorId).filter(Boolean)));
    const serviceCatalogIds = Array.from(new Set(input.issues.map((x) => x.serviceCatalogId).filter(Boolean)));
    const vendors = vendorIds.length
        ? await tx.vendor.findMany({ where: { id: { in: vendorIds as string[] } }, select: { id: true, name: true } })
        : [];
    const serviceCatalogs = serviceCatalogIds.length
        ? await tx.serviceCatalog.findMany({ where: { id: { in: serviceCatalogIds as string[] } }, select: { id: true, name: true } })
        : [];
    const vendorMap = new Map(vendors.map((x) => [x.id, x.name]));
    const serviceMap = new Map(serviceCatalogs.map((x) => [x.id, x.name]));

    let newAutoTotal = 0;
    for (const [idx, issue] of input.issues.entries()) {
        const cost = Number(issue.estimatedCost ?? 0);
        if (cost > 0) newAutoTotal += cost;
        const issueRef = issue.id ? `Issue: ${issue.id}` : null;
        const lines = [
            `${mark} #${idx + 1}`,
            issueRef,
            issue.area ? `Hạng mục: ${issue.area}` : null,
            `Loại xử lý: ${issue.issueType}`,
            issue.serviceCatalogId ? `Nghiệp vụ: ${serviceMap.get(issue.serviceCatalogId) ?? issue.serviceCatalogId}` : null,
            issue.actionMode === "VENDOR" ? `Thực hiện: Vendor${issue.vendorId ? ` (${vendorMap.get(issue.vendorId) ?? issue.vendorId})` : ""}` : issue.actionMode === "INTERNAL" ? "Thực hiện: Nội bộ" : "Thực hiện: Chưa rõ",
            input.conclusion ? `Kết luận: ${input.conclusion}` : null,
            issue.note ? `Ghi chú: ${issue.note}` : null,
        ].filter(Boolean);
        await tx.maintenanceRecord.create({
            data: {
                id: crypto.randomUUID(),
                serviceRequestId: input.serviceRequestId,
                technicalIssueId: issue.id ?? null,
                productId: input.productId ?? null,
                variantId: input.variantId ?? null,
                brandSnapshot: input.brandSnapshot ?? null,
                modelSnapshot: input.modelSnapshot ?? null,
                refSnapshot: input.refSnapshot ?? null,
                serialSnapshot: input.serialSnapshot ?? null,
                technicianId: input.technicianId ?? null,
                technicianNameSnap: input.technicianNameSnap ?? null,
                vendorId: issue.actionMode === "VENDOR" ? issue.vendorId ?? null : null,
                vendorName: issue.actionMode === "VENDOR" ? vendorMap.get(issue.vendorId ?? "") ?? issue.vendorNameSnap ?? null : null,
                eventType: issue.actionMode === "VENDOR" ? MaintenanceEventType.ASSIGN_VENDOR : MaintenanceEventType.NOTE,
                notes: lines.join("\n"),
                totalCost: cost > 0 ? new Prisma.Decimal(String(cost)) : null,
                currency: "VND",
                servicedAt: new Date(),
                serviceCatalogId: issue.serviceCatalogId ?? null,
            } as any,
        });
    }

    if (input.variantId) {
        const variant = await tx.productVariant.findUnique({ where: { id: input.variantId }, select: { id: true, costPrice: true } });
        if (variant) {
            const currentCost = Number(variant.costPrice ?? 0);
            const nextCost = Math.max(0, currentCost - oldAutoTotal + newAutoTotal);
            await tx.productVariant.update({ where: { id: variant.id }, data: { costPrice: new Prisma.Decimal(String(nextCost)) } });
        }
    }

    return { oldAutoTotal, newAutoTotal };
}

export async function getTechnicalAssessmentPanel(serviceRequestId: string) {
    const base = await assertServiceProductVisible(prisma as any, serviceRequestId);
    const panel = await repo.getPanel(serviceRequestId);
    if (!panel) throw new Error("Không tìm thấy service request");

    const maintenanceRecords = await prisma.maintenanceRecord.findMany({
        where: { serviceRequestId },
        orderBy: { createdAt: "desc" },
        select: {
            id: true,
            technicalIssueId: true,
            eventType: true,
            notes: true,
            totalCost: true,
            createdAt: true,
            servicedAt: true,
            vendorName: true,
            workSummary: true,
        } as any,
    });

    const issueMap = new Map<string, any[]>();
    for (const row of maintenanceRecords) {
        const key = (row as any).technicalIssueId || "__ungrouped__";
        if (!issueMap.has(key)) issueMap.set(key, []);
        issueMap.get(key)!.push(row);
    }

    if (!panel.assessment) {
        return {
            ...panel,
            technicalIssues: [],
            maintenanceRecords,
            assessment: {
                movementKind: inferMovementKind(panel.serviceRequest.movement),
                movementStatus: "GOOD",
                caseStatus: "GOOD",
                crystalStatus: "GOOD",
                crownStatus: "GOOD",
                preRate: null,
                preAmplitude: null,
                preBeatError: null,
                postRate: null,
                postAmplitude: null,
                postBeatError: null,
                conclusion: "",
                imageFileKey: panel.serviceRequest.primaryImageUrl ?? panel.serviceRequest.productImages?.[0]?.fileKey ?? null,
                status: "DRAFT",
                issues: [],
                issueLogsById: {},
            },
        };
    }

    const technicalIssues = panel.assessment.issues.map((it: any) => ({
        ...it,
        executionStatus: it.executionStatus ?? "OPEN",
        maintenanceRecords: issueMap.get(it.id) ?? [],
    }));

    return {
        ...panel,
        technicalIssues,
        maintenanceRecords,
        assessment: {
            ...panel.assessment,
            issueLogsById: Object.fromEntries(Array.from(issueMap.entries())),
        },
    };
}

export async function saveTechnicalAssessment(input: any) {
    const serviceRequestId = String(input.serviceRequestId || "").trim();
    if (!serviceRequestId) throw new Error("Missing serviceRequestId");

    return prisma.$transaction(async (tx) => {
        const sr = await tx.serviceRequest.findUnique({
            where: { id: serviceRequestId },
            select: {
                id: true,
                status: true,
                technicianId: true,
                technicianNameSnap: true,
                productId: true,
                variantId: true,
                brandSnapshot: true,
                modelSnapshot: true,
                refSnapshot: true,
                serialSnapshot: true,
                product: { select: { id: true, contentStatus: true } },
            },
        });
        if (!sr) throw new Error("Service request not found");
        if (String(sr.product?.contentStatus ?? "").toUpperCase() === String(ContentStatus.ARCHIVED)) {
            throw new Error("Sản phẩm đã hủy/ẩn, không thể tiếp tục thao tác service.");
        }

        const normalizedIssues = [
            ...(Array.isArray(input.issues) ? input.issues : []),
            ...normalizeFunctionalIssues(input),
        ].map((x: any, idx: number) => ({
            area: x.area ?? null,
            issueType: x.issueType,
            actionMode: x.actionMode ?? "NONE",
            vendorId: x.vendorId ?? null,
            vendorNameSnap: null,
            serviceCatalogId: x.serviceCatalogId ?? null,
            supplyCatalogId: x.supplyCatalogId ?? null,
            mechanicalPartCatalogId: x.mechanicalPartCatalogId ?? x.partId ?? null,
            note: x.note ?? null,
            estimatedCost: x.estimatedCost ?? x.cost ?? null,
            sortOrder: x.sortOrder ?? idx,
        }));

        const vendorIds = Array.from(new Set(normalizedIssues.map((x: any) => x.vendorId).filter(Boolean)));
        const vendors = vendorIds.length ? await tx.vendor.findMany({ where: { id: { in: vendorIds as string[] } }, select: { id: true, name: true } }) : [];
        const vendorMap = new Map(vendors.map((x) => [x.id, x.name]));

        const issuesWithVendorSnap = normalizedIssues.map((x: any) => ({
            ...x,
            vendorNameSnap: x.vendorId ? vendorMap.get(x.vendorId) ?? null : null,
        }));

        const hasAnyIssue = issuesWithVendorSnap.length > 0 || [input.movementStatus, input.caseStatus, input.crystalStatus, input.crownStatus].some((x) => x === "ISSUE");
        const nextServiceStatus = hasAnyIssue ? ServiceRequestStatus.IN_PROGRESS : ServiceRequestStatus.COMPLETED;
        const nextAssessmentStatus = hasAnyIssue ? ("IN_PROGRESS" as any) : TechnicalAssessmentStatus.COMPLETED;
        const topLevelActionMode = issuesWithVendorSnap.some((x: any) => x.actionMode === "VENDOR") ? "VENDOR" : issuesWithVendorSnap.some((x: any) => x.actionMode === "INTERNAL") ? "INTERNAL" : "NONE";
        const firstVendor = issuesWithVendorSnap.find((x: any) => x.vendorId)?.vendorId ?? null;
        const firstVendorName = firstVendor ? vendorMap.get(firstVendor) ?? null : null;

        const assessment = await repo.upsertAssessment(tx, {
            serviceRequestId,
            movementKind: input.movementKind ?? "UNKNOWN",
            movementStatus: input.movementStatus,
            caseStatus: input.caseStatus,
            crystalStatus: input.crystalStatus,
            crownStatus: input.crownStatus,
            preRate: input.preRate ?? null,
            preAmplitude: input.preAmplitude ?? null,
            preBeatError: input.preBeatError ?? null,
            postRate: input.postRate ?? null,
            postAmplitude: input.postAmplitude ?? null,
            postBeatError: input.postBeatError ?? null,
            actionMode: topLevelActionMode as any,
            vendorId: firstVendor,
            vendorNameSnap: firstVendorName,
            conclusion: input.conclusion ?? null,
            imageFileKey: input.imageFileKey ?? null,
            status: nextAssessmentStatus,
            evaluatedById: sr.technicianId ?? null,
            evaluatedByNameSnap: sr.technicianNameSnap ?? null,
            issues: issuesWithVendorSnap,
        } as any);

        const createdIssues = await tx.technicalIssue.findMany({
            where: { assessmentId: assessment.id },
            orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
            select: { id: true, area: true, note: true, serviceCatalogId: true, vendorId: true, vendorNameSnap: true, estimatedCost: true, actionMode: true, issueType: true },
        });

        const syncInputIssues = createdIssues.map((row, idx) => ({ ...issuesWithVendorSnap[idx], id: row.id }));
        const autoArtifacts = await syncAutoLogsAndCost(tx, {
            serviceRequestId,
            productId: sr.productId ?? null,
            variantId: sr.variantId ?? null,
            brandSnapshot: sr.brandSnapshot ?? null,
            modelSnapshot: sr.modelSnapshot ?? null,
            refSnapshot: sr.refSnapshot ?? null,
            serialSnapshot: sr.serialSnapshot ?? null,
            technicianId: sr.technicianId ?? null,
            technicianNameSnap: sr.technicianNameSnap ?? null,
            conclusion: input.conclusion ?? null,
            issues: syncInputIssues,
        });

        await tx.serviceRequest.update({
            where: { id: serviceRequestId },
            data: {
                status: nextServiceStatus,
                vendorId: firstVendor,
                vendorNameSnap: firstVendorName,
                updatedAt: new Date(),
            },
        });

        await tx.maintenanceRecord.create({
            data: {
                id: crypto.randomUUID(),
                serviceRequestId,
                productId: sr.productId ?? null,
                variantId: sr.variantId ?? null,
                brandSnapshot: sr.brandSnapshot ?? null,
                modelSnapshot: sr.modelSnapshot ?? null,
                refSnapshot: sr.refSnapshot ?? null,
                serialSnapshot: sr.serialSnapshot ?? null,
                technicianId: sr.technicianId ?? null,
                technicianNameSnap: sr.technicianNameSnap ?? null,
                vendorId: firstVendor,
                vendorName: firstVendorName,
                eventType: MaintenanceEventType.NOTE,
                notes: makeStatusChangeNote(nextServiceStatus, input.conclusion ?? null),
                currency: "VND",
                servicedAt: new Date(),
            },
        });

        return { assessment, autoArtifacts, serviceRequestStatus: nextServiceStatus, issueCount: createdIssues.length };
    });
}

export async function startTechnicalIssue(issueId: string) {
    return prisma.$transaction(async (tx) => {
        const issue = await tx.technicalIssue.findUnique({ where: { id: issueId }, select: { id: true, serviceRequestId: true, note: true, area: true } as any });
        if (!issue) throw new Error("Technical issue not found");
        await tx.technicalIssue.update({ where: { id: issueId }, data: { executionStatus: "IN_PROGRESS" as any, startedAt: new Date() } as any });
        await tx.serviceRequest.update({ where: { id: (issue as any).serviceRequestId }, data: { status: ServiceRequestStatus.IN_PROGRESS } });
        await tx.maintenanceRecord.create({ data: { id: crypto.randomUUID(), serviceRequestId: (issue as any).serviceRequestId, technicalIssueId: issueId, eventType: MaintenanceEventType.NOTE, notes: `[ISSUE_START] ${issue.area ?? "ISSUE"}\n${issue.note ?? ""}`, currency: "VND", servicedAt: new Date() } as any });
        return { ok: true };
    });
}

export async function completeTechnicalIssue(issueId: string) {
    return prisma.$transaction(async (tx) => {
        const issue = await tx.technicalIssue.findUnique({ where: { id: issueId }, select: { id: true, serviceRequestId: true, note: true, area: true } as any });
        if (!issue) throw new Error("Technical issue not found");
        await tx.technicalIssue.update({ where: { id: issueId }, data: { executionStatus: "DONE" as any, completedAt: new Date(), completedByNameSnap: "system" } as any });
        await tx.maintenanceRecord.create({ data: { id: crypto.randomUUID(), serviceRequestId: (issue as any).serviceRequestId, technicalIssueId: issueId, eventType: MaintenanceEventType.NOTE, notes: `[ISSUE_DONE] ${issue.area ?? "ISSUE"}\n${issue.note ?? ""}`, currency: "VND", servicedAt: new Date() } as any });
        const remain = await tx.technicalIssue.count({ where: { serviceRequestId: (issue as any).serviceRequestId, executionStatus: { not: "DONE" as any } } as any });
        if (remain === 0) {
            await tx.serviceRequest.update({ where: { id: (issue as any).serviceRequestId }, data: { status: ServiceRequestStatus.COMPLETED } });
        }
        return { ok: true, remaining: remain };
    });
}
