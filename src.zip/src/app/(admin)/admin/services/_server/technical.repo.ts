import {
    Prisma,
    PrismaClient,
    TechnicalActionMode,
    TechnicalIssueType,
    TechnicalMovementKind,
    TechnicalSectionStatus,
} from "@prisma/client";

const prisma = new PrismaClient();
type DB = Prisma.TransactionClient | PrismaClient;

type AssessmentActionLine = {
    status?: string | null;
    action?: unknown;
    actionCode?: string | null;
    execution?: string | null;
    actionMode?: string | null;
    processingMode?: string | null;
    note?: string | null;
    cost?: number | null;
    estimatedCost?: number | null;
    vendorId?: string | null;
    serviceCatalogId?: string | null;
    supplyCatalogId?: string | null;
    partId?: string | null;
    mechanicalPartCatalogId?: string | null;
};

export type TechnicalAssessmentPayload = {
    serviceRequestId: string;
    summary?: string | null;
    notes?: string | null;
    conclusion?: string | null;
    payloadJson?: Prisma.InputJsonValue | null;
    movement?: {
        machineType?: string | null;
        status?: string | null;
        beforeSpecs?: {
            rate?: string | number | null;
            amp?: string | number | null;
            err?: string | number | null;
        } | null;
        afterSpecs?: {
            rate?: string | number | null;
            amp?: string | number | null;
            err?: string | number | null;
        } | null;
        action?: unknown;
        actionCode?: string | null;
        execution?: string | null;
        actionMode?: string | null;
        processingMode?: string | null;
        note?: string | null;
        cost?: number | null;
        estimatedCost?: number | null;
        vendorId?: string | null;
        serviceCatalogId?: string | null;
        supplyCatalogId?: string | null;
        partId?: string | null;
        mechanicalPartCatalogId?: string | null;
        lines?: AssessmentActionLine[];
    };
    crown?: AssessmentActionLine;
    appearance?: {
        score?: number | null;
        case?: any;
        glass?: any;
        dial?: any;
        crown?: any;
    };
    financialSummary?: {
        movementCost?: number | null;
        crownCost?: number | null;
        cosmeticProposalCost?: number | null;
        totalCost?: number | null;
    };
    functional?: {
        chronograph?: AssessmentActionLine;
        moonphase?: AssessmentActionLine;
    };
};

function toIntOrNull(v: unknown) {
    if (v === null || v === undefined || v === "") return null;
    const n = Number(v);
    if (Number.isNaN(n)) return null;
    return Math.round(n);
}

function toDecimalOrNull(v: unknown) {
    if (v === null || v === undefined || v === "") return null;
    const n = Number(v);
    if (Number.isNaN(n)) return null;
    return new Prisma.Decimal(n);
}

function textOrNull(v: unknown) {
    const s = String(v ?? "").trim();
    return s.length ? s : null;
}

function joinNote(...parts: Array<unknown>) {
    const text = parts
        .map((x) => String(x ?? "").trim())
        .filter(Boolean)
        .join(" | ");
    return text || null;
}

function pickActionCode(v: unknown) {
    if (!v) return null;
    if (typeof v === "string") return textOrNull(v);

    if (typeof v === "object") {
        const anyV = v as any;
        return (
            textOrNull(anyV.code) ??
            textOrNull(anyV.name) ??
            textOrNull(anyV.label) ??
            textOrNull(anyV.value)
        );
    }

    return textOrNull(v);
}

function mapIssueActionMode(v: unknown): TechnicalActionMode {
    const s = String(v ?? "").toUpperCase();
    return s === "VENDOR" ? TechnicalActionMode.VENDOR : TechnicalActionMode.INTERNAL;
}

function mapMovementKind(v: unknown): TechnicalMovementKind {
    const s = String(v ?? "").toUpperCase();
    if (s === "MECHANICAL") return TechnicalMovementKind.MECHANICAL;
    if (s === "QUARTZ") return TechnicalMovementKind.QUARTZ;
    return TechnicalMovementKind.UNKNOWN;
}

function mapSectionStatus(hasIssue: boolean): TechnicalSectionStatus {
    return hasIssue ? TechnicalSectionStatus.ISSUE : TechnicalSectionStatus.GOOD;
}

async function getVendorSnapshot(tx: DB, vendorId?: string | null) {
    if (!vendorId) {
        return {
            vendorId: null as string | null,
            vendorNameSnap: null as string | null,
        };
    }

    const vendor = await tx.vendor.findUnique({
        where: { id: vendorId },
        select: {
            id: true,
            name: true,
        },
    });

    return {
        vendorId: vendor?.id ?? null,
        vendorNameSnap: vendor?.name ?? null,
    };
}

function getCrownPayload(payload: TechnicalAssessmentPayload) {
    return payload.crown ?? payload.appearance?.crown ?? null;
}

function normalizeAppearanceProposal(item: any) {
    const proposal = item?.proposal ?? null;
    if (!proposal?.enabled) return null;
    const actionCode = pickActionCode(proposal.action);
    if (!actionCode || actionCode === "NO_ACTION") return null;

    return {
        status: "ISSUE",
        actionCode,
        execution: proposal.execution,
        vendorId: proposal.vendorId ?? null,
        estimatedCost: proposal.estimatedCost ?? null,
        note: joinNote(
            Array.isArray(item?.issues) ? item.issues.join(", ") : null,
            item?.note ?? null,
            proposal.note ?? null
        ),
    };
}

function payloadJsonFromInput(payload: TechnicalAssessmentPayload) {
    if (payload.payloadJson !== undefined) return payload.payloadJson;
    return payload as unknown as Prisma.InputJsonValue;
}

export async function upsertTechnicalAssessment(
    tx: DB,
    payload: TechnicalAssessmentPayload,
    opts?: {
        evaluatedById?: string | null;
        evaluatedByNameSnap?: string | null;
    }
) {
    const existing = await tx.technicalAssessment.findFirst({
        where: { serviceRequestId: payload.serviceRequestId },
        orderBy: { updatedAt: "desc" },
        select: { id: true },
    });

    const movementIssue = String(payload?.movement?.status ?? "").toUpperCase() === "ISSUE";
    const caseIssue = !!normalizeAppearanceProposal(payload.appearance?.case);
    const crystalIssue = !!normalizeAppearanceProposal(payload.appearance?.glass);
    const crown = getCrownPayload(payload);
    const crownIssue = String(crown?.status ?? "").toUpperCase() === "ISSUE";

    const anyVendor = [
        payload?.movement?.vendorId,
        crown?.vendorId,
        payload?.appearance?.case?.proposal?.vendorId,
        payload?.appearance?.glass?.proposal?.vendorId,
        payload?.appearance?.dial?.proposal?.vendorId,
    ].find(Boolean);

    const vendorSnap = await getVendorSnapshot(tx, anyVendor ?? null);

    const data: Prisma.TechnicalAssessmentUncheckedCreateInput = {
        serviceRequestId: payload.serviceRequestId,
        movementKind: mapMovementKind(payload?.movement?.machineType),
        preRate: toIntOrNull(payload?.movement?.beforeSpecs?.rate),
        preAmplitude: toIntOrNull(payload?.movement?.beforeSpecs?.amp),
        preBeatError: toDecimalOrNull(payload?.movement?.beforeSpecs?.err),
        postRate: toIntOrNull(payload?.movement?.afterSpecs?.rate),
        postAmplitude: toIntOrNull(payload?.movement?.afterSpecs?.amp),
        postBeatError: toDecimalOrNull(payload?.movement?.afterSpecs?.err),
        actionMode: anyVendor ? TechnicalActionMode.VENDOR : TechnicalActionMode.INTERNAL,
        vendorId: vendorSnap.vendorId,
        vendorNameSnap: vendorSnap.vendorNameSnap,
        conclusion: textOrNull(payload.conclusion ?? payload.summary ?? payload.notes),
        payloadJson: payloadJsonFromInput(payload),
        evaluatedById: opts?.evaluatedById ?? null,
        evaluatedByNameSnap: opts?.evaluatedByNameSnap ?? null,
        movementStatus: mapSectionStatus(movementIssue),
        caseStatus: mapSectionStatus(caseIssue),
        crystalStatus: mapSectionStatus(crystalIssue),
        crownStatus: mapSectionStatus(crownIssue),
        status: "DRAFT" as any,
    };

    if (existing) {
        return tx.technicalAssessment.update({
            where: { id: existing.id },
            data,
        });
    }

    return tx.technicalAssessment.create({
        data,
    });
}

export async function replaceTechnicalIssues(
    tx: DB,
    assessmentId: string,
    serviceRequestId: string,
    payload: TechnicalAssessmentPayload
) {
    await tx.technicalIssue.deleteMany({
        where: { assessmentId },
    });

    const rows: Prisma.TechnicalIssueCreateManyInput[] = [];
    let sortOrder = 1;

    async function pushIssue(input: {
        area: string;
        issueType: TechnicalIssueType;
        actionMode: TechnicalActionMode;
        serviceCatalogId?: string | null;
        supplyCatalogId?: string | null;
        mechanicalPartCatalogId?: string | null;
        note?: string | null;
        summary?: string | null;
        estimatedCost?: Prisma.Decimal | null;
        vendorId?: string | null;
        vendorNameSnap?: string | null;
    }) {
        rows.push({
            assessmentId,
            serviceRequestId,
            openedAt: new Date(),
            area: input.area,
            issueType: input.issueType,
            actionMode: input.actionMode,
            serviceCatalogId: input.serviceCatalogId ?? null,
            supplyCatalogId: input.supplyCatalogId ?? null,
            mechanicalPartCatalogId: input.mechanicalPartCatalogId ?? null,
            note: input.note ?? null,
            summary: input.summary ?? null,
            estimatedCost: input.estimatedCost ?? null,
            sortOrder: sortOrder++,
            vendorId: input.vendorId ?? null,
            vendorNameSnap: input.vendorNameSnap ?? null,
        });
    }

    const movementLines = Array.isArray(payload?.movement?.lines)
        ? payload.movement!.lines!
        : [];

    if (String(payload?.movement?.status ?? "").toUpperCase() === "ISSUE") {
        if (movementLines.length > 0) {
            for (const line of movementLines) {
                const actionCode = pickActionCode(line?.action ?? line?.actionCode);
                if (!actionCode) continue;

                const vendorSnap = await getVendorSnapshot(tx, line.vendorId);
                await pushIssue({
                    area: "MOVEMENT",
                    issueType: TechnicalIssueType.REPAIR,
                    actionMode: mapIssueActionMode(
                        line.execution ?? line.processingMode ?? line.actionMode
                    ),
                    serviceCatalogId: line.serviceCatalogId ?? null,
                    supplyCatalogId: line.supplyCatalogId ?? null,
                    mechanicalPartCatalogId:
                        line.partId ?? line.mechanicalPartCatalogId ?? null,
                    note: joinNote(actionCode, line.note ?? null),
                    summary: actionCode,
                    estimatedCost: toDecimalOrNull(line.cost ?? line.estimatedCost),
                    vendorId: vendorSnap.vendorId,
                    vendorNameSnap: vendorSnap.vendorNameSnap,
                });
            }
        } else {
            const actionCode = pickActionCode(
                payload?.movement?.action ?? payload?.movement?.actionCode
            );
            if (actionCode) {
                const vendorSnap = await getVendorSnapshot(tx, payload?.movement?.vendorId);
                await pushIssue({
                    area: "MOVEMENT",
                    issueType: TechnicalIssueType.REPAIR,
                    actionMode: mapIssueActionMode(
                        payload?.movement?.execution ??
                        payload?.movement?.processingMode ??
                        payload?.movement?.actionMode
                    ),
                    serviceCatalogId: payload?.movement?.serviceCatalogId ?? null,
                    supplyCatalogId: payload?.movement?.supplyCatalogId ?? null,
                    mechanicalPartCatalogId:
                        payload?.movement?.partId ??
                        payload?.movement?.mechanicalPartCatalogId ??
                        null,
                    note: joinNote(actionCode, payload?.movement?.note ?? null),
                    summary: actionCode,
                    estimatedCost: toDecimalOrNull(
                        payload?.movement?.cost ?? payload?.movement?.estimatedCost
                    ),
                    vendorId: vendorSnap.vendorId,
                    vendorNameSnap: vendorSnap.vendorNameSnap,
                });
            }
        }
    }

    const crown = getCrownPayload(payload);
    if (crown && String(crown.status ?? "").toUpperCase() === "ISSUE") {
        const actionCode = pickActionCode(crown.action ?? crown.actionCode);
        if (actionCode) {
            const vendorSnap = await getVendorSnapshot(tx, crown.vendorId);
            await pushIssue({
                area: "CROWN",
                issueType: TechnicalIssueType.REPAIR,
                actionMode: mapIssueActionMode(
                    crown.execution ?? crown.processingMode ?? crown.actionMode
                ),
                serviceCatalogId: crown.serviceCatalogId ?? null,
                supplyCatalogId: crown.supplyCatalogId ?? null,
                mechanicalPartCatalogId:
                    crown.partId ?? crown.mechanicalPartCatalogId ?? null,
                note: joinNote(actionCode, crown.note ?? null),
                summary: actionCode,
                estimatedCost: toDecimalOrNull(crown.cost ?? crown.estimatedCost),
                vendorId: vendorSnap.vendorId,
                vendorNameSnap: vendorSnap.vendorNameSnap,
            });
        }
    }

    for (const [area, source] of [
        ["CASE", payload?.appearance?.case],
        ["CRYSTAL", payload?.appearance?.glass],
        ["DIAL", payload?.appearance?.dial],
    ] as const) {
        const item = normalizeAppearanceProposal(source);
        if (!item) continue;
        const vendorSnap = await getVendorSnapshot(tx, item.vendorId);
        await pushIssue({
            area,
            issueType: TechnicalIssueType.REPAIR,
            actionMode: mapIssueActionMode(item.execution),
            note: item.note,
            summary: item.actionCode,
            estimatedCost: toDecimalOrNull(item.estimatedCost),
            vendorId: vendorSnap.vendorId,
            vendorNameSnap: vendorSnap.vendorNameSnap,
        });
    }

    for (const [label, item] of [
        ["CHRONOGRAPH", payload?.functional?.chronograph],
        ["MOONPHASE", payload?.functional?.moonphase],
    ] as const) {
        if (!item) continue;
        if (String(item.status ?? "").toUpperCase() !== "ISSUE") continue;

        const actionCode = pickActionCode(item.action ?? item.actionCode);
        if (!actionCode) continue;

        const vendorSnap = await getVendorSnapshot(tx, item.vendorId);

        await pushIssue({
            area: "FUNCTIONAL",
            issueType: TechnicalIssueType.REPAIR,
            actionMode: mapIssueActionMode(
                item.execution ?? item.processingMode ?? item.actionMode
            ),
            serviceCatalogId: item.serviceCatalogId ?? null,
            supplyCatalogId: item.supplyCatalogId ?? null,
            mechanicalPartCatalogId:
                item.partId ?? item.mechanicalPartCatalogId ?? null,
            note: joinNote(label, actionCode, item.note ?? null),
            summary: joinNote(label, actionCode),
            estimatedCost: toDecimalOrNull(item.cost ?? item.estimatedCost),
            vendorId: vendorSnap.vendorId,
            vendorNameSnap: vendorSnap.vendorNameSnap,
        });
    }

    if (rows.length > 0) {
        await tx.technicalIssue.createMany({
            data: rows,
        });
    }

    return rows.length;
}
