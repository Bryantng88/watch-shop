import { prisma } from "@/server/db/client";

export async function getTechnicalAssessmentPanelWithCatalogs(serviceRequestId: string) {
    const sr = await prisma.serviceRequest.findUnique({
        where: { id: serviceRequestId },
        select: {
            id: true,
            refNo: true,
            status: true,
            scope: true,
            productId: true,
            technicianId: true,
            technicianNameSnap: true,
            vendorNameSnap: true,
            skuSnapshot: true,
            primaryImageUrlSnapshot: true,
            createdAt: true,
            updatedAt: true,
        },
    });

    if (!sr) {
        return null;
    }

    let product: any = null;

    if (sr.productId) {
        product = await prisma.product.findUnique({
            where: { id: sr.productId },
            select: {
                id: true,
                title: true,
                primaryImageUrl: true,
                //movement: true,
                contentStatus: true,
            },
        });

        if (String(product?.contentStatus ?? "").toUpperCase() === "ARCHIVED") {
            throw new Error("Sản phẩm đã hủy/ẩn, không hiển thị trong quy trình service.");
        }
    }

    const assessment = await prisma.technicalAssessment.findFirst({
        where: { serviceRequestId },
        orderBy: { updatedAt: "desc" },
        select: {
            id: true,
            status: true,
            conclusion: true,
            imageFileKey: true,
            actionMode: true,
            movementKind: true,
            movementStatus: true,
            caseStatus: true,
            crystalStatus: true,
            crownStatus: true,
            vendorNameSnap: true,
            evaluatedByNameSnap: true,
            payloadJson: true,
            createdAt: true,
            updatedAt: true,
        },
    });

    const technicalIssues = assessment
        ? await prisma.technicalIssue.findMany({
            where: { assessmentId: assessment.id },
            orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
            include: {
                Vendor: {
                    select: { id: true, name: true },
                },
                User: {
                    select: { id: true, name: true, email: true },
                },
                ServiceCatalog: {
                    select: { id: true, code: true, name: true },
                },
                SupplyCatalog: {
                    select: { id: true, code: true, name: true },
                },
                MechanicalPartCatalog: {
                    select: { id: true, code: true, name: true },
                },
                MaintenanceRecord: {
                    orderBy: { createdAt: "desc" },
                    select: {
                        id: true,
                        eventType: true,
                        notes: true,
                        diagnosis: true,
                        workSummary: true,
                        totalCost: true,
                        servicedAt: true,
                        createdAt: true,
                    },
                },
            },
        })
        : [];

    const maintenanceRecords = await prisma.maintenanceRecord.findMany({
        where: { serviceRequestId },
        orderBy: [{ createdAt: "desc" }],
        include: {
            TechnicalIssue: {
                select: {
                    id: true,
                    area: true,
                    summary: true,
                    note: true,
                },
            },
            ServiceCatalog: {
                select: {
                    id: true,
                    code: true,
                    name: true,
                },
            },
            User: {
                select: {
                    id: true,
                    name: true,
                    email: true,
                },
            },
            vendor: {
                select: {
                    id: true,
                    name: true,
                },
            },
        },
    });

    const [movementActions, crownActions, parts, appearanceRows, vendors] = await Promise.all([
        prisma.technicalActionCatalog.findMany({
            where: { isActive: true, groupKey: "MOVEMENT" },
            orderBy: [{ sortOrder: "asc" }, { code: "asc" }],
            select: {
                id: true,
                code: true,
                name: true,
                appliesTo: true,
                requiresPart: true,
                defaultExecutionMode: true,
            },
        }),
        prisma.technicalActionCatalog.findMany({
            where: { isActive: true, groupKey: "CROWN" },
            orderBy: [{ sortOrder: "asc" }, { code: "asc" }],
            select: {
                id: true,
                code: true,
                name: true,
                appliesTo: true,
                requiresPart: true,
                defaultExecutionMode: true,
            },
        }),
        prisma.technicalPartCatalog.findMany({
            where: { isActive: true },
            orderBy: [{ sortOrder: "asc" }, { code: "asc" }],
            select: {
                id: true,
                code: true,
                name: true,
                partGroup: true,
            },
        }),
        prisma.technicalAppearanceIssueCatalog.findMany({
            where: { isActive: true },
            orderBy: [{ area: "asc" }, { sortOrder: "asc" }, { code: "asc" }],
            select: {
                id: true,
                code: true,
                area: true,
                label: true,
                deductionScore: true,
            },
        }),
        prisma.vendor.findMany({
            orderBy: [{ name: "asc" }],
            select: { id: true, name: true },
        }),
    ]);

    const appearanceIssues = {
        CASE: appearanceRows.filter((x) => x.area === "CASE"),
        CRYSTAL: appearanceRows.filter((x) => x.area === "CRYSTAL"),
        DIAL: appearanceRows.filter((x) => x.area === "DIAL"),
    };

    const issueCount = technicalIssues.length;
    const openIssueCount = technicalIssues.filter((x) => {
        const st = String(x.executionStatus ?? "").toUpperCase();
        return st === "OPEN" || st === "IN_PROGRESS";
    }).length;

    return {
        serviceRequest: {
            id: sr.id,
            refNo: sr.refNo,
            status: sr.status,
            scope: sr.scope,
            productId: sr.productId,
            productTitle: product?.title ?? null,
            sku: sr.skuSnapshot ?? null,
            movement: product?.movement ?? null,
            primaryImageUrl: sr.primaryImageUrlSnapshot ?? product?.primaryImageUrl ?? null,
            technicianId: sr.technicianId,
            technicianName: sr.technicianNameSnap ?? null,
            vendorName: sr.vendorNameSnap ?? null,
            createdAt: sr.createdAt,
            updatedAt: sr.updatedAt,
        },
        assessment: assessment
            ? {
                id: assessment.id,
                status: assessment.status,
                conclusion: assessment.conclusion,
                imageFileKey: assessment.imageFileKey,
                actionMode: assessment.actionMode,
                movementKind: assessment.movementKind,
                movementStatus: assessment.movementStatus,
                caseStatus: assessment.caseStatus,
                crystalStatus: assessment.crystalStatus,
                crownStatus: assessment.crownStatus,
                vendorNameSnap: assessment.vendorNameSnap,
                evaluatedByNameSnap: assessment.evaluatedByNameSnap,
                payloadJson: assessment.payloadJson,
                createdAt: assessment.createdAt,
                updatedAt: assessment.updatedAt,
            }
            : null,
        technicalIssues,
        maintenanceRecords,
        catalogs: {
            movementActions,
            crownActions,
            parts,
            appearanceIssues,
            vendors,
        },
        stats: {
            issueCount,
            openIssueCount,
            maintenanceCount: maintenanceRecords.length,
        },
    };
}
