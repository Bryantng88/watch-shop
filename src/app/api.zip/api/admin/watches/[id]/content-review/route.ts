import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";

import { PERMISSIONS } from "@/constants/permissions";
import { requirePermissionApi } from "@/server/auth/requirePermissionApi";
import {
    approveWatchContent,
    rejectWatchContent,
} from "@/domains/watch/server/content";

export const dynamic = "force-dynamic";

const BodySchema = z.object({
    action: z.enum(["approve", "reject"]),
    note: z.string().optional().nullable(),
});

function getAuthUserId(auth: any) {
    return auth?.user?.id ?? auth?.id ?? auth?.userId ?? null;
}

export async function POST(
    req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = BodySchema.parse(await req.json());

        const auth = await requirePermissionApi(
            PERMISSIONS.PRODUCT_CONTENT_REVIEW
        );
        if (auth instanceof Response) return auth;

        const userId = getAuthUserId(auth);

        const content =
            body.action === "approve"
                ? await approveWatchContent({
                    productId: params.id,
                    userId,
                })
                : await rejectWatchContent({
                    productId: params.id,
                    userId,
                    note: body.note,
                });

        return NextResponse.json({
            success: true,
            contentStatus: content.contentStatus,
            reviewNote: content.reviewNote,
        });
    } catch (error: any) {
        return NextResponse.json(
            {
                success: false,
                error: error?.message || "Không thể duyệt content.",
            },
            { status: 400 }
        );
    }
}