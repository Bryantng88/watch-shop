import { NextRequest, NextResponse } from "next/server";
import { indexMediaPrefix } from "@/domains/media/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
    try {
        const result = await indexMediaPrefix({
            profile: req.nextUrl.searchParams.get("profile"),
            prefix: req.nextUrl.searchParams.get("prefix"),
            markMissing: req.nextUrl.searchParams.get("markMissing") === "1",
        });

        return NextResponse.json(result);
    } catch (error: any) {
        console.error("media-browse error", error);
        return NextResponse.json(
            { error: error?.message || "Không thể duyệt thư mục ảnh" },
            { status: 500 }
        );
    }
}
