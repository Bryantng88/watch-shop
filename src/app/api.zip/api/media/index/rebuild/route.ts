import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requirePermissionApi } from "@/server/auth/requirePermissionApi";
import { PERMISSIONS } from "@/constants/permissions";
import { indexMediaPrefix } from "@/domains/media/server";

export const dynamic = "force-dynamic";

const BodySchema = z.object({
    profile: z.string().optional().nullable(),
    prefixes: z.array(z.string()).optional(),
    markMissing: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
    const auth = await requirePermissionApi(PERMISSIONS.PRODUCT_CREATE);
    if (auth instanceof Response) return auth;

    try {
        const body = BodySchema.parse(await req.json().catch(() => ({})));
        const prefixes = body.prefixes?.length ? body.prefixes : [null];

        const results = [];
        for (const prefix of prefixes) {
            results.push(
                await indexMediaPrefix({
                    profile: body.profile,
                    prefix,
                    markMissing: body.markMissing ?? true,
                })
            );
        }

        return NextResponse.json({ success: true, results });
    } catch (error: any) {
        return NextResponse.json(
            { success: false, error: error?.message || "Không thể rebuild media index" },
            { status: 400 }
        );
    }
}
