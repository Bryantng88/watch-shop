import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { ImageRole } from "@prisma/client";
import { requirePermissionApi } from "@/server/auth/requirePermissionApi";
import { PERMISSIONS } from "@/constants/permissions";
import { moveAndTrackMediaAsset } from "@/domains/media/server";

export const dynamic = "force-dynamic";

const BodySchema = z.object({
    fromKey: z.string().min(1),
    toPrefix: z.string().min(1),
    deleteSource: z.boolean().optional(),
    overwrite: z.boolean().optional(),
    productId: z.string().optional().nullable(),
    acquisitionId: z.string().optional().nullable(),
    role: z.nativeEnum(ImageRole).optional().nullable(),
    sortOrder: z.number().optional().nullable(),
});

export async function POST(req: NextRequest) {
    const auth = await requirePermissionApi(PERMISSIONS.PRODUCT_CREATE);
    if (auth instanceof Response) return auth;

    try {
        const body = BodySchema.parse(await req.json());

        const moved = await moveAndTrackMediaAsset({
            fromKey: body.fromKey,
            toPrefix: body.toPrefix,
            deleteSource: body.deleteSource,
            overwrite: body.overwrite,
            productId: body.productId,
            acquisitionId: body.acquisitionId,
            role: body.role,
            sortOrder: body.sortOrder,
            status: body.toPrefix.includes("/chosen") || body.toPrefix.endsWith("chosen") ? "CHOSEN" : undefined,
        });

        return NextResponse.json({
            success: true,
            key: moved.key,
            fromKey: moved.fromKey,
            url: moved.url,
            copied: moved.copied,
            deleted: moved.deleted,
            asset: moved.asset,
        });
    } catch (error: any) {
        return NextResponse.json(
            { error: error?.message || "Move media failed" },
            { status: 400 }
        );
    }
}
