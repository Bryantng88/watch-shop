"use client";

import * as React from "react";
import { ScorePill } from "./primitives";
import { buildTechnicalSummaryForSale } from "./utils";
import { HealthStatus, MachineType } from "./types";

export function CollapsibleDefects({
    title,
    score,
    defects,
}: {
    title: string;
    score: number;
    defects: string[];
}) {
    const [open, setOpen] = React.useState(false);

    return (
        <div className="rounded-2xl border border-slate-200 bg-white">
            <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left"
            >
                <div>
                    <div className="text-sm font-semibold text-slate-900">{title}</div>
                    <div className="mt-1 text-xs text-slate-500">
                        {defects.length > 0 ? `${defects.length} khuyết điểm` : "Không ghi nhận khuyết điểm"}
                    </div>
                </div>

                <div className="flex items-center gap-3">
                    <ScorePill score={score} />
                    <span className="text-sm text-slate-400">{open ? "−" : "+"}</span>
                </div>
            </button>

            {open ? (
                <div className="border-t border-slate-200 px-4 py-4">
                    <div className="flex flex-wrap gap-2">
                        {defects.length > 0 ? (
                            defects.map((item, index) => (
                                <span
                                    key={`${item}-${index}`}
                                    className="inline-flex rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs text-slate-700"
                                >
                                    {item}
                                </span>
                            ))
                        ) : (
                            <span className="text-sm text-slate-500">Không có khuyết điểm được ghi nhận.</span>
                        )}
                    </div>
                </div>
            ) : null}
        </div>
    );
}

export function TechnicalFinalSummary({
    machineIssueTitles,
    appearanceScore,
    appearanceDefects,
    machineStatus,
    machineType,
    afterSpecs,
}: {
    machineIssueTitles: string[];
    appearanceScore: number;
    appearanceDefects: string[];
    machineStatus: HealthStatus;
    machineType: MachineType;
    afterSpecs: { rate: string; amp: string; err: string };
}) {
    const summaryText = buildTechnicalSummaryForSale({
        machineStatus,
        machineIssueTitles,
        appearanceScore,
        appearanceDefects,
        afterSpecs,
        machineType,
    });

    return (
        <div className="space-y-4">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="text-sm font-semibold text-slate-900">Kết quả kỹ thuật gửi sale</div>
                <div className="mt-4 whitespace-pre-line text-sm leading-7 text-slate-700">
                    {summaryText}
                </div>
            </div>
        </div>
    );
}