"use client";

import * as React from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Field, TextInput } from "./primitives";
import { FormState, MachineType } from "./types";

export function MeasurementCompact({
    machineType,
    value,
    onChange,
    disabled,
}: {
    machineType: MachineType;
    value: {
        beforeSpecs: { rate: string; amp: string; err: string };
        afterSpecs: { rate: string; amp: string; err: string };
        showBeforeSpecs: boolean;
    };
    onChange: (patch: Partial<FormState>) => void;
    disabled?: boolean;
}) {
    const [open, setOpen] = React.useState(false);

    if (machineType !== "MECHANICAL") return null;

    const hasAfter =
        value.afterSpecs.rate || value.afterSpecs.amp || value.afterSpecs.err;

    return (
        <div className="rounded-2xl border border-slate-200 bg-white">
            <div className="flex items-center justify-between gap-3 px-4 py-3">
                <div>
                    <div className="text-sm font-semibold text-slate-900">Thông số máy đo</div>
                    <div className="mt-1 text-xs text-slate-500">
                        Rate / Amp / Err sau xử lý. Có thể mở rộng để nhập thông số trước xử lý nếu cần.
                    </div>
                </div>

                <button
                    type="button"
                    onClick={() => setOpen((v) => !v)}
                    className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                    disabled={disabled}
                >
                    {open ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    {open ? "Thu gọn" : hasAfter ? "Sửa thông số" : "Nhập thông số"}
                </button>
            </div>

            {!open ? (
                <div className="grid gap-3 border-t border-slate-100 px-4 py-4 sm:grid-cols-3">
                    <div className="rounded-xl bg-slate-50 px-3 py-3">
                        <div className="text-[11px] uppercase tracking-[0.08em] text-slate-400">Rate</div>
                        <div className="mt-1 text-base font-semibold text-slate-900">
                            {value.afterSpecs.rate || "-"}
                        </div>
                    </div>
                    <div className="rounded-xl bg-slate-50 px-3 py-3">
                        <div className="text-[11px] uppercase tracking-[0.08em] text-slate-400">Amp</div>
                        <div className="mt-1 text-base font-semibold text-slate-900">
                            {value.afterSpecs.amp || "-"}
                        </div>
                    </div>
                    <div className="rounded-xl bg-slate-50 px-3 py-3">
                        <div className="text-[11px] uppercase tracking-[0.08em] text-slate-400">Err</div>
                        <div className="mt-1 text-base font-semibold text-slate-900">
                            {value.afterSpecs.err || "-"}
                        </div>
                    </div>
                </div>
            ) : (
                <div className="space-y-4 border-t border-slate-100 px-4 py-4">
                    <div className="grid gap-4 sm:grid-cols-3">
                        <Field label="Rate">
                            <TextInput
                                value={value.afterSpecs.rate}
                                onChange={(e) =>
                                    onChange({
                                        afterSpecs: { ...value.afterSpecs, rate: e.target.value },
                                    } as Partial<FormState>)
                                }
                                placeholder="+8"
                                disabled={disabled}
                            />
                        </Field>
                        <Field label="Amp">
                            <TextInput
                                value={value.afterSpecs.amp}
                                onChange={(e) =>
                                    onChange({
                                        afterSpecs: { ...value.afterSpecs, amp: e.target.value },
                                    } as Partial<FormState>)
                                }
                                placeholder="248"
                                disabled={disabled}
                            />
                        </Field>
                        <Field label="Err">
                            <TextInput
                                value={value.afterSpecs.err}
                                onChange={(e) =>
                                    onChange({
                                        afterSpecs: { ...value.afterSpecs, err: e.target.value },
                                    } as Partial<FormState>)
                                }
                                placeholder="0.2"
                                disabled={disabled}
                            />
                        </Field>
                    </div>

                    <label className="flex items-center gap-2 text-sm text-slate-600">
                        <input
                            type="checkbox"
                            checked={value.showBeforeSpecs}
                            onChange={(e) => onChange({ showBeforeSpecs: e.target.checked })}
                            disabled={disabled}
                        />
                        Lưu thêm thông số trước xử lý
                    </label>

                    {value.showBeforeSpecs ? (
                        <div className="grid gap-4 sm:grid-cols-3">
                            <Field label="Rate trước xử lý">
                                <TextInput
                                    value={value.beforeSpecs.rate}
                                    onChange={(e) =>
                                        onChange({
                                            beforeSpecs: { ...value.beforeSpecs, rate: e.target.value },
                                        } as Partial<FormState>)
                                    }
                                    disabled={disabled}
                                />
                            </Field>
                            <Field label="Amp trước xử lý">
                                <TextInput
                                    value={value.beforeSpecs.amp}
                                    onChange={(e) =>
                                        onChange({
                                            beforeSpecs: { ...value.beforeSpecs, amp: e.target.value },
                                        } as Partial<FormState>)
                                    }
                                    disabled={disabled}
                                />
                            </Field>
                            <Field label="Err trước xử lý">
                                <TextInput
                                    value={value.beforeSpecs.err}
                                    onChange={(e) =>
                                        onChange({
                                            beforeSpecs: { ...value.beforeSpecs, err: e.target.value },
                                        } as Partial<FormState>)
                                    }
                                    disabled={disabled}
                                />
                            </Field>
                        </div>
                    ) : null}
                </div>
            )}
        </div>
    );
}