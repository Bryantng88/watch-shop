"use client";

import * as React from "react";
import { Lock, Trash2 } from "lucide-react";
import { Button, Field, SelectInput, TextInput } from "./primitives";
import { formatCurrency, parseMoney } from "./utils";
import {
    ExecutionType,
    MachineType,
    MovementAction,
    MovementLine,
} from "./types";

function RowDividerLabel({
    index,
    statusText,
}: {
    index: number;
    statusText?: string;
}) {
    return (
        <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-slate-900">Dòng #{index}</span>
                {statusText ? (
                    <span className="text-xs font-medium text-slate-400">{statusText}</span>
                ) : null}
            </div>
            <div className="h-px flex-1 bg-slate-200" />
        </div>
    );
}

export function IssueRow({
    index,
    title,
    modeLabel,
    costText,
    boardText,
    onOpenBoard,
    readOnly = false,
}: {
    index: number;
    title: string;
    modeLabel?: string;
    costText?: string;
    boardText?: string;
    onOpenBoard?: () => void;
    readOnly?: boolean;
}) {
    const status = String(boardText || "").toUpperCase();

    const tone =
        status.includes("DONE")
            ? "bg-emerald-500"
            : status.includes("PROCESS")
                ? "bg-sky-500"
                : status.includes("CANCELED")
                    ? "bg-slate-300"
                    : "bg-amber-500";

    return (
        <div className="rounded-2xl border border-slate-200 bg-white shadow-[0_1px_2px_rgba(15,23,42,0.04)]">
            <div className="flex items-stretch gap-0">
                <div className={`w-1 rounded-l-2xl ${tone}`} />

                <div className="min-w-0 flex-1 px-4 py-4">
                    <div className="grid gap-3 xl:grid-cols-[140px_minmax(0,1.2fr)_240px_auto] xl:items-center">
                        <div className="min-w-0">
                            <div className="flex items-center gap-2">
                                <Lock className="h-4 w-4 text-slate-400" />
                                <span className="text-sm font-semibold text-slate-900">
                                    Dòng #{index}
                                </span>
                            </div>

                            <div className="mt-2 flex flex-wrap gap-2">
                                <span className="inline-flex rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs text-slate-600">
                                    Issue đã tạo
                                </span>

                                {boardText ? (
                                    <span className="inline-flex rounded-full border border-sky-200 bg-sky-50 px-2.5 py-1 text-xs text-sky-700">
                                        {boardText}
                                    </span>
                                ) : null}
                            </div>
                        </div>

                        <div className="min-w-0">
                            <div className="truncate text-sm font-semibold text-slate-900">
                                {title}
                            </div>
                            {modeLabel ? (
                                <div className="mt-1 truncate text-xs text-slate-500">
                                    {modeLabel}
                                </div>
                            ) : null}
                        </div>

                        <div className="flex flex-wrap gap-2 xl:justify-end">
                            <div className="inline-flex rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700">
                                Chi phí dự kiến:
                                <span className="ml-1 font-semibold text-slate-900">
                                    {costText || "0đ"}
                                </span>
                            </div>
                        </div>

                        <div className="flex items-center xl:justify-end">
                            {!readOnly && onOpenBoard ? (
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={onOpenBoard}
                                    className="whitespace-nowrap"
                                >
                                    Issue Board →
                                </Button>
                            ) : (
                                <span className="text-sm italic text-slate-400">
                                    {status.includes("CANCELED")
                                        ? "Issue đã hủy"
                                        : "Chỉ xem"}
                                </span>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export function StaticIssueSummary({
    lineNo,
    summary,
    boardStatus,
    execution,
    cost,
    vendorName,
    partName,
    actionLabel,
    onGoBoard,
    readOnly = false,
}: {
    lineNo: number;
    summary?: string;
    boardStatus?: string;
    execution?: string;
    cost?: string;
    vendorName?: string;
    partName?: string;
    actionLabel?: string;
    onGoBoard: () => void;
    readOnly?: boolean;
}) {
    const metaParts = [
        actionLabel,
        execution ? (execution === "VENDOR" ? "Vendor" : "Nội bộ") : undefined,
        vendorName ? `Vendor: ${vendorName}` : undefined,
        partName ? `Linh kiện: ${partName}` : undefined,
    ].filter(Boolean) as string[];

    return (
        <IssueRow
            index={lineNo}
            title={summary || "Issue đã được ghi nhận và đang theo dõi tại Issue Board"}
            modeLabel={metaParts.join(" • ")}
            boardText={boardStatus ? `Board: ${boardStatus}` : undefined}
            costText={cost || "0đ"}
            onOpenBoard={onGoBoard}
            readOnly={readOnly || String(boardStatus || "").toUpperCase() === "CANCELED"}
        />
    );
}

export function MovementIssueRow({
    index,
    line,
    machineType,
    parts,
    vendors,
    onChange,
    onRemove,
    canRemove,
    onGoBoard,
    isLocked,
}: {
    index: number;
    line: MovementLine;
    machineType: MachineType;
    parts: any[];
    vendors: any[];
    onChange: (patch: Partial<MovementLine>) => void;
    onRemove: () => void;
    canRemove: boolean;
    onGoBoard: () => void;
    isLocked: boolean;
}) {
    const isVendor = line.execution === "VENDOR";
    const isReplacePart = line.action === "REPLACE_PART";
    const vendorName = vendors.find((v: any) => v.id === line.vendorId)?.name ?? "";
    const partName = parts.find((p: any) => p.id === line.partId)?.name ?? "";

    if (line.isFromBoard) {
        const actionLabelMap: Record<string, string> = {
            SERVICE: "Lau dầu / service máy",
            REPLACE_PART: "Thay linh kiện",
            REGULATE: "Chỉnh sai số / dây tóc",
            WATERPROOF: "Chống nước",
            REPLACE_MOVEMENT: "Thay máy mới",
            BATTERY_CHANGE: "Thay pin",
        };

        return (
            <StaticIssueSummary
                lineNo={index + 1}
                summary={line.summary || (line.action ? actionLabelMap[line.action] || line.action : undefined)}
                boardStatus={line.boardStatus}
                execution={line.execution}
                cost={formatCurrency(parseMoney(line.cost))}
                vendorName={vendorName}
                partName={partName}
                actionLabel={line.action ? actionLabelMap[line.action] || line.action : undefined}
                onGoBoard={onGoBoard}
                readOnly={isLocked}
            />
        );
    }

    return (
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="px-4 pt-4">
                <div className="flex items-center justify-between gap-3">
                    <RowDividerLabel index={index + 1} statusText="Đang soạn" />

                    {canRemove ? (
                        <Button
                            type="button"
                            variant="ghost"
                            className="px-2 text-red-500 hover:bg-red-50 hover:text-red-600"
                            onClick={onRemove}
                        >
                            <Trash2 className="h-4 w-4" />
                        </Button>
                    ) : (
                        <div className="h-8 w-8" />
                    )}
                </div>
            </div>

            <div className="space-y-4 p-4">
                <div className="grid gap-4 md:grid-cols-12">
                    <div className="md:col-span-5">
                        <Field label="Xử lý">
                            <SelectInput
                                value={line.action ?? ""}
                                onChange={(e) =>
                                    onChange({
                                        action: e.target.value as MovementAction,
                                        partId:
                                            e.target.value === "REPLACE_PART"
                                                ? line.partId
                                                : undefined,
                                    })
                                }
                                disabled={isLocked}
                            >
                                <option value="">Chọn xử lý</option>
                                {machineType === "MECHANICAL" ? (
                                    <>
                                        <option value="SERVICE">Lau dầu / service máy</option>
                                        <option value="REPLACE_PART">Thay linh kiện</option>
                                        <option value="REGULATE">Chỉnh sai số / dây tóc</option>
                                        <option value="WATERPROOF">Chống nước</option>
                                        <option value="REPLACE_MOVEMENT">Thay máy mới</option>
                                    </>
                                ) : (
                                    <>
                                        <option value="BATTERY_CHANGE">Thay pin</option>
                                        <option value="REPLACE_PART">Thay linh kiện</option>
                                        <option value="WATERPROOF">Chống nước</option>
                                        <option value="REPLACE_MOVEMENT">Thay máy mới</option>
                                    </>
                                )}
                            </SelectInput>
                        </Field>
                    </div>

                    <div className="md:col-span-4">
                        <Field label="Thực hiện">
                            <SelectInput
                                value={line.execution ?? "INHOUSE"}
                                onChange={(e) =>
                                    onChange({
                                        execution: e.target.value as ExecutionType,
                                        vendorId:
                                            e.target.value === "VENDOR"
                                                ? line.vendorId
                                                : undefined,
                                    })
                                }
                                disabled={isLocked}
                            >
                                <option value="INHOUSE">Nội bộ</option>
                                <option value="VENDOR">Vendor</option>
                            </SelectInput>
                        </Field>
                    </div>

                    <div className="md:col-span-3">
                        <Field label="Chi phí">
                            <TextInput
                                inputMode="numeric"
                                placeholder="0"
                                value={line.cost ?? ""}
                                onChange={(e) => onChange({ cost: e.target.value })}
                                disabled={isLocked}
                            />
                        </Field>
                    </div>
                </div>

                {(isReplacePart || isVendor) ? (
                    <div className="grid gap-4 md:grid-cols-12">
                        {isReplacePart ? (
                            <div className="md:col-start-1 md:col-span-5">
                                <Field label="Linh kiện">
                                    <SelectInput
                                        value={line.partId ?? ""}
                                        onChange={(e) => onChange({ partId: e.target.value })}
                                        disabled={isLocked}
                                    >
                                        <option value="">Chọn linh kiện</option>
                                        {parts.map((part: any) => (
                                            <option key={part.id} value={part.id}>
                                                {part.code ? `${part.code} - ` : ""}{part.name}
                                            </option>
                                        ))}
                                    </SelectInput>
                                </Field>
                            </div>
                        ) : (
                            <div className="hidden md:block md:col-span-5" />
                        )}

                        {isVendor ? (
                            <div className="md:col-start-6 md:col-span-7">
                                <Field label="Vendor">
                                    <SelectInput
                                        value={line.vendorId ?? ""}
                                        onChange={(e) => onChange({ vendorId: e.target.value })}
                                        disabled={isLocked}
                                    >
                                        <option value="">Chọn vendor</option>
                                        {vendors.map((vendor: any) => (
                                            <option key={vendor.id} value={vendor.id}>
                                                {vendor.name}
                                            </option>
                                        ))}
                                    </SelectInput>
                                </Field>
                            </div>
                        ) : null}
                    </div>
                ) : null}
            </div>
        </div>
    );
}