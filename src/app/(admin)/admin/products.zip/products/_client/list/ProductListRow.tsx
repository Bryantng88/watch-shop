"use client";

import Link from "next/link";
import { MoreHorizontal, Pencil } from "lucide-react";
import InlineMoneyEditor from "./InlineMoneyEditor";
import type { ProductRow } from "./types";

type Props = {
  product: ProductRow;
  checked: boolean;
  canViewCost: boolean;
  canEditPrice: boolean;
  onCheckedChange: (checked: boolean) => void;
  onOpenReadiness: (product: ProductRow) => void;
  onPriceSaved: (productId: string, patch: Partial<ProductRow>) => void;
  onPriceCommit: (
    productId: string,
    field: "minPrice" | "salePrice" | "purchasePrice",
    value: number | null
  ) => Promise<void>;
  onView: (productId: string) => void;
  onEdit: (productId: string) => void;
  onDelete: (productId: string) => void;
  onService: (productId: string) => void;
};

function formatMoney(value?: number | null) {
  if (value == null || !Number.isFinite(Number(value))) return "-";
  return Number(value).toLocaleString("vi-VN");
}

function resolveImageSrc(input?: string | null) {
  if (!input) return null;
  if (
    input.startsWith("http://") ||
    input.startsWith("https://") ||
    input.startsWith("data:") ||
    input.startsWith("/api/") ||
    input.startsWith("/")
  ) {
    return input;
  }
  return `/api/media/sign?key=${encodeURIComponent(input)}`;
}

function Dot({
  tone,
}: {
  tone: "green" | "amber" | "red" | "slate";
}) {
  const cls =
    tone === "green"
      ? "bg-emerald-500"
      : tone === "amber"
        ? "bg-amber-500"
        : tone === "red"
          ? "bg-rose-500"
          : "bg-slate-400";

  return <span className={`inline-block h-2 w-2 rounded-full ${cls}`} />;
}

function ReadinessLine({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "green" | "amber" | "red" | "slate";
}) {
  return (
    <div className="flex items-center gap-2 text-sm">
      <Dot tone={tone} />
      <span className="text-slate-500">{label}:</span>
      <span className="font-medium text-slate-800">{value}</span>
    </div>
  );
}

function Thumbnail({ src, alt }: { src?: string | null; alt: string }) {
  const resolved = resolveImageSrc(src);

  if (!resolved) {
    return (
      <div className="h-16 w-16 shrink-0 rounded-2xl bg-slate-100 ring-1 ring-slate-200" />
    );
  }

  return (
    <img
      src={resolved}
      alt={alt}
      className="h-16 w-16 shrink-0 rounded-2xl object-cover ring-1 ring-slate-200"
    />
  );
}

function getServiceLabel(serviceState?: string) {
  switch (serviceState) {
    case "DONE":
      return { text: "Đã sửa xong", tone: "green" as const };
    case "IN_PROGRESS":
      return { text: "Đang service", tone: "amber" as const };
    case "PENDING":
      return { text: "Chờ xử lý", tone: "red" as const };
    default:
      return { text: "Không cần service", tone: "slate" as const };
  }
}

function getReadinessBadge(stage?: string) {
  switch (stage) {
    case "READY":
      return "Sẵn sàng bán";
    case "PROCESSING":
      return "Đang hoàn thiện";
    case "SOLD":
      return "Đã bán";
    default:
      return "Chưa bắt đầu";
  }
}

export default function ProductListRow({
  product,
  checked,
  canViewCost,
  canEditPrice,
  onCheckedChange,
  onPriceSaved,
  onPriceCommit,
}: Props) {
  const thumbnailSrc =
    product.primaryImageUrl ??
    product.primaryImageKey ??
    null;

  const hasContent = Boolean(product.computed?.hasContent);
  const hasImages = Boolean(product.computed?.hasImages);
  const hasSellPrice = Boolean(product.computed?.hasSellPrice);
  const serviceMeta = getServiceLabel(product.computed?.serviceState);
  const readinessLabel = getReadinessBadge(product.computed?.readinessStage);

  return (
    <tr className="border-t border-slate-100 transition hover:bg-slate-50/50">
      <td className="px-4 py-4 align-middle">
        <input
          type="checkbox"
          checked={checked}
          onChange={(e) => onCheckedChange(e.target.checked)}
        />
      </td>

      <td className="px-4 py-4 align-middle">
        <div className="flex items-center gap-4">
          <Thumbnail
            src={thumbnailSrc}
            alt={product.title || "product"}
          />

          <div className="min-w-0 flex-1 self-start">
            <div className="text-[14px] font-medium text-slate-900">
              <span className="line-clamp-2 break-words">
                {product.title || "-"}
              </span>
            </div>

            <div className="mt-1 truncate text-xs text-slate-500">
              {`${(product.brand || "-").toLowerCase()} · ${(product.type || "-").toLowerCase()}`}
            </div>

            {product.variantSnapshot?.sku ? (
              <div className="mt-1 text-xs text-slate-400">
                SKU: {product.variantSnapshot.sku || product.sku}
              </div>
            ) : null}

            <div className="mt-2 text-xs font-medium text-slate-500">
              {readinessLabel}
            </div>
          </div>
        </div>
      </td>

      <td className="px-4 py-4 align-middle">
        <div className="space-y-2">
          <ReadinessLine
            label="Content"
            value={hasContent ? "Đã có" : "Chưa có"}
            tone={hasContent ? "green" : "red"}
          />
          <ReadinessLine
            label="Image"
            value={hasImages ? "Đã có" : "Chưa có"}
            tone={hasImages ? "green" : "red"}
          />
          <ReadinessLine
            label="Service"
            value={serviceMeta.text}
            tone={serviceMeta.tone}
          />
        </div>
      </td>

      <td className="px-4 py-4 align-middle">
        <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-3">
          <div className="space-y-2">
            <InlineMoneyEditor
              label="Bán"
              value={product.minPrice ?? null}
              canEdit={canEditPrice}
              onCommit={(value) => onPriceCommit(product.id, "minPrice", value)}
              onSaved={(value) => onPriceSaved(product.id, { minPrice: value })}
              valueClassName="text-orange-600"
              icon={canEditPrice ? <Pencil className="h-3.5 w-3.5 text-slate-400" /> : null}
            />
            <InlineMoneyEditor
              label="Sale"
              value={product.salePrice ?? null}
              canEdit={canEditPrice}
              onCommit={(value) => onPriceCommit(product.id, "salePrice", value)}
              onSaved={(value) => onPriceSaved(product.id, { salePrice: value })}
              valueClassName="text-slate-700"
            />
            {canViewCost ? (
              <InlineMoneyEditor
                label="Mua"
                value={product.purchasePrice ?? null}
                canEdit={canEditPrice}
                onCommit={(value) => onPriceCommit(product.id, "purchasePrice", value)}
                onSaved={(value) => onPriceSaved(product.id, { purchasePrice: value })}
                valueClassName="text-slate-400"
              />
            ) : null}
          </div>

          <div className="mt-3 border-t border-slate-200 pt-2 text-xs">
            {hasSellPrice ? (
              <span className="font-medium text-emerald-700">Đã có giá bán</span>
            ) : (
              <span className="font-medium text-rose-600">Thiếu giá bán</span>
            )}
          </div>
        </div>
      </td>

      <td className="px-4 py-4 align-middle">
        <div className="space-y-1 text-sm text-slate-700">
          <div>{product.updatedAt ? new Date(product.updatedAt).toLocaleTimeString("vi-VN") : "-"}</div>
          <div>{product.updatedAt ? new Date(product.updatedAt).toLocaleDateString("vi-VN") : "-"}</div>
          <div className="pt-2 text-xs text-slate-400">
            Tạo: {product.createdAt ? new Date(product.createdAt).toLocaleString("vi-VN") : "-"}
          </div>
          <div className="text-xs text-slate-400">
            Vendor: {product.vendorName || "-"}
          </div>
        </div>
      </td>

      <td className="px-4 py-4 align-middle text-right">
        <button
          type="button"
          className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
        >
          <MoreHorizontal className="h-5 w-5" />
        </button>
      </td>
    </tr>
  );
}