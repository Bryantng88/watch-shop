"use client";

import ProductListRow from "./ProductListRow";
import type { Counts, ProductRow } from "./types";

type Props = {
  items: ProductRow[];
  selectedIds: string[];
  canViewCost: boolean;
  counts?: Counts;
  onToggleOne: (id: string, checked: boolean) => void;
  onToggleAll: (checked: boolean) => void;
  onView: (productId: string) => void;
  onEdit: (productId: string) => void;
  onDelete: (productId: string) => void;
  onService: (productId: string) => void;
};

function HeaderStat({
  value,
  label,
  tone = "default",
}: {
  value: number;
  label: string;
  tone?: "default" | "content" | "image";
}) {
  const cls =
    tone === "content"
      ? "text-emerald-700"
      : tone === "image"
        ? "text-sky-700"
        : "text-slate-500";

  return (
    <div className="inline-flex items-center gap-1.5 text-xs">
      <span className={`font-semibold ${cls}`}>{value}</span>
      <span className="text-slate-400">{label}</span>
    </div>
  );
}

export default function ProductListTable({
  items,
  selectedIds,
  canViewCost,
  counts,
  onToggleOne,
  onToggleAll,
  onView,
  onEdit,
  onDelete,
  onService,
}: Props) {
  const allChecked =
    items.length > 0 && items.every((item) => selectedIds.includes(item.id));

  return (
    <div className="rounded-[24px] border border-slate-200 bg-white">
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="text-sm font-semibold text-slate-950">
            Danh sách dữ liệu
          </div>

          <div className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] text-slate-500">
            {items.length} mục
          </div>

          {counts ? (
            <>
              <div className="h-3.5 w-px bg-slate-200" />
              <HeaderStat
                value={counts.hasContent ?? 0}
                label="có content"
                tone="content"
              />
              <HeaderStat
                value={counts.hasImages ?? 0}
                label="có image"
                tone="image"
              />
            </>
          ) : null}
        </div>
      </div>

      <div className="overflow-x-auto overflow-y-visible">
        <table className="min-w-full table-fixed">
          <colgroup>
            <col className="w-12" />
            <col className="w-[34%]" />
            <col className="w-[22%]" />
            <col className="w-[16%]" />
            <col className="w-[20%]" />
            <col className="w-[8%]" />
          </colgroup>

          <thead>
            <tr className="bg-slate-50/80">
              <th className="px-4 py-3 text-left">
                <input
                  type="checkbox"
                  checked={allChecked}
                  onChange={(e) => onToggleAll(e.target.checked)}
                />
              </th>
              <th className="px-4 py-3 text-left text-[12px] font-semibold text-slate-500">
                Sản phẩm
              </th>
              <th className="px-4 py-3 text-left text-[12px] font-semibold text-slate-500">
                Post readiness
              </th>
              <th className="px-4 py-3 text-left text-[12px] font-semibold text-slate-500">
                Pricing
              </th>
              <th className="px-4 py-3 text-left text-[12px] font-semibold text-slate-500">
                Cập nhật
              </th>
              <th className="px-4 py-3 text-right text-[12px] font-semibold text-slate-500">
                Hành động
              </th>
            </tr>
          </thead>

          <tbody>
            {items.map((product) => (
              <ProductListRow
                key={product.id}
                product={product}
                checked={selectedIds.includes(product.id)}
                canViewCost={canViewCost}
                onCheckedChange={(checked) => onToggleOne(product.id, checked)}
                onView={onView}
                onEdit={onEdit}
                onDelete={onDelete}
                onService={onService}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}