import { prisma } from "@/server/db/client";
import { ProductStatus, ProductType, DiscountType, ServiceRequestStatus, ContentStatus } from "@prisma/client";
import * as prodRepo from "./product.repo";
import { generateRuleBasedProductContent } from "../content/product-content.generator";
import { z } from "zod";
import { computeEffectivePrice } from "../../helpers/price";
import { moveMediaObject } from "@/server/lib/media-storage";
import { buildProductListComputed } from "./product-list-computed";
import { MIN_IMAGES, getRequiredWatchSpecFields, hasValue as hasRuleValue } from "../shared/rules";
import { buildSpecBulletsFromProductABC, buildHashtagsFromProduct } from "../shared/helper";

import * as orderService from "../../../orders/_servers/order.service"
import * as acquisitionService from "../../../acquisitions/_server/core/acquisition.service";
import * as serviceRequestService from "../../../services/_server/service_request.service";


const firstValue = (v: unknown) => (Array.isArray(v) ? v[0] : v);

const asDate = (v: unknown) => {
    const raw = firstValue(v);
    if (raw == null || raw === "") return undefined;
    const d = new Date(String(raw));
    return Number.isNaN(d.getTime()) ? undefined : d;
};

const asNumber = (v: unknown) => {
    const raw = firstValue(v);
    if (raw == null || raw === "") return undefined;
    const n = Number(raw);
    return Number.isFinite(n) ? n : undefined;
};

const asString = (v: unknown) => {
    const raw = firstValue(v);
    if (raw == null || raw === "") return undefined;
    return String(raw);
};

const arrayify = (v: unknown): string[] => {
    if (Array.isArray(v)) return v.filter(Boolean).map(String);
    if (v == null || v === "") return [];
    return [String(v)];
};

function normalizeView(v: unknown) {
    const raw = String(firstValue(v) ?? "draft").toLowerCase();

    if (
        raw === "draft" ||
        raw === "processing" ||
        raw === "ready" ||
        raw === "hold" ||
        raw === "sold" ||
        raw === "all"
    ) {
        return raw;
    }

    return "draft";
}

function normalizeCatalog(v: unknown): "product" | "strap" {
    const raw = String(firstValue(v) ?? "product").toLowerCase();
    return raw === "strap" ? "strap" : "product";
}

const AdminListQuerySchema = z.object({
    page: z.coerce.number().min(1).default(1),
    pageSize: z.coerce.number().min(1).max(200).default(50),
    q: z.string().optional(),
    sort: z
        .enum([
            "updatedDesc",
            "updatedAsc",
            "createdDesc",
            "createdAsc",
            "titleAsc",
            "titleDesc",
        ])
        .optional(),
    type: z.array(z.string()).optional(),
    brandIds: z.array(z.string()).optional(),
    categoryIds: z.array(z.string()).optional(),
    hasImages: z.enum(["yes", "no"]).optional(),
    hasContent: z.enum(["yes", "no"]).optional(),
    hasSellPrice: z.enum(["yes", "no"]).optional(),
    serviceState: z
        .enum(["DONE", "IN_PROGRESS", "PENDING", "NOT_REQUIRED"])
        .optional(),
    vendorId: z.string().optional(),
    sku: z.string().optional(),
    updatedFrom: z.date().optional(),
    updatedTo: z.date().optional(),
});

const OPEN_SERVICE_REQUEST_STATUSES = [
    ServiceRequestStatus.DRAFT,
    ServiceRequestStatus.DIAGNOSING,
    ServiceRequestStatus.WAIT_APPROVAL,
    ServiceRequestStatus.IN_PROGRESS,
] as const;

function hasShallowValue(v: unknown) {
    return !(v == null || v === "");
}

function computeMissingVariantFields(item: any): string[] {
    const missing: string[] = [];

    if (!item?.variantId) {
        missing.push("variant");
    }

    if (item?.type === ProductType.WATCH_STRAP) {
        const s = item?.strapSpec ?? null;
        if (!s) return ["strap spec"];
        if (!hasShallowValue(s.material)) missing.push("chất liệu dây");
        if (!hasShallowValue(s.color)) missing.push("màu dây");
        if (!hasShallowValue(s.lugWidthMM)) missing.push("lug width");
        if (!hasShallowValue(s.buckleWidthMM)) missing.push("buckle width");
    }

    return Array.from(new Set(missing));
}

function computeMissingWatchSpecFields(item: any): string[] {
    if (item?.type === ProductType.WATCH_STRAP) return [];
    if (item?.type && item.type !== ProductType.WATCH) return [];

    const ws = item?.watchSpecSnapshot ?? null;
    if (!ws) return ["watch spec"];

    const missing: string[] = [];
    if (!hasShallowValue(ws.caseType)) missing.push("kiểu vỏ");
    if (!hasShallowValue(ws.movement)) missing.push("bộ máy");
    if (!hasShallowValue(ws.caseMaterial)) missing.push("chất liệu vỏ");
    if (!hasShallowValue(ws.strap)) missing.push("loại dây");
    if (!hasShallowValue(ws.glass)) missing.push("kính");

    return Array.from(new Set(missing));
}

function computePublishReadiness(item: any) {
    if (item?.type === ProductType.WATCH_STRAP) {
        const price = Number(item?.variantSnapshot?.price ?? item?.minPrice ?? 0);
        const hasSellableVariant = Number.isFinite(price) && price > 0;
        const missing = [
            Number(item?.imagesCount ?? 0) >= 1 ? null : "images",
            item?.brandId ? null : "brandId",
            hasSellableVariant ? null : "variant",
        ].filter(Boolean) as string[];

        return {
            isReadyToPublish: missing.length === 0,
            publishMissing: missing,
        };
    }

    const imageCount = Number(item?.imagesCount ?? 0);
    const variantPrice = Number(item?.variantSnapshot?.price ?? item?.minPrice ?? 0);
    const variantAvailability = String(item?.variantSnapshot?.availabilityStatus ?? "").toUpperCase();
    const variantStockQty = Number(item?.variantSnapshot?.stockQty ?? 0);
    const hasSellableVariant =
        Number.isFinite(variantPrice) &&
        variantPrice > 0 &&
        (variantAvailability === "ACTIVE" || variantStockQty > 0);

    const missing: string[] = [];

    if (imageCount < MIN_IMAGES) missing.push("images");
    if (!item?.brandId) missing.push("brandId");
    if (!hasSellableVariant) missing.push("variant");

    const ws = item?.watchSpecSnapshot ?? null;
    if (!ws) {
        missing.push("watchSpec");
    } else {
        const missingSpecFields = getRequiredWatchSpecFields(ws)
            .filter((field) => !hasRuleValue((ws as any)?.[field.key]))
            .map((field) => field.label);

        if (missingSpecFields.length) {
            missing.push(...missingSpecFields);
        }
    }

    return {
        isReadyToPublish: missing.length === 0,
        publishMissing: Array.from(new Set(missing)),
    };
}

export async function createProductDraft(title: string) {
    return prisma.$transaction(async (tx) => {
        return prodRepo.createProductDraft(
            tx,
            title,
            ProductType.WATCH,
            1,
            null as any
        );
    });
}



function toHashtagToken(value: unknown) {
    if (value == null) return null;
    const raw = String(value).trim();
    if (!raw) return null;
    const normalized = raw.replace(/[^a-zA-Z0-9]/g, "");
    return normalized ? `#${normalized}` : null;
}

function buildManualSavedContent(
    product: any,
    payload: {
        generatedContent?: string | null;
        promptNote?: string | null;
    }
) {
    const generated = generateRuleBasedProductContent(product);
    const manualLong = String(payload.generatedContent ?? "").trim();
    const skuTag = toHashtagToken(product?.variants?.[0]?.sku);
    const hashtags = Array.from(
        new Set([...(generated.hashtags ?? []), skuTag].filter(Boolean))
    ) as string[];

    const promoteLong = manualLong;
    const promoteShort = manualLong || generated.promoteShort || "";
    const specBullets = generated.specBullets ?? [];
    const promptNote = [
        payload.promptNote ? String(payload.promptNote).trim() : null,
        generated.promptNote,
        skuTag ? `sku=${product?.variants?.[0]?.sku}` : null,
        "source=manual_input",
    ]
        .filter(Boolean)
        .join(" | ");

    return {
        generatedContent: promoteLong,
        promptNote,
        specBullets,
        promoteShort,
        promoteLong,
        facebookCaption: [promoteLong, specBullets.join("\n"), hashtags.join(" ")]
            .filter(Boolean)
            .join("\n\n"),
        instagramCaption: [
            promoteShort,
            specBullets.slice(0, 4).join("\n"),
            hashtags.join(" "),
        ]
            .filter(Boolean)
            .join("\n\n"),
        titleOptions: generated.titleOptions ?? [],
        hashtags,
        missingData: generated.missingData ?? [],
        safetyNotes: generated.safetyNotes ?? [],
    };
}

export async function saveContent(
    id: string,
    payload: {
        generatedContent?: string | null;
        promptNote?: string | null;
        syncSnapshot?: boolean;
    }
) {
    if (payload.syncSnapshot !== false) {
        await prodRepo.syncProductContentSnapshot(prisma, id);
    }

    const product = await prodRepo.getAdminProductDetail(prisma, id);
    if (!product) {
        throw new Error("Không tìm thấy sản phẩm.");
    }

    const specBullets = buildSpecBulletsFromProductABC(product);
    const hashtags = buildHashtagsFromProduct(product);

    const content = await prodRepo.saveProductContent(prisma, id, {
        generatedContent: payload.generatedContent,
        promptNote: payload.promptNote,
        specBullets,
        hashtags,
    });

    const refreshed = await prodRepo.getAdminProductDetail(prisma, id);
    if (!refreshed) {
        throw new Error("Không tìm thấy sản phẩm.");
    }

    return {
        success: true,
        product: {
            id: refreshed.id,
            contentStatus: refreshed.contentStatus,
            postContent: refreshed.postContent ?? null,
            aiPromptUsed: refreshed.aiPromptUsed ?? null,
            aiGeneratedAt: refreshed.aiGeneratedAt?.toISOString?.() ?? null,
            updatedAt: refreshed.updatedAt?.toISOString?.() ?? null,
        },
        content: {
            productId: content.productId,
            titleSnapshot: content.titleSnapshot ?? null,
            brandSnapshot: content.brandSnapshot ?? null,
            refSnapshot: content.refSnapshot ?? null,
            sizeSnapshot: content.sizeSnapshot ?? null,
            movementSnapshot: content.movementSnapshot ?? null,
            glassSnapshot: content.glassSnapshot ?? null,
            strapClaspSnapshot: content.strapClaspSnapshot ?? null,
            modelSnapshot: content.modelSnapshot ?? null,
            yearSnapshot: content.yearSnapshot ?? null,
            generatedContent: content.generatedContent ?? null,
            promptNote: content.promptNote ?? null,
            specBullets: content.specBullets ?? [],
            hashtags: content.hashtags ?? [],
            generatedAt: content.generatedAt?.toISOString?.() ?? null,
            updatedAt: content.updatedAt?.toISOString?.() ?? null,
        },
    };
}
export async function getAdminProductList(
    raw: Record<string, unknown>,
    opts?: { canViewCost?: boolean }
) {
    const parsedResult = AdminListQuerySchema.safeParse({
        page: asNumber(raw.page) ?? 1,
        pageSize: asNumber(raw.pageSize) ?? 50,
        q: asString(raw.q),
        sort: asString(raw.sort),
        type: arrayify(raw.type),
        brandIds: arrayify(raw.brandIds ?? raw.brandId),
        categoryIds: arrayify(raw.categoryIds ?? raw.categoryId),
        hasImages: asString(raw.hasImages),
        hasContent: asString(raw.hasContent),
        hasSellPrice: asString(raw.hasSellPrice),
        serviceState: asString(raw.serviceState),
        vendorId: asString(raw.vendorId),
        sku: asString(raw.sku),
        updatedFrom: asDate(raw.updatedFrom),
        updatedTo: asDate(raw.updatedTo),
    });
    const parsed = parsedResult.success
        ? parsedResult.data
        : {
            page: 1,
            pageSize: 50,
            q: undefined,
            sort: undefined,
            type: undefined,
            brandIds: undefined,
            categoryIds: undefined,
            hasImages: undefined,
            hasContent: undefined,
            hasSellPrice: undefined,
            serviceState: undefined,
            vendorId: undefined,
            sku: undefined,
            updatedFrom: undefined,
            updatedTo: undefined,
        };
    const catalog = normalizeCatalog(raw.catalog);
    const view = normalizeView(raw.view);

    const result = await prodRepo.listAdminProducts(prisma, {
        q: parsed.q,
        sort: parsed.sort as any,
        page: parsed.page,
        pageSize: parsed.pageSize,
        view: view as any,
        type: parsed.type?.[0],
        brandId: parsed.brandIds?.[0],
        categoryId: parsed.categoryIds?.[0],
        vendorId: parsed.vendorId,
        sku: parsed.sku,
        hasImages: parsed.hasImages,
        hasContent: parsed.hasContent,
        hasSellPrice: parsed.hasSellPrice,
        serviceState: parsed.serviceState,
        catalog,
        includeCost: !!opts?.canViewCost,
    });

    const itemIds = (result.items ?? [])
        .map((item: any) => item.id)
        .filter(Boolean);

    const latestServices = itemIds.length
        ? await prisma.serviceRequest.findMany({
            where: {
                productId: { in: itemIds },
            },
            orderBy: [{ updatedAt: "desc" }, { createdAt: "desc" }],
            select: {
                productId: true,
                status: true,
            },
        })
        : [];

    const latestServiceMap = new Map<string, string>();
    const openServiceMap = new Map<string, string>();

    for (const row of latestServices) {
        if (!row.productId) continue;

        if (!latestServiceMap.has(row.productId)) {
            latestServiceMap.set(row.productId, String(row.status));
        }

        if (
            !openServiceMap.has(row.productId) &&
            OPEN_SERVICE_REQUEST_STATUSES.includes(row.status as any)
        ) {
            openServiceMap.set(row.productId, String(row.status));
        }
    }

    const items = (result.items ?? []).map((item: any) => {
        const hasOpenService = openServiceMap.has(item.id);
        const openServiceStatus = openServiceMap.get(item.id) ?? null;
        const latestServiceStatus = latestServiceMap.get(item.id) ?? null;

        const imageCount = Number(item?.imagesCount ?? item?._count?.image ?? 0);

        const basePrice = Number(
            item?.salePrice ??
            item?.minPrice ??
            item?.variantSnapshot?.salePrice ??
            item?.variantSnapshot?.price ??
            0
        );

        const computed = buildProductListComputed({
            productStatus: item?.status,
            contentStatus: item?.contentStatus,
            postContent: item?.postContent,
            imageCount,
            salePrice: item?.salePrice,
            basePrice,
            hasOpenService,
            latestServiceStatus,
            needService:
                item?.status === ProductStatus.NEED_SERVICE ||
                item?.status === ProductStatus.IN_SERVICE,
        });

        return {
            ...item,
            hasOpenService,
            openServiceStatus,
            latestServiceStatus,
            computed,
        };
    });
    return {
        ...result,
        items,
        page: parsed.page,
        pageSize: parsed.pageSize,
    };
}
export async function updateProduct(
    id: string,
    patch: {
        title?: string;
        categoryId?: string | null;
        minPrice?: number | null;
        listPrice?: number | null;
        discountType?: DiscountType | null;
        discountValue?: number | null;
        salePrice?: number | null;
        saleStartsAt?: Date | null;
        saleEndsAt?: Date | null;
        purchasePrice?: number | null;
        primaryImageUrl?: string | null;
        status?: string;
        priceVisibility?: "SHOW" | "HIDE";
        availabilityStatus?: "ACTIVE" | "HIDDEN";
    }
) {
    return prisma.$transaction(async (tx) => {


        const current = await prodRepo.getLatestVariantForAdmin(tx, id);
        if (!current) {
            throw new Error("Không tìm thấy product.");
        }

        const variant = await prodRepo.getLatestVariantForAdmin(tx, id);
        if (!variant) {
            throw new Error("Không tìm thấy variant của product.");
        }

        const currentList =
            variant.listPrice != null
                ? Number(variant.listPrice)
                : Number(variant.price ?? 0);

        const nextListPrice =
            patch.listPrice !== undefined
                ? patch.listPrice
                : patch.minPrice !== undefined
                    ? patch.minPrice
                    : currentList;

        const nextDiscountType =
            patch.discountType !== undefined ? patch.discountType : (variant.discountType ?? null);

        const nextDiscountValue =
            patch.discountValue !== undefined
                ? patch.discountValue
                : variant.discountValue != null
                    ? Number(variant.discountValue)
                    : null;

        const nextSalePrice =
            patch.salePrice !== undefined
                ? patch.salePrice
                : variant.salePrice != null
                    ? Number(variant.salePrice)
                    : null;

        const nextSaleStartsAt =
            patch.saleStartsAt !== undefined ? patch.saleStartsAt : (variant.saleStartsAt ?? null);

        const nextSaleEndsAt =
            patch.saleEndsAt !== undefined ? patch.saleEndsAt : (variant.saleEndsAt ?? null);

        const nextCostPrice =
            patch.purchasePrice !== undefined
                ? patch.purchasePrice
                : variant.costPrice != null
                    ? Number(variant.costPrice)
                    : null;
        const shouldTouchPricing =
            patch.minPrice !== undefined ||
            patch.listPrice !== undefined ||
            patch.discountType !== undefined ||
            patch.discountValue !== undefined ||
            patch.salePrice !== undefined ||
            patch.saleStartsAt !== undefined ||
            patch.saleEndsAt !== undefined ||
            patch.purchasePrice !== undefined ||
            patch.availabilityStatus !== undefined;

        if (shouldTouchPricing) {
            const effectivePrice = computeEffectivePrice({
                listPrice: nextListPrice,
                discountType: nextDiscountType,
                discountValue: nextDiscountValue,
                salePrice: nextSalePrice,
                saleStartsAt: nextSaleStartsAt,
                saleEndsAt: nextSaleEndsAt,
                fallbackPrice: variant?.price,
            });

            await prodRepo.updatePrimaryVariantPricing(tx, id, {
                price: effectivePrice,
                listPrice: nextListPrice,
                discountType: nextDiscountType,
                discountValue: nextDiscountValue,
                salePrice: nextSalePrice,
                saleStartsAt: nextSaleStartsAt,
                saleEndsAt: nextSaleEndsAt,
                costPrice: nextCostPrice,
                ...(patch.availabilityStatus ? { availabilityStatus: patch.availabilityStatus as any } : {}),
            } as any);
        }

        const data: any = {};
        if (patch.title !== undefined) data.title = patch.title;
        if (patch.categoryId !== undefined) data.categoryId = patch.categoryId || null;
        if (patch.primaryImageUrl !== undefined) data.primaryImageUrl = patch.primaryImageUrl;
        if (patch.status !== undefined) data.status = patch.status;
        if (patch.priceVisibility !== undefined) data.priceVisibility = patch.priceVisibility;

        return prodRepo.updateProduct(tx, id, data);
    });
}

export async function remove(id: string) {
    return prisma.$transaction(async (tx) => {
        const product = await tx.product.findUnique({
            where: { id },
            select: {
                id: true,
                title: true,
                _count: {
                    select: {
                        AcquisitionItem: true,
                        orderItems: true,
                        InvoiceItem: true,
                        ServiceRequest: true,
                        maintenanceRecords: true,
                        Reservation: true,
                    },
                },
            },
        });

        if (!product) {
            throw new Error("Không tìm thấy sản phẩm");
        }

        if (product._count.AcquisitionItem > 0) {
            throw new Error(
                `Sản phẩm "${product.title}" được tạo hoặc liên kết từ phiếu nhập, không thể xóa trực tiếp. Hãy điều chỉnh tại phiếu nhập.`
            );
        }

        const blockers = [
            product._count.orderItems > 0 ? "đơn hàng" : null,
            product._count.InvoiceItem > 0 ? "hóa đơn" : null,
            product._count.ServiceRequest > 0 ? "phiếu service" : null,
            product._count.maintenanceRecords > 0 ? "maintenance log" : null,
            product._count.Reservation > 0 ? "reservation" : null,
        ].filter(Boolean);

        if (blockers.length > 0) {
            throw new Error(
                `Sản phẩm "${product.title}" đã phát sinh ${blockers.join(", ")}, không thể xóa trực tiếp.`
            );
        }

        await prodRepo.deleteProduct(tx, id);
        return { success: true };
    });
}

export async function searchProductService(q: string) {
    return prisma.$transaction(async (tx) => {
        return prodRepo.searchProductsRepo(tx, q);
    });
}

export type BulkPostProductsResult = {
    count: number;
    postedIds: string[];
    failed: Array<{
        id: string;
        title?: string | null;
        reasons: string[];
    }>;
};

function toNumberPrice(v: unknown): number {
    if (v == null) return 0;
    if (typeof v === "number") return v;

    const anyV = v as any;
    if (typeof anyV?.toNumber === "function") return anyV.toNumber();

    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
}

function hasPrice(p: { minPrice: unknown }) {
    return toNumberPrice(p.minPrice) > 0;
}

function hasImage(p: { primaryImageUrl: string | null }) {
    return !!p.primaryImageUrl && p.primaryImageUrl.trim().length > 0;
}

export async function bulkPostProducts(productIds: string[]): Promise<BulkPostProductsResult> {
    const ids = Array.from(new Set((productIds ?? []).filter(Boolean)));

    if (!ids.length) {
        return { count: 0, postedIds: [], failed: [] };
    }

    return prisma.$transaction(async (tx) => {
        const rows = await prodRepo.getProductsForBulkPost(tx, ids);

        const found = new Set(rows.map((x) => x.id));
        const notFound = ids.filter((id) => !found.has(id));

        const failed: BulkPostProductsResult["failed"] = [];

        for (const id of notFound) {
            failed.push({ id, title: null, reasons: ["NOT_FOUND"] });
        }

        const eligibleIds: string[] = [];

        for (const p of rows as Array<any>) {
            const reasons: string[] = [];

            if (p.contentStatus !== ContentStatus.DRAFT) {
                reasons.push(`STATUS_NOT_ALLOWED:${p.contentStatus}`);
            }
            if (!hasPrice(p)) reasons.push("MISSING_PRICE");
            if (!hasImage(p)) reasons.push("MISSING_IMAGE");

            if (reasons.length) {
                failed.push({ id: p.id, title: p.title ?? null, reasons });
            } else {
                eligibleIds.push(p.id);
            }
        }

        if (eligibleIds.length) {
            await prodRepo.markPostedMany(tx, eligibleIds);
        }

        return {
            count: eligibleIds.length,
            postedIds: eligibleIds,
            failed,
        };
    });
}


export async function detail(id: string) {
    const [product, serviceHistory, tradeHistory] = await Promise.all([
        prodRepo.getAdminProductDetail(prisma, id),
        prodRepo.getProductServiceHistory(prisma, id),
        prodRepo.getProductTradeHistory(prisma, id),
    ]);

    if (!product) return null;

    return {
        product: {
            ...product,
            createdAt: product.createdAt?.toISOString?.() ?? null,
            updatedAt: product.updatedAt?.toISOString?.() ?? null,
            aiGeneratedAt: product.aiGeneratedAt?.toISOString?.() ?? null,
            publishedAt: product.publishedAt?.toISOString?.() ?? null,
            content: product.content
                ? {
                    ...product.content,
                    generatedAt: product.content.generatedAt?.toISOString?.() ?? null,
                    createdAt: product.content.createdAt?.toISOString?.() ?? null,
                    updatedAt: product.content.updatedAt?.toISOString?.() ?? null,
                }
                : null,
            watchSpec: product.watchSpec
                ? {
                    ...product.watchSpec,
                    length: product.watchSpec.length != null ? Number(product.watchSpec.length) : null,
                    width: product.watchSpec.width != null ? Number(product.watchSpec.width) : null,
                    thickness: product.watchSpec.thickness != null ? Number(product.watchSpec.thickness) : null,
                    createdAt: product.watchSpec.createdAt?.toISOString?.() ?? null,
                    updatedAt: product.watchSpec.updatedAt?.toISOString?.() ?? null,
                }
                : null,
            image: (product.image ?? []).map((img: any) => ({
                ...img,
                createdAt: img.createdAt?.toISOString?.() ?? null,
                updatedAt: img.updatedAt?.toISOString?.() ?? null,
            })),
            variants: (product.variants ?? []).map((variant: any) => ({
                ...variant,
                price: variant.price != null ? Number(variant.price) : null,
                listPrice: variant.listPrice != null ? Number(variant.listPrice) : null,
                discountValue: variant.discountValue != null ? Number(variant.discountValue) : null,
                salePrice: variant.salePrice != null ? Number(variant.salePrice) : null,
                costPrice: variant.costPrice != null ? Number(variant.costPrice) : null,
                saleStartsAt: variant.saleStartsAt?.toISOString?.() ?? null,
                saleEndsAt: variant.saleEndsAt?.toISOString?.() ?? null,
                createdAt: variant.createdAt?.toISOString?.() ?? null,
                updatedAt: variant.updatedAt?.toISOString?.() ?? null,
                acquisitionItem: (variant.acquisitionItem ?? []).map((item: any) => ({
                    ...item,
                    unitCost: item.unitCost != null ? Number(item.unitCost) : null,
                    acquisition: item.acquisition ? { ...item.acquisition, acquiredAt: item.acquisition.acquiredAt?.toISOString?.() ?? null } : null,
                })),
            })),
        },
        serviceHistory,
        tradeHistory,
    };
}

export async function quickOrderProduct(input: {
    productId: string;
    customerName: string;
    customerId?: string | null;
    listPrice?: number | null;
    unitPriceAgreed?: number | null;
    notes?: string | null;
}) {
    return prisma.$transaction(async (tx) => {
        const product = await prodRepo.getAdminProductRow(tx as any, input.productId);
        if (!product) throw new Error("Không tìm thấy sản phẩm");

        const status = String(product.status || "").toUpperCase();
        if (status === "SOLD") {
            throw new Error("Sản phẩm đã SOLD, không thể tạo quick order");
        }
        if (status === "CONSIGNED_TO") {
            throw new Error("Sản phẩm đang consign đi, không thể tạo quick order");
        }

        const order = await orderService.createQuickOrderFromProduct({
            productId: input.productId,
            customerName: input.customerName,
            customerId: input.customerId ?? null,
            listPrice: input.listPrice ?? null,
            unitPriceAgreed: input.unitPriceAgreed ?? null,
            notes: input.notes ?? null,
        });

        return order;
    });
}

export async function buyBackProduct(input: {
    productId: string;
    unitCost: number;
    notes?: string | null;
    customerId?: string | null;
    needService?: boolean;
}) {
    const result = await acquisitionService.createBuyBackFromProduct({
        productId: input.productId,
        unitCost: Number(input.unitCost ?? 0),
        notes: input.notes ?? null,
        customerId: input.customerId ?? null,
        needService: Boolean(input.needService),
    });

    if (input.needService) {
        await serviceRequestService.ensurePriorityTechnicalCheckForBuyBack({
            productId: input.productId,
            reason: "Buy back cần kiểm tra lại",
            source: "BUY_BACK",
        });
    }

    return result;
}

export async function consignToProduct(input: {
    productId: string;
    vendorId: string;
    notes?: string | null;
}) {
    return acquisitionService.createConsignToFromProduct({
        productId: input.productId,
        vendorId: input.vendorId,
        notes: input.notes ?? null,
    });
}


export async function setStorefrontImage(productId: string, fileKey: string) {
    const rawKey = String(fileKey ?? "").trim();
    if (!rawKey) {
        throw new Error("Thiếu fileKey ảnh đại diện bán hàng.");
    }

    return prisma.$transaction(async (tx) => {
        const product = await tx.product.findUnique({
            where: { id: productId },
            select: { id: true, storefrontImageKey: true },
        });

        if (!product) {
            throw new Error("Không tìm thấy sản phẩm.");
        }

        let finalKey = rawKey;

        if (rawKey.startsWith("product/storefront/active/")) {
            const moved = await moveMediaObject({
                fromKey: rawKey,
                toPrefix: "product/storefront/chosen",
                deleteSource: true,
                overwrite: false,
            });

            finalKey = moved.key;
        }

        const saved = await prodRepo.setProductStorefrontImage(tx, productId, finalKey);

        return {
            ...saved,
            storefrontImageUrl: finalKey
                ? `/api/media/sign?key=${encodeURIComponent(finalKey)}`
                : null,
        };
    });
}