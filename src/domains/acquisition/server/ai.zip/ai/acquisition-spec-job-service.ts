"use server";

import { Prisma } from "@prisma/client";
import { genUniqueAcquisitionSku } from "@/domains/acquisition/shared/sku.helper";
import { generateAcquisitionSpec } from "./generate-acquisition-spec";
import { mapWatchSpecFromAi } from "./map-watch-spec-from-ai";

function getImages(aiMeta: any): string[] {
    return (aiMeta?.images ?? [])
        .map((x: any) => x?.url)
        .filter((x: unknown): x is string => typeof x === "string" && !!x);
}

function stringifyAcquisitionItemMeta(input: unknown) {
    return JSON.stringify(input ?? {});
}

function buildProductTitleFromWatchAi(input: {
    brand?: string | null;
    extractedSpec?: {
        model?: string | null;
        ref?: string | null;
    } | null;
    fallback?: string | null;
}) {
    const parts = [
        input.brand?.trim(),
        input.extractedSpec?.model?.trim(),
        input.extractedSpec?.ref?.trim(),
    ].filter(Boolean);

    return parts.length ? parts.join(" ") : (input.fallback ?? "").trim();
}

export async function enqueueAcquisitionSpecJob(
    tx: Prisma.TransactionClient,
    input: {
        acquisitionItemId: string;
        productId: string;
    }
) {
    await tx.acquisitionSpecJob.upsert({
        where: { acquisitionItemId: input.acquisitionItemId },
        update: { status: "PENDING" },
        create: {
            acquisitionItemId: input.acquisitionItemId,
            productId: input.productId,
            status: "PENDING",
        },
    });
}

export async function processAcquisitionSpecJob(
    tx: Prisma.TransactionClient,
    input: {
        acquisitionItemId: string;
    }
) {
    const item = await tx.acquisitionItem.findUnique({
        where: { id: input.acquisitionItemId },
        include: {
            product: {
                include: {
                    brand: true,
                },
            },
            acquisition: true,
        },
    });

    if (!item || !item.productId || !item.product) {
        throw new Error("Acquisition item or product not found");
    }

    const meta =
        typeof item.description === "string" && item.description
            ? safeJsonParse(item.description)
            : {};

    const aiMeta = (meta as any)?.aiMeta ?? {};
    const images = getImages(aiMeta);

    const brand = item.product.brand;

    const ai = await generateAcquisitionSpec({
        title: item.productTitle ?? item.product.title,
        brand: brand?.name ?? null,
        model: null,
        notes: item.notes ?? item.acquisition?.notes ?? null,
        condition: item.condition ?? item.acquisition?.condition ?? null,
        images,
    });

    const spec = mapWatchSpecFromAi(ai.extractedSpec);

    if (!item.product.sku) {
        const generatedSku = await genUniqueAcquisitionSku(tx as any, {
            brandCode: brand?.code ?? brand?.name ?? null,
            categoryCode: "WATCH",
            year: ai.extractedSpec?.year ?? new Date().getFullYear(),
        });

        await tx.product.update({
            where: { id: item.productId },
            data: {
                sku: generatedSku,
            },
        });
    }

    await tx.product.update({
        where: { id: item.productId },
        data: {
            title: buildProductTitleFromWatchAi({
                brand: brand?.name,
                extractedSpec: ai.extractedSpec,
                fallback: item.productTitle ?? item.product.title,
            }),
        },
    });

    await tx.watchSpec.upsert({
        where: { productId: item.productId },
        create: {
            productId: item.productId,
            ...spec,
        },
        update: {
            ...spec,
        },
    });

    await tx.acquisitionItem.update({
        where: { id: item.id },
        data: {
            description: stringifyAcquisitionItemMeta({
                ...meta,
                aiMeta: {
                    ...(meta as any)?.aiMeta,
                    ai,
                },
            }),
        },
    });

    await tx.acquisitionSpecJob.update({
        where: { acquisitionItemId: item.id },
        data: {
            status: "DONE",
            processedAt: new Date(),
        },
    });
}

function safeJsonParse(value: string) {
    try {
        return JSON.parse(value);
    } catch {
        return {};
    }
}