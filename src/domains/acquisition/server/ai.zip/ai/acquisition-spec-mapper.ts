function s(v: any) {
    const t = String(v ?? "").trim();
    return t || null;
}

function n(v: any) {
    const x = Number(v);
    return Number.isFinite(x) ? x : null;
}

function mapMovement(v: any) {
    const t = s(v)?.toLowerCase();
    if (!t) return null;
    if (t.includes("quartz")) return "QUARTZ";
    if (t.includes("auto")) return "AUTOMATIC";
    if (t.includes("manual")) return "HAND_WOUND";
    return null;
}

function mapGlass(v: any) {
    const t = s(v)?.toLowerCase();
    if (!t) return null;
    if (t.includes("sapphire")) return "SAPPHIRE";
    if (t.includes("mineral")) return "MINERAL";
    if (t.includes("plexi")) return "ACRYLIC";
    return null;
}

export function mapWatchSpecFromAi(ex: any) {
    const p = ex?.probableVisualFacts ?? {};

    return {
        ref: s(ex?.bestRefCandidate),
        model: s(ex?.modelFamily),
        caliber: s(ex?.bestCaliberCandidate),
        year: s(ex?.yearEstimate),

        movement: mapMovement(ex?.movement) ?? mapMovement(p?.movement),
        caseType: s(ex?.caseType) ?? s(p?.caseType),
        caseMaterial: s(ex?.caseMaterial) ?? s(p?.caseMaterial),
        dialColor: s(ex?.dialColor) ?? s(p?.dialColor),
        glass: mapGlass(ex?.glass) ?? mapGlass(p?.glass),

        width: n(ex?.widthEstimateMm) ?? n(p?.widthEstimateMm),
    };
}

export function buildProductTitleFromWatchAi(input: {
    brand?: string | null;
    extractedSpec?: any;
    fallback?: string | null;
}) {
    const parts = [
        input.brand,
        s(input.extractedSpec?.modelFamily),
        s(input.extractedSpec?.bestRefCandidate),
    ].filter(Boolean);

    return parts.length ? parts.join(" ") : input.fallback ?? "Watch";
}