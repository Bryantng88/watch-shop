import OpenAI from "openai";

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

export type GenerateAcquisitionSpecInput = {
    title?: string | null;
    brand?: string | null;
    model?: string | null;
    notes?: string | null;
    condition?: string | null;
    images?: string[];
};

export type GenerateAcquisitionSpecResult = {
    extractedSpec?: {
        ref?: string | null;
        model?: string | null;
        caliber?: string | null;
        year?: string | null;
        movement?: string | null;
        caseType?: string | null;
        caseMaterial?: string | null;
        dialColor?: string | null;
        glass?: string | null;
        width?: number | null;
    };
    summary?: string | null;
};

type InputContentItem =
    | { type: "input_text"; text: string }
    | { type: "input_image"; image_url: string };

function buildPrompt(input: GenerateAcquisitionSpecInput) {
    return `
Bạn là chuyên gia đọc thông tin đồng hồ từ ảnh và dữ liệu đầu vào.

Hãy trích xuất thông tin theo JSON với format:
{
  "extractedSpec": {
    "ref": string | null,
    "model": string | null,
    "caliber": string | null,
    "year": string | null,
    "movement": string | null,
    "caseType": string | null,
    "caseMaterial": string | null,
    "dialColor": string | null,
    "glass": string | null,
    "width": number | null
  },
  "summary": string | null
}

Chỉ trả JSON hợp lệ, không thêm markdown.

Input:
- title: ${input.title ?? ""}
- brand: ${input.brand ?? ""}
- model: ${input.model ?? ""}
- notes: ${input.notes ?? ""}
- condition: ${input.condition ?? ""}
`.trim();
}

export async function generateAcquisitionSpec(
    input: GenerateAcquisitionSpecInput
): Promise<GenerateAcquisitionSpecResult> {
    const images = (input.images ?? []).filter(
        (x): x is string => typeof x === "string" && x.trim().length > 0
    );

    const content: InputContentItem[] = [
        {
            type: "input_text",
            text: buildPrompt(input),
        },
        ...images.map(
            (url): InputContentItem => ({
                type: "input_image",
                image_url: url,
            })
        ),
    ];

    const res = await openai.responses.create({
        model: "gpt-4.1-mini",
        input: [
            {
                role: "user",
                content,
            },
        ],
    });

    const text = res.output_text?.trim() || "{}";

    try {
        return JSON.parse(text) as GenerateAcquisitionSpecResult;
    } catch {
        return {};
    }
}