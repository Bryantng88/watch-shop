"use client";

import { ArrowLeftRight } from "lucide-react";
import { SectionCard, SectionEmpty, fmtDate, fmtMoney } from "./shared";

type Props = {
  tradeHistory?: any;
  canViewTradeFinancials?: boolean;
};

type TimelineRow = {
  id: string;
  date: any;
  amount: any;
  text: string;
  tone: "buy" | "sell" | "buyback";
};

function normalizeTradeHistory(tradeHistory: any) {
  if (Array.isArray(tradeHistory)) {
    return {
      acquisitions: tradeHistory.filter(
        (x) =>
          String(x?.type ?? x?.kind ?? "")
            .toUpperCase()
            .includes("ACQUISITION") ||
          x?.acquisitionId ||
          x?.unitCost,
      ),
      orders: tradeHistory.filter(
        (x) =>
          String(x?.type ?? x?.kind ?? "")
            .toUpperCase()
            .includes("ORDER") ||
          x?.orderId ||
          x?.salePrice,
      ),
    };
  }

  return {
    acquisitions: Array.isArray(tradeHistory?.acquisitions)
      ? tradeHistory.acquisitions
      : [],
    orders: Array.isArray(tradeHistory?.orders) ? tradeHistory.orders : [],
  };
}

function getAcquisitionParty(item: any) {
  if (String(item?.acquisitionType ?? "").toUpperCase() === "BUY_BACK") {
    return (
      item.customer?.name ||
      item.customerName ||
      item.orderCustomerName ||
      "khách"
    );
  }

  return item.vendor?.name || item.vendorName || "nguồn nhập";
}

function getOrderParty(item: any) {
  return item.customer?.name || item.customerName || "khách";
}

function buildTimeline(tradeHistory: any): TimelineRow[] {
  const { acquisitions, orders } = normalizeTradeHistory(tradeHistory);

  const acquisitionRows: TimelineRow[] = acquisitions.map((item: any, index: number) => {
    const acquisitionType = String(item?.acquisitionType ?? "").toUpperCase();
    const isBuyBack = acquisitionType === "BUY_BACK";

    return {
      id: `acq-${item.id ?? index}`,
      date: item.createdAt ?? item.updatedAt,
      amount: item.amount ?? item.unitCost ?? item.costPrice,
      text: isBuyBack
        ? `Mua lại từ ${getAcquisitionParty(item)}`
        : `Mua từ ${getAcquisitionParty(item)}`,
      tone: isBuyBack ? "buyback" : "buy",
    };
  });

  const orderRows: TimelineRow[] = orders.map((item: any, index: number) => ({
    id: `order-${item.id ?? index}`,
    date: item.createdAt ?? item.updatedAt,
    amount: item.amount ?? item.salePrice ?? item.totalAmount,
    text: `Bán cho ${getOrderParty(item)}`,
    tone: "sell",
  }));

  return [...acquisitionRows, ...orderRows].sort((a, b) => {
    const timeA = new Date(a.date ?? 0).getTime();
    const timeB = new Date(b.date ?? 0).getTime();
    return timeA - timeB;
  });
}

function dotClass(tone: TimelineRow["tone"]) {
  if (tone === "sell") return "bg-emerald-500";
  if (tone === "buyback") return "bg-orange-500";
  return "bg-blue-500";
}

export default function WatchTradePanel({
  tradeHistory,
  canViewTradeFinancials = false,
}: Props) {
  const timeline = buildTimeline(tradeHistory);

  return (
    <SectionCard
      title="Lịch sử giao dịch"
      subtitle="Theo dõi vòng đời mua vào, bán ra và mua lại của watch."
      icon={<ArrowLeftRight className="h-5 w-5" />}
      defaultOpen
    >
      {timeline.length === 0 ? (
        <SectionEmpty text="Chưa có lịch sử nhập/bán cho watch này." />
      ) : (
        <div className="relative space-y-0 pl-6">
          <div className="absolute left-[11px] top-4 bottom-4 w-px bg-slate-200" />

          {timeline.map((row, index) => (
            <div key={row.id} className="relative pb-5 last:pb-0">
              <div className="absolute left-[-21px] top-1.5 h-3 w-3 rounded-full border-2 border-white bg-slate-900 shadow ring-4 ring-slate-100" />

              <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-950">
                      {row.text}
                    </div>
                    <div className="mt-1 text-xs text-slate-500">
                      {fmtDate(row.date)}
                    </div>
                  </div>

                  {canViewTradeFinancials ? (
                    <div className="shrink-0 text-sm font-semibold text-slate-950">
                      {fmtMoney(row.amount)}
                    </div>
                  ) : null}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </SectionCard>
  );
}