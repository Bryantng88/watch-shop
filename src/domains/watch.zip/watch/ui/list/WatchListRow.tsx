"use client";

import Image from "next/image";
import type { WatchRow } from "./types";
import RowActionMenu from "@/app/(admin)/admin/__components/RowActionMenu"
import { pickWatchInlineImage } from "../../server/shared/watch-image";
import { resolveMediaPreviewSrc } from "@/lib/media-profile";
type Props = {
    item: WatchRow;
    checked: boolean;
    onCheckedChange: (checked: boolean) => void;

    canViewCost: boolean;
    canEditPrice: boolean;

    // 👇 GIỮ LẠI ACTION
    onView: (productId: string) => void;
    onEdit: (productId: string) => void;
    onDelete: (productId: string) => void;
    onService: (productId: string) => void;
    onConsign?: (productId: string) => void;
    onQuickOrder?: (productId: string) => void;
};
export default function WatchListRow({
    item,
    checked,
    onCheckedChange,
    canViewCost,
    canEditPrice,
    onView,
    onEdit,
    onDelete,
    onService,
    onConsign,
    onQuickOrder,
}: Props) {
    const image = pickWatchInlineImage(item.images ?? []);
    const imageSrc = resolveMediaPreviewSrc(image?.fileKey || image?.url || null);

    return (
        <tr className="border-t hover:bg-gray-50 transition">
            <td className="px-4 py-3 align-middle">
                <input
                    type="checkbox"
                    checked={checked}
                    onChange={(e) => onCheckedChange(e.target.checked)}
                />
            </td>

            <td className="px-4 py-3 align-middle">
                <div className="flex items-center gap-3 min-w-[220px]">
                    <div className="w-12 h-12 rounded-md overflow-hidden border bg-gray-100 flex-shrink-0">
                        {imageSrc ? (
                            <Image
                                src={imageSrc}
                                alt={item.title || ""}
                                width={48}
                                height={48}
                                className="w-full h-full object-cover"
                            />
                        ) : (
                            <div className="flex items-center justify-center h-full text-xs text-gray-400">
                                No image
                            </div>
                        )}
                    </div>

                    <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{item.title || "—"}</div>
                        <div className="text-xs text-gray-400">{item.sku || "—"}</div>
                    </div>
                </div>
            </td>

            <td className="px-4 py-3 text-sm align-middle">
                {item.hasContent && item.hasImages ? (
                    <span className="text-green-600 font-medium">Ready</span>
                ) : (
                    <span className="text-gray-400">Chưa đủ</span>
                )}
            </td>

            <td className="px-4 py-3 text-sm align-middle">
                <div className="flex flex-col">
                    <span className="font-medium text-orange-600">{item.salePrice ?? "—"}</span>
                    {canViewCost && (
                        <span className="text-xs text-gray-400">Cost: {item.costPrice ?? "—"}</span>
                    )}
                </div>
            </td>

            <td className="px-4 py-3 text-sm text-gray-500 align-middle">
                {item.updatedAt ? new Date(item.updatedAt).toLocaleDateString() : "—"}
            </td>

            <td className="px-4 py-3 text-right align-middle">
                <RowActionMenu
                    item={item}
                    canEditPrice={canEditPrice}
                    onView={() => onView(item.productId)}
                    onEdit={() => onEdit(item.productId)}
                    onDelete={() => onDelete(item.productId)}
                    onService={() => onService(item.productId)}
                    onConsign={() => onConsign?.(item.productId)}
                    onQuickOrder={() => onQuickOrder?.(item.productId)}
                />
            </td>

        </tr >
    );
}