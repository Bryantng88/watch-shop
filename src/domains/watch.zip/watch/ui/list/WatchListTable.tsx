"use client";

import WatchListRow from "./WatchListRow";
import type { WatchRow } from "./types";

type Props = {
    items: WatchRow[];
    selectedIds: string[];
    canViewCost: boolean;
    canEditPrice: boolean;
    counts: any;
    activeQuickFilters: {
        hasContent: boolean;
        hasImages: boolean;
    };
    onQuickFilterClick: (key: "hasContent" | "hasImages") => void;
    onToggleOne: (productId: string, checked: boolean) => void;
    onToggleAll: (checked: boolean) => void;
    onView: (productId: string) => void;
    onEdit: (productId: string) => void;
    onDelete: (productId: string) => void;
    onService: (productId: string) => void;
};

export default function WatchListTable({
    items,
    selectedIds,
    canViewCost,
    canEditPrice,
    onToggleOne,
    onToggleAll,
}: Props) {
    const allChecked = items.length > 0 && items.every((x) => selectedIds.includes(x.productId));

    return (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                    <thead className="bg-slate-50 text-slate-600">
                        <tr>
                            <th className="px-4 py-3 text-left">
                                <input
                                    type="checkbox"
                                    checked={allChecked}
                                    onChange={(e) => onToggleAll(e.target.checked)}
                                />
                            </th>
                            <th className="px-4 py-3 text-left">Watch</th>
                            <th className="px-4 py-3 text-left">Post readiness</th>
                            <th className="px-4 py-3 text-left">Pricing</th>
                            <th className="px-4 py-3 text-left">Cập nhật</th>
                            <th className="px-4 py-3 text-right">Hành động</th>
                        </tr>
                    </thead>

                    <tbody>
                        {items.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="px-4 py-10 text-center text-slate-400">
                                    Không có dữ liệu
                                </td>
                            </tr>
                        ) : (
                            items.map((item) => (
                                <WatchListRow
                                    key={item.productId}
                                    item={item}
                                    checked={selectedIds.includes(item.productId)}
                                    onCheckedChange={(checked) => onToggleOne(item.productId, checked)}
                                    canViewCost={canViewCost}
                                    canEditPrice={canEditPrice}
                                />
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}