import { getAdminOrderList } from "../server";
import type { OrderSearchInput } from "../server/shared";

export async function listOrdersApplication(input: OrderSearchInput) {
  return getAdminOrderList(input);
}
