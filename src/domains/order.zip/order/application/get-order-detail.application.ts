import { getAdminOrderDetail } from "../server";

export async function getOrderDetailApplication(orderId: string) {
  return getAdminOrderDetail(orderId);
}
