import { getServiceCatalogOptions } from "../server";

export async function getOrderServiceCatalogApplication() {
  return getServiceCatalogOptions();
}
