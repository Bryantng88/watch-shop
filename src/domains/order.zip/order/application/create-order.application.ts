import { createOrderWithItems, createQuickOrderFromProduct } from "../server";
import type { CreateOrderInput, QuickOrderFromProductInput } from "../server/shared";

export async function createOrderApplication(input: CreateOrderInput) {
  return createOrderWithItems({
    ...input,
    source: input.source ?? "ADMIN",
    verificationStatus: input.verificationStatus ?? "VERIFIED",
    status: input.status ?? "DRAFT",
    quickFromProductId: input.quickFromProductId ?? null,
    quickFlowType: input.quickFlowType ?? "STANDARD",
  });
}

export async function createQuickOrderFromProductApplication(input: QuickOrderFromProductInput) {
  return createQuickOrderFromProduct(input);
}
