import { getOrderDraftForEdit } from "../server";

export async function getOrderDraftForEditApplication(orderId: string) {
  return getOrderDraftForEdit(orderId);
}
