import { WorkflowConditionStrategy } from "@prisma/client";
import { workflowActionHandlers } from "./workflow-action-registry";

type EvaluateContext = {
    actorUserId?: string | null;
    eventLog?: any;
};

function businessKey(input: { targetType: string; targetId: string }) {
    return `${input.targetType}:${input.targetId}`;
}

function isSameTargetType(a?: string | null, b?: string | null) {
    if (!a || !b) return true;
    return String(a).toUpperCase() === String(b).toUpperCase();
}

function groupEventsByBusinessTarget(events: any[]) {
    const map = new Map<string, any[]>();

    for (const event of events) {
        const key = businessKey({
            targetType: event.targetType,
            targetId: event.targetId,
        });

        const next = map.get(key) ?? [];
        next.push(event);
        map.set(key, next);
    }

    return map;
}

function evaluateBusinessTarget(input: {
    conditions: any[];
    events: any[];
    strategy: WorkflowConditionStrategy;
}) {
    const eventKeys = new Set(input.events.map((event) => event.eventKey));

    const relevantConditions = input.conditions.filter((condition) => {
        const targetType = input.events[0]?.targetType;
        return isSameTargetType(condition.targetType, targetType);
    });

    if (!relevantConditions.length) return false;

    if (input.strategy === WorkflowConditionStrategy.ANY) {
        return relevantConditions.some((condition) =>
            eventKeys.has(condition.eventKey),
        );
    }

    return relevantConditions.every((condition) =>
        eventKeys.has(condition.eventKey),
    );
}

function evaluateExecutionByBusinessTargets(input: {
    conditions: any[];
    events: any[];
    strategy: WorkflowConditionStrategy;
}) {
    const grouped = groupEventsByBusinessTarget(input.events);
    const results = Array.from(grouped.values()).map((events) =>
        evaluateBusinessTarget({
            conditions: input.conditions,
            events,
            strategy: input.strategy,
        }),
    );

    if (!results.length) return false;

    if (input.strategy === WorkflowConditionStrategy.ANY) {
        return results.some(Boolean);
    }

    return results.every(Boolean);
}

export async function evaluateWorkflowExecution(
    client: any,
    executionId: string,
    context: EvaluateContext = {},
) {
    const execution = await client.workflowExecution.findUnique({
        where: { id: executionId },
        include: {
            workflow: {
                include: {
                    conditions: {
                        orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
                    },
                    actions: {
                        orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
                    },
                },
            },
            events: true,
        },
    });

    if (!execution) return { ok: false, reason: "EXECUTION_NOT_FOUND" };

    const workflow = execution.workflow;
    if (!workflow || workflow.status !== "ACTIVE") {
        return { ok: false, reason: "WORKFLOW_INACTIVE" };
    }

    if (!execution.events?.length) {
        return { ok: false, reason: "NO_EVENTS" };
    }

    const matched = evaluateExecutionByBusinessTargets({
        conditions: workflow.conditions ?? [],
        events: execution.events ?? [],
        strategy: workflow.strategy,
    });

    if (!matched) {
        return { ok: true, matched: false };
    }

    let taskItem: any = null;

    if (execution.actionTargetType === "TASK_ITEM") {
        taskItem = await client.taskItem.findUnique({
            where: { id: execution.actionTargetId },
            include: {
                task: true,
                executions: true,
                checklists: true,
            } as any,
        });

        if (!taskItem) {
            return { ok: false, reason: "TASK_ITEM_NOT_FOUND" };
        }

        if (taskItem.isDone || String(taskItem.status) === "DONE") {
            await client.workflowExecution.update({
                where: { id: execution.id },
                data: {
                    status: "COMPLETED" as any,
                    completedAt: execution.completedAt ?? new Date(),
                    errorMessage: null,
                },
            });

            return { ok: true, matched: true, alreadyDone: true };
        }
    }

    for (const action of workflow.actions ?? []) {
        const handler = workflowActionHandlers[action.actionType];
        if (!handler) continue;

        await handler(client, {
            workflow,
            taskItem,
            execution,
            eventLog: context.eventLog,
            actorUserId: context.actorUserId ?? null,
        });
    }

    await client.workflowExecution.update({
        where: { id: execution.id },
        data: {
            status: "COMPLETED" as any,
            completedAt: new Date(),
            errorMessage: null,
        },
    });

    return { ok: true, matched: true };
}