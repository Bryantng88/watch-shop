import {
  WorkflowActionType,
  WorkflowConditionStrategy,
  WorkflowTemplateStatus,
} from "@prisma/client";
import { dbOrTx, type DB } from "@/server/db/client";
import { normalizeWorkflowEventKey } from "./workflow.registry";

export async function listWorkflowTemplatesRepo(
  db: DB,
  input?: { ownerType?: string | null; ownerId?: string | null; includeGlobal?: boolean },
) {
  const client = dbOrTx(db) as any;

  const ownerType = input?.ownerType ?? null;
  const ownerId = input?.ownerId ?? null;
  const includeGlobal = input?.includeGlobal !== false;

  return client.workflowTemplate.findMany({
    where: {
      status: { not: WorkflowTemplateStatus.ARCHIVED },
      OR: [
        ...(includeGlobal ? [{ ownerType: null, ownerId: null }] : []),
        ...(ownerType && ownerId ? [{ ownerType, ownerId }] : []),
      ],
    },
    include: {
      conditions: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] },
      actions: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] },
    },
    orderBy: [{ isSystem: "desc" }, { name: "asc" }],
  });
}

export async function createWorkflowTemplateRepo(
  db: DB,
  input: {
    name: string;
    description?: string | null;
    ownerType?: string | null;
    ownerId?: string | null;
    strategy?: WorkflowConditionStrategy;
    eventKeys: string[];
    actionTypes?: WorkflowActionType[];
  },
) {
  const client = dbOrTx(db) as any;
  const name = String(input.name || "").trim();
  if (!name) throw new Error("Missing workflow name");

  const eventKeys = Array.from(
    new Set(input.eventKeys.map(normalizeWorkflowEventKey).filter(Boolean)),
  );

  if (!eventKeys.length) throw new Error("Workflow cần ít nhất một condition");

  const actionTypes = input.actionTypes?.length
    ? input.actionTypes
    : [WorkflowActionType.COMPLETE_TASK_ITEM];

  return client.workflowTemplate.create({
    data: {
      name,
      description: input.description?.trim() || null,
      ownerType: input.ownerType || null,
      ownerId: input.ownerId || null,
      strategy: input.strategy ?? WorkflowConditionStrategy.ALL,
      conditions: {
        create: eventKeys.map((eventKey, index) => ({
          eventKey,
          sortOrder: index,
        })),
      },
      actions: {
        create: actionTypes.map((actionType, index) => ({
          actionType,
          sortOrder: index,
        })),
      },
    },
    include: {
      conditions: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] },
      actions: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] },
    },
  });
}

export async function setTagWorkflowRepo(
  db: DB,
  input: { tagId: string; workflowId?: string | null },
) {
  const client = dbOrTx(db) as any;
  const tagId = String(input.tagId || "").trim();
  if (!tagId) throw new Error("Missing tagId");

  return client.appTag.update({
    where: { id: tagId },
    data: {
      workflowId: input.workflowId || null,
    },
    include: {
      workflow: {
        include: {
          conditions: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] },
          actions: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] },
        },
      },
    },
  });
}
export async function getTaskItemWorkflowProgress(
  db: DB,
  taskItemIds: string[],
) {
  if (!taskItemIds.length) return new Map();

  const client = dbOrTx(db);

  const executions = await client.workflowExecution.findMany({
    where: {
      actionTargetType: "TASK_ITEM",
      actionTargetId: {
        in: taskItemIds,
      },
    },
    include: {
      workflow: {
        include: {
          conditions: {
            orderBy: {
              sortOrder: "asc",
            },
          },
        },
      },
      events: true,
    },
  });

  const map = new Map<string, any>();

  for (const execution of executions) {
    const received = new Set(
      execution.events.map((e) => e.eventKey),
    );

    const conditions = execution.workflow.conditions.map((c) => ({
      eventKey: c.eventKey,
      done: received.has(c.eventKey),
    }));

    map.set(execution.actionTargetId, {
      id: execution.id,
      status: execution.status,
      workflowId: execution.workflow.id,
      workflowName: execution.workflow.name,
      strategy: execution.workflow.strategy,
      total: conditions.length,
      completed: conditions.filter((x) => x.done).length,
      conditions,
    });
  }

  return map;
}