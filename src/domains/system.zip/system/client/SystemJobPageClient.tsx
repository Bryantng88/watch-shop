"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import AcquisitionSpecLogViewer from "@/domains/system/ui/jobs/AcquisitionSpecLogViewer";

type JobControl = {
    id: string;
    processorKey: string;
    label?: string | null;
    isEnabled: boolean;
    batchSize: number | null;
    pausedReason?: string | null;
    updatedAt?: string | null;
};

type JobRunLog = {
    id: string;
    processorKey: string;
    triggerSource?: string | null;
    status: string;
    processedCount?: number | null;
    errorCount?: number | null;
    startedAt?: string | null;
    finishedAt?: string | null;
    note?: string | null;
    createdAt?: string | null;
};

type JobStats = {
    processorCount: number;
    pendingSpecCount: number;
    failedSpecCount: number;
    latestRunStatus?: string | null;
    latestRunAt?: string | null;
};

type Props = {
    initialControls?: JobControl[];
    initialLogs?: JobRunLog[];
    initialStats?: JobStats | null;
};

function fmtDateTime(value?: string | null) {
    if (!value) return "-";
    try {
        return new Date(value).toLocaleString("vi-VN");
    } catch {
        return value;
    }
}

function runStatusTone(status?: string | null) {
    const value = String(status ?? "").toUpperCase();

    switch (value) {
        case "DONE":
        case "SUCCESS":
            return "border-emerald-200 bg-emerald-50 text-emerald-700";
        case "FAILED":
        case "ERROR":
            return "border-rose-200 bg-rose-50 text-rose-700";
        case "RUNNING":
            return "border-blue-200 bg-blue-50 text-blue-700";
        case "SKIPPED":
            return "border-amber-200 bg-amber-50 text-amber-700";
        default:
            return "border-slate-200 bg-slate-50 text-slate-700";
    }
}

function ProcessorCard({
    control,
    pendingCount,
    failedCount,
    busy,
    onRunNow,
    onRetryFailed,
    onToggleEnabled,
}: {
    control: JobControl;
    pendingCount: number;
    failedCount: number;
    busy: boolean;
    onRunNow: () => void;
    onRetryFailed: () => void;
    onToggleEnabled: () => void;
}) {
    const enabled = control.isEnabled;

    return (
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <div className="flex items-center gap-2">
                        <h3 className="text-lg font-semibold text-slate-950">
                            {control.label || "Acquisition AI Spec"}
                        </h3>
                        <span
                            className={`inline-flex rounded-full border px-2 py-0.5 text-xs font-medium ${enabled
                                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                : "border-slate-200 bg-slate-50 text-slate-600"
                                }`}
                        >
                            {enabled ? "Đang bật" : "Đã tắt"}
                        </span>
                    </div>

                    <div className="mt-1 text-sm text-slate-500">
                        {control.processorKey} • cập nhật {fmtDateTime(control.updatedAt)}
                    </div>
                </div>

                <div className="min-w-[120px]">
                    <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-slate-400">
                        Batch size
                    </label>
                    <input
                        disabled
                        value={control.batchSize ?? 3}
                        className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700"
                    />
                </div>
            </div>

            <div className="mt-5 grid grid-cols-3 gap-3">
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                    <div className="text-xs font-medium uppercase tracking-wide text-slate-400">
                        Pending
                    </div>
                    <div className="mt-2 text-2xl font-semibold text-slate-950">
                        {pendingCount}
                    </div>
                </div>

                <div className="rounded-2xl border border-rose-200 bg-rose-50 p-4">
                    <div className="text-xs font-medium uppercase tracking-wide text-rose-400">
                        Failed
                    </div>
                    <div className="mt-2 text-2xl font-semibold text-rose-700">
                        {failedCount}
                    </div>
                </div>

                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                    <div className="text-xs font-medium uppercase tracking-wide text-slate-400">
                        Batch
                    </div>
                    <div className="mt-2 text-2xl font-semibold text-slate-950">
                        {control.batchSize ?? 3}
                    </div>
                </div>
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-2">
                <button
                    type="button"
                    onClick={onRunNow}
                    disabled={busy}
                    className="rounded-xl bg-slate-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
                >
                    {busy ? "Đang chạy..." : "Run now"}
                </button>

                <button
                    type="button"
                    onClick={onRetryFailed}
                    disabled={busy || failedCount <= 0}
                    className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-2 text-sm font-medium text-amber-700 transition hover:bg-amber-100 disabled:cursor-not-allowed disabled:opacity-60"
                >
                    Retry failed
                </button>

                <button
                    type="button"
                    onClick={onToggleEnabled}
                    disabled={busy}
                    className={`rounded-xl border px-4 py-2 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-60 ${enabled
                        ? "border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100"
                        : "border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
                        }`}
                >
                    {enabled ? "Pause" : "Resume"}
                </button>
            </div>
        </div>
    );
}

function JobRunLogCard({
    log,
    selected,
    onViewLogs,
}: {
    log: JobRunLog;
    selected?: boolean;
    onViewLogs?: () => void;
}) {
    return (
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
                <div>
                    <div className="text-sm font-semibold text-slate-900">
                        {log.processorKey}
                    </div>
                    <div className="text-xs text-slate-500">
                        {log.triggerSource || "manual"}
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <span
                        className={`inline-flex rounded-full border px-2 py-0.5 text-xs font-medium ${runStatusTone(
                            log.status
                        )}`}
                    >
                        {log.status}
                    </span>

                    <button
                        type="button"
                        onClick={onViewLogs}
                        className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition ${selected
                            ? "border-slate-900 bg-slate-900 text-white"
                            : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                            }`}
                    >
                        Xem logs
                    </button>
                </div>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                    <div className="text-xs uppercase tracking-wide text-slate-400">
                        Processed
                    </div>
                    <div className="mt-1 text-slate-900">
                        {log.processedCount ?? 0}
                    </div>
                </div>

                <div>
                    <div className="text-xs uppercase tracking-wide text-slate-400">
                        Errors
                    </div>
                    <div className="mt-1 text-slate-900">
                        {log.errorCount ?? 0}
                    </div>
                </div>

                <div>
                    <div className="text-xs uppercase tracking-wide text-slate-400">
                        Started
                    </div>
                    <div className="mt-1 text-slate-900">
                        {fmtDateTime(log.startedAt)}
                    </div>
                </div>

                <div>
                    <div className="text-xs uppercase tracking-wide text-slate-400">
                        Finished
                    </div>
                    <div className="mt-1 text-slate-900">
                        {fmtDateTime(log.finishedAt)}
                    </div>
                </div>
            </div>

            {log.note ? (
                <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700">
                    {log.note}
                </div>
            ) : null}
        </div>
    );
}

export default function SystemJobPageClient({
    initialControls = [],
    initialLogs = [],
    initialStats = null,
}: Props) {
    const [controls, setControls] = useState<JobControl[]>(initialControls);
    const [logs, setLogs] = useState<JobRunLog[]>(initialLogs);
    const [stats, setStats] = useState<JobStats>({
        processorCount: initialStats?.processorCount ?? initialControls.length ?? 0,
        pendingSpecCount: initialStats?.pendingSpecCount ?? 0,
        failedSpecCount: initialStats?.failedSpecCount ?? 0,
        latestRunStatus: initialStats?.latestRunStatus ?? null,
        latestRunAt: initialStats?.latestRunAt ?? null,
    });

    const [busyKey, setBusyKey] = useState("");
    const [error, setError] = useState("");
    const [selectedRunId, setSelectedRunId] = useState("");
    const [, startTransition] = useTransition();

    const acquisitionControl = useMemo(
        () => controls.find((x) => x.processorKey === "acquisition_spec") || null,
        [controls]
    );

    const acquisitionRuns = useMemo(
        () => logs.filter((x) => x.processorKey === "acquisition_spec"),
        [logs]
    );

    useEffect(() => {
        if (!selectedRunId && acquisitionRuns.length > 0) {
            setSelectedRunId(acquisitionRuns[0].id);
        }
    }, [acquisitionRuns, selectedRunId]);

    async function loadAll(showBusy = false) {
        if (showBusy) setBusyKey("reload");

        try {
            setError("");

            const [controlsRes, logsRes, statsRes] = await Promise.all([
                fetch("/api/admin/system/jobs/system-job-controls", {
                    method: "GET",
                    cache: "no-store",
                }),
                fetch("/api/admin/system/jobs/system-job-logs", {
                    method: "GET",
                    cache: "no-store",
                }),
                fetch("/api/admin/system/jobs/system-job-stats", {
                    method: "GET",
                    cache: "no-store",
                }),
            ]);

            const [controlsData, logsData, statsData] = await Promise.all([
                controlsRes.json().catch(() => ({})),
                logsRes.json().catch(() => ({})),
                statsRes.json().catch(() => ({})),
            ]);

            if (!controlsRes.ok || !controlsData?.ok) {
                throw new Error(controlsData?.error || "Không thể tải job controls");
            }

            if (!logsRes.ok || !logsData?.ok) {
                throw new Error(logsData?.error || "Không thể tải job logs");
            }

            if (!statsRes.ok || !statsData?.ok) {
                throw new Error(statsData?.error || "Không thể tải job stats");
            }

            setControls(
                Array.isArray(controlsData.controls) ? controlsData.controls : []
            );

            setLogs(
                Array.isArray(logsData.items)
                    ? logsData.items
                    : Array.isArray(logsData.logs)
                        ? logsData.logs
                        : []
            );

            setStats(
                statsData.item || {
                    processorCount: 0,
                    pendingSpecCount: 0,
                    failedSpecCount: 0,
                    latestRunStatus: null,
                    latestRunAt: null,
                }
            );
        } catch (error: any) {
            setError(error?.message || "Không thể tải dữ liệu jobs");
        } finally {
            if (showBusy) setBusyKey("");
        }
    }

    async function runAcquisitionSpec(includeFailed = false) {
        setBusyKey(includeFailed ? "retry_failed_spec" : "run_acq_spec");
        setError("");

        try {
            const res = await fetch(
                "/api/admin/system/jobs/system-jobs/run-acquisition-spec",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        includeFailed,
                    }),
                }
            );

            const data = await res.json().catch(() => ({}));

            if (!res.ok || !data?.ok) {
                throw new Error(data?.error || "Không thể chạy acquisition spec");
            }

            await loadAll();
        } catch (error: any) {
            setError(error?.message || "Không thể chạy acquisition spec");
        } finally {
            setBusyKey("");
        }
    }

    async function runAllJobs() {
        setBusyKey("run_all_jobs");
        setError("");

        try {
            await runAcquisitionSpec(false);
        } finally {
            setBusyKey("");
        }
    }

    async function toggleProcessor(control: JobControl) {
        setBusyKey(`toggle_${control.processorKey}`);
        setError("");

        try {
            const res = await fetch(
                "/api/admin/system/jobs/system-job-controls/toggle",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        processorKey: control.processorKey,
                        isEnabled: !control.isEnabled,
                    }),
                }
            );

            const data = await res.json().catch(() => ({}));

            if (!res.ok || !data?.ok) {
                throw new Error(data?.error || "Không thể cập nhật processor");
            }

            await loadAll();
        } catch (error: any) {
            setError(error?.message || "Không thể cập nhật processor");
        } finally {
            setBusyKey("");
        }
    }

    useEffect(() => {
        if (
            initialControls.length === 0 &&
            initialLogs.length === 0 &&
            !initialStats
        ) {
            startTransition(() => {
                void loadAll();
            });
        }
    }, [initialControls.length, initialLogs.length, initialStats, startTransition]);

    return (
        <div className="space-y-6">
            <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div>
                        <h1 className="text-3xl font-semibold tracking-tight text-slate-950">
                            System Jobs
                        </h1>
                        <p className="mt-1 text-sm text-slate-500">
                            Quản lý processor chạy nền, backlog và lịch sử vận hành.
                        </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                        <button
                            type="button"
                            onClick={runAllJobs}
                            disabled={busyKey === "run_all_jobs"}
                            className="rounded-xl bg-slate-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
                        >
                            {busyKey === "run_all_jobs" ? "Đang chạy..." : "Run All Jobs Now"}
                        </button>

                        <button
                            type="button"
                            onClick={() => runAcquisitionSpec(false)}
                            disabled={busyKey === "run_acq_spec"}
                            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
                        >
                            {busyKey === "run_acq_spec" ? "Đang chạy..." : "Run Acquisition Spec"}
                        </button>

                        <button
                            type="button"
                            onClick={() => runAcquisitionSpec(true)}
                            disabled={busyKey === "retry_failed_spec"}
                            className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-2 text-sm font-medium text-amber-700 transition hover:bg-amber-100 disabled:cursor-not-allowed disabled:opacity-60"
                        >
                            {busyKey === "retry_failed_spec"
                                ? "Đang retry..."
                                : "Retry Failed Spec"}
                        </button>
                    </div>
                </div>
            </div>

            {error ? (
                <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
                    {error}
                </div>
            ) : null}

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
                <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div className="text-sm text-slate-500">Processors</div>
                    <div className="mt-2 text-4xl font-semibold tracking-tight text-slate-950">
                        {stats.processorCount}
                    </div>
                    <div className="mt-2 text-sm text-slate-500">
                        Enabled {controls.filter((x) => x.isEnabled).length} • Paused{" "}
                        {controls.filter((x) => !x.isEnabled).length}
                    </div>
                </div>

                <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div className="text-sm text-slate-500">Spec Pending</div>
                    <div className="mt-2 text-4xl font-semibold tracking-tight text-slate-950">
                        {stats.pendingSpecCount}
                    </div>
                    <div className="mt-2 text-sm text-slate-500">
                        Đang chờ run hoặc trigger sau post
                    </div>
                </div>

                <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div className="text-sm text-slate-500">Spec Failed</div>
                    <div className="mt-2 text-4xl font-semibold tracking-tight text-slate-950">
                        {stats.failedSpecCount}
                    </div>
                    <div className="mt-2 text-sm text-slate-500">
                        Nên retry hoặc kiểm tra input AI
                    </div>
                </div>

                <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div className="text-sm text-slate-500">Latest Run</div>
                    <div className="mt-2 text-4xl font-semibold tracking-tight text-slate-950">
                        {stats.latestRunStatus || "-"}
                    </div>
                    <div className="mt-2 text-sm text-slate-500">
                        {fmtDateTime(stats.latestRunAt)}
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
                <div className="space-y-6 xl:col-span-7">
                    <div>
                        <h2 className="text-lg font-semibold text-slate-950">
                            Processors
                        </h2>
                        <p className="mt-1 text-sm text-slate-500">
                            Bật / tắt từng processor và theo dõi queue hiện tại.
                        </p>
                    </div>

                    {acquisitionControl ? (
                        <ProcessorCard
                            control={acquisitionControl}
                            pendingCount={stats.pendingSpecCount}
                            failedCount={stats.failedSpecCount}
                            busy={
                                busyKey === "run_acq_spec" ||
                                busyKey === "retry_failed_spec" ||
                                busyKey === `toggle_${acquisitionControl.processorKey}`
                            }
                            onRunNow={() => runAcquisitionSpec(false)}
                            onRetryFailed={() => runAcquisitionSpec(true)}
                            onToggleEnabled={() => toggleProcessor(acquisitionControl)}
                        />
                    ) : (
                        <div className="rounded-3xl border border-dashed border-slate-200 bg-white p-6 text-sm text-slate-500">
                            Chưa có processor nào.
                        </div>
                    )}
                </div>

                <div className="space-y-6 xl:col-span-5">
                    <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
                        <div className="mb-4">
                            <h2 className="text-lg font-semibold text-slate-950">
                                Recent Runs
                            </h2>
                            <p className="mt-1 text-sm text-slate-500">
                                Nhật ký các lần run hoặc trigger thủ công.
                            </p>
                        </div>

                        {acquisitionRuns.length === 0 ? (
                            <div className="text-sm text-slate-500">
                                Chưa có run log nào.
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {acquisitionRuns.map((log) => (
                                    <JobRunLogCard
                                        key={log.id}
                                        log={log}
                                        selected={selectedRunId === log.id}
                                        onViewLogs={() => setSelectedRunId(log.id)}
                                    />
                                ))}
                            </div>
                        )}
                    </div>

                    {selectedRunId ? (
                        <AcquisitionSpecLogViewer jobId={selectedRunId} />
                    ) : (
                        <div className="rounded-3xl border border-dashed border-slate-200 bg-white p-6 text-sm text-slate-500">
                            Chọn một run để xem logs chi tiết.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}