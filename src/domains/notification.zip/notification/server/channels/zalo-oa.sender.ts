export async function sendZaloOaTextToGroup(input: {
    groupId: string;
    message: string;
}) {
    const endpoint = process.env.ZALO_OA_SEND_URL;
    const accessToken = process.env.ZALO_OA_ACCESS_TOKEN;

    if (!endpoint) throw new Error("Missing ZALO_OA_SEND_URL");
    if (!accessToken) throw new Error("Missing ZALO_OA_ACCESS_TOKEN");

    const response = await fetch(endpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            access_token: accessToken,
        },
        body: JSON.stringify({
            recipient: {
                group_id: input.groupId,
            },
            message: {
                text: input.message,
            },
        }),
    });

    const data = await response.json().catch(() => null);

    if (!response.ok || data?.error) {
        throw new Error(
            data?.message ||
            data?.error_description ||
            `Zalo OA failed ${response.status}`,
        );
    }

    return data;
}