import { Prisma, ProductStatus, ContentStatus, ProductType } from "@prisma/client";
import { DB, dbOrTx } from "@/server/db/client";
import { stringifyAcquisitionItemMeta } from "../content/acquisition-item-metadata";

function getDb(tx?: DB) {
    return dbOrTx(tx);
}

export async function createWatchDraftForAcquisitionItem(
    tx: DB,
    input: {
        acquisitionItemId: string;
        acquisitionId: string;
        vendorId: string;
        title: string;
        quantity?: number | null;
        unitCost?: number | null;
        imageKey?: string | null;
        imageUrl?: string | null;
    }
) {
    const db = getDb(tx);

    const product = await db.product.create({
        data: {
            type: ProductType.WATCH,
            title: input.title,
            vendorId: input.vendorId,
            status: ProductStatus.HOLD,
            contentStatus: ContentStatus.DRAFT,
            specStatus: "PENDING",
            sku: null,
            primaryImageUrl: input.imageUrl ?? null,
            storefrontImageKey: input.imageKey ?? null,
        },
        select: {
            id: true,
            primaryImageUrl: true,
            storefrontImageKey: true,
        },
    });

    const watch = await db.watch.create({
        data: {
            productId: product.id,
            acquisitionId: input.acquisitionId,
            gender: "MEN",
            siteChannel: "AFFORDABLE",
            stockState: "IN_STOCK",
            saleState: "OFF_SHELF",
            serviceState: "PENDING",
        },
        select: {
            id: true,
            productId: true,
        },
    });

    await db.watchPrice.upsert({
        where: { watchId: watch.id },
        create: {
            watchId: watch.id,
            costPrice: new Prisma.Decimal(Number(input.unitCost ?? 0)),
            landedCost: new Prisma.Decimal(Number(input.unitCost ?? 0)),
        },
        update: {
            costPrice: new Prisma.Decimal(Number(input.unitCost ?? 0)),
            landedCost: new Prisma.Decimal(Number(input.unitCost ?? 0)),
        },
    });

    await db.watchContent.upsert({
        where: { watchId: watch.id },
        create: {
            watchId: watch.id,
            bulletSpecs: [],
        },
        update: {},
    });

    if (input.imageKey) {
        await db.productImage.create({
            data: {
                id: crypto.randomUUID(),
                productId: product.id,
                fileKey: input.imageKey,
                role: "GALLERY",
                sortOrder: 0,
                isPrimary: true,
                isForAdmin: true,
                isForStorefront: true,
            },
        });
    }

    const variant = await db.productVariant.create({
        data: {
            productId: product.id,
            sku: null,
            stockQty: Number(input.quantity ?? 1),
            costPrice: new Prisma.Decimal(Number(input.unitCost ?? 0)),
            availabilityStatus: "HIDDEN",
        },
        select: { id: true },
    });

    await db.acquisitionItem.update({
        where: { id: input.acquisitionItemId },
        data: {
            productId: product.id,
            variantId: variant.id,
        },
    });

    return {
        productId: product.id,
        watchId: watch.id,
        variantId: variant.id,
    };
}