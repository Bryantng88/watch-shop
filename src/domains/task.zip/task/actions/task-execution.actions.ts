"use server";

import { revalidatePath } from "next/cache";
import { requirePermission } from "@/server/auth/requirePermission";
import { prisma } from "@/server/db/client";
import { linkTaskExecution, listTaskExecutions } from "../server/execution/task-execution.service";
import type { LinkTaskExecutionInput } from "../server/execution/task-execution.types";
import { TaskExecutionActionType, TaskExecutionTargetType } from "@prisma/client";
import { TASK_EXECUTION_INCLUDE } from "../server/core/task.repo.shared";
async function getTaskAuth() {
  return requirePermission("TASK_VIEW");
}

export async function listTaskExecutionsAction(taskId: string) {
  const auth = await getTaskAuth();
  const items = await listTaskExecutions(prisma, taskId, auth);
  return { ok: true, items };
}

export async function linkTaskExecutionAction(input: {
  taskId: string;
  taskItemId?: string | null;
  targetType: TaskExecutionTargetType;
  targetId: string;
  note?: string | null;
  metadataJson?: any;
}) {
  const auth = await requirePermission("TASK_VIEW");

  const taskId = String(input.taskId || "").trim();
  const targetId = String(input.targetId || "").trim();

  if (!taskId) throw new Error("Missing taskId");
  if (!targetId) throw new Error("Missing targetId");

  const execution = await prisma.taskExecution.create({
    data: {
      taskId,
      taskItemId: input.taskItemId || null,
      targetType: input.targetType,
      targetId,
      actionType: TaskExecutionActionType.LINKED,
      note: input.note || null,
      metadataJson: input.metadataJson ?? null,
      createdByUserId: auth?.user?.id ?? auth?.id ?? auth?.userId ?? null,
    } as any,
  });



  return { ok: true, execution };
}
export async function linkTaskExecutionsAction(input: {
  taskId: string;
  taskItemId?: string | null;
  targetType: TaskExecutionTargetType;
  targetIds: string[];
  note?: string | null;
  metadataJson?: any;
}) {
  const auth = await requirePermission("TASK_VIEW");

  const taskId = String(input.taskId || "").trim();
  const targetIds = Array.from(
    new Set(
      (input.targetIds ?? [])
        .map((id) => String(id || "").trim())
        .filter(Boolean),
    ),
  );

  if (!taskId) throw new Error("Missing taskId");
  if (!targetIds.length) throw new Error("Missing targetIds");

  const taskItemId = input.taskItemId || null;
  const createdByUserId = auth?.user?.id ?? auth?.id ?? auth?.userId ?? null;

  const existing = await prisma.taskExecution.findMany({
    where: {
      taskId,
      taskItemId,
      targetType: input.targetType,
      targetId: { in: targetIds },
      actionType: TaskExecutionActionType.LINKED,
    },
    select: { targetId: true },
  });

  const existingIds = new Set(existing.map((item) => item.targetId));
  const nextTargetIds = targetIds.filter((id) => !existingIds.has(id));

  if (!nextTargetIds.length) {
    return {
      ok: true,
      count: 0,
      skipped: targetIds.length,
      executions: [],
    };
  }

  const createdRows = await prisma.$transaction(
    nextTargetIds.map((targetId) =>
      prisma.taskExecution.create({
        data: {
          taskId,
          taskItemId,
          targetType: input.targetType,
          targetId,
          actionType: TaskExecutionActionType.LINKED,
          note: input.note || null,
          metadataJson: input.metadataJson ?? null,
          createdByUserId,
        } as any,
        select: { id: true },
      }),
    ),
  );

  const executions = await prisma.taskExecution.findMany({
    where: {
      id: { in: createdRows.map((row) => row.id) },
    },
    include: TASK_EXECUTION_INCLUDE,
  });

  return {
    ok: true,
    count: executions.length,
    skipped: targetIds.length - executions.length,
    executions,
  };
}