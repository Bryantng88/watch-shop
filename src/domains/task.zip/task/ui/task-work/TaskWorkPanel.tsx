"use client";

import { useEffect, useMemo, useState } from "react";
import { TaskPriority } from "@prisma/client";
import SubtaskManageModal from "../list/SubtaskManageModal";
import {
  BusinessEntityPreviewModal,
  useBusinessEntityPreview,
} from "@/domains/shared/ui/business/BusinessEntityPreview";
import TaskItemRow from "./TaskItemRow";
import TaskExecutionGroup from "./TaskExecutionGroup";
import { splitExecutions } from "./taskWorkPanel.helpers";

type UserOption = {
  id: string;
  name?: string | null;
  email?: string | null;
};

type TaskItemInput = {
  taskId: string;
  title: string;
  assignedToUserId?: string | null;
  priority?: TaskPriority | null;
  dueAt?: string | null;
};

type UpdateTaskItemInput = {
  itemId: string;
  title: string;
  assignedToUserId?: string | null;
  priority?: TaskPriority | null;
  dueAt?: string | null;
};

function tempId(prefix: string) {
  return `temp-${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function findUser(users: UserOption[], id?: string | null) {
  if (!id) return null;
  return users.find((x) => x.id === id) ?? null;
}

function isTempId(id?: string | null) {
  return String(id || "").startsWith("temp-");
}

function TaskItemCreateBar({
  task,
  users,
  pending,
  onSubmit,
}: {
  task: any;
  users: UserOption[];
  pending: boolean;
  onSubmit: (input: TaskItemInput) => Promise<void> | void;
}) {
  const [title, setTitle] = useState("");
  const [selectedUserId, setSelectedUserId] = useState("");
  const [priority, setPriority] = useState<TaskPriority>(TaskPriority.MEDIUM);
  const [dueAt, setDueAt] = useState("");

  async function submit() {
    const clean = title.trim();
    if (!clean || pending) return;

    await onSubmit({
      taskId: task.id,
      title: clean,
      assignedToUserId:
        selectedUserId || task.assignedToUserId || task.createdByUserId || null,
      priority,
      dueAt: dueAt || null,
    });

    setTitle("");
    setSelectedUserId("");
    setPriority(TaskPriority.MEDIUM);
    setDueAt("");
  }

  return (
    <div className="mb-3 grid gap-2 lg:grid-cols-[minmax(0,1fr)_180px_140px_150px_80px]">
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            e.stopPropagation();
            submit();
          }
        }}
        placeholder="Thêm task item..."
        className="h-10 rounded-2xl border border-slate-300 bg-white px-4 text-sm outline-none focus:border-slate-400"
      />

      <select
        value={selectedUserId}
        onChange={(e) => setSelectedUserId(e.target.value)}
        className="h-10 rounded-2xl border border-slate-300 bg-white px-3 text-sm outline-none focus:border-slate-400"
      >
        <option value="">Tự giao</option>
        {users.map((user) => (
          <option key={user.id} value={user.id}>
            {user.name || user.email}
          </option>
        ))}
      </select>

      <select
        value={priority}
        onChange={(e) => setPriority(e.target.value as TaskPriority)}
        className="h-10 rounded-2xl border border-slate-300 bg-white px-3 text-sm outline-none focus:border-slate-400"
      >
        <option value={TaskPriority.LOW}>Thấp</option>
        <option value={TaskPriority.MEDIUM}>Vừa</option>
        <option value={TaskPriority.HIGH}>Cao</option>
        <option value={TaskPriority.URGENT}>Gấp</option>
      </select>

      <input
        type="date"
        value={dueAt}
        onChange={(e) => setDueAt(e.target.value)}
        className="h-10 rounded-2xl border border-slate-300 bg-white px-3 text-sm outline-none focus:border-slate-400"
      />

      <button
        type="button"
        disabled={pending || !title.trim()}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          submit();
        }}
        className="h-10 rounded-2xl bg-slate-950 px-4 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-40"
      >
        Thêm
      </button>
    </div>
  );
}

export default function TaskWorkPanel({
  task,
  taskItems = [],
  executions = [],
  onAddTaskItem,
  onToggleTaskItem,
  onDeleteTaskItem,
  onUpdateTaskItem,
  onAddTaskItemChecklist,
  onToggleTaskItemChecklist,
  users = [],
  canAddTaskItem = true,
  canCancelTaskItem = true,
  onUpdateTaskItemChecklistTitle,
  onDeleteTaskItemChecklist,
  onTaskItemsChange,
}: {
  task: any;
  taskItems?: any[];
  executions?: any[];
  users?: UserOption[];
  canAddTaskItem?: boolean;
  canCancelTaskItem?: boolean;
  onAddTaskItem?: (input: TaskItemInput) => Promise<any> | any;
  onUpdateTaskItem?: (input: UpdateTaskItemInput) => Promise<void> | void;
  onToggleTaskItem?: (itemId: string, isDone: boolean) => Promise<void> | void;
  onDeleteTaskItem?: (itemId: string) => Promise<void> | void;
  onAddTaskItemChecklist?: (
    taskItemId: string,
    title: string,
  ) => Promise<any> | any;
  onToggleTaskItemChecklist?: (
    checklistId: string,
    isDone: boolean,
  ) => Promise<void> | void;
  onUpdateTaskItemChecklistTitle?: (
    checklistId: string,
    title: string,
  ) => Promise<void> | void;
  onDeleteTaskItemChecklist?: (checklistId: string) => Promise<void> | void;
  onTaskItemsChange?: (taskId: string, items: any[]) => void;
}) {
  const previewState = useBusinessEntityPreview();

  const [pending, setPending] = useState(false);
  const [localItems, setLocalItems] = useState<any[]>(taskItems ?? []);
  const [managingItem, setManagingItem] = useState<any | null>(null);
  const [expandedItemIds, setExpandedItemIds] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setLocalItems(taskItems ?? []);
  }, [taskItems]);

  function commitLocalItems(updater: (prev: any[]) => any[]) {
    setLocalItems((prev) => {
      const next = updater(prev);
      onTaskItemsChange?.(task.id, next);
      return next;
    });
  }

  const orphanExecutions = useMemo(
    () => splitExecutions(executions.filter((x) => !x.taskItemId)),
    [executions],
  );

  async function addTaskItem(input: TaskItemInput) {
    const id = tempId("task-item");
    const assignedToUser = findUser(users, input.assignedToUserId);

    const optimisticItem = {
      id,
      taskId: input.taskId,
      title: input.title,
      note: null,
      status: "TODO",
      isDone: false,
      priority: input.priority ?? TaskPriority.MEDIUM,
      dueAt: input.dueAt ?? null,
      assignedToUserId: input.assignedToUserId ?? null,
      assignedToUser,
      executions: [],
      checklists: [],
      _pending: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    commitLocalItems((prev) => [optimisticItem, ...prev]);

    try {
      setPending(true);

      const result = await onAddTaskItem?.(input);
      const created = result?.item ?? result?.taskItem ?? result?.data ?? null;

      if (!created?.id) {
        throw new Error("Server chưa trả task item đã tạo.");
      }

      commitLocalItems((prev) =>
        prev.map((x) =>
          x.id === id
            ? {
              ...optimisticItem,
              ...created,
              _pending: false,
            }
            : x,
        ),
      );
    } catch (error) {
      commitLocalItems((prev) => prev.filter((x) => x.id !== id));
      throw error;
    } finally {
      setPending(false);
    }
  }

  async function toggleItem(item: any) {
    if (item._pending || isTempId(item.id)) return;

    const nextDone = !Boolean(item.isDone || item.status === "DONE");
    const oldItem = item;

    commitLocalItems((prev) =>
      prev.map((x) =>
        x.id === item.id
          ? {
            ...x,
            isDone: nextDone,
            status: nextDone ? "DONE" : "TODO",
          }
          : x,
      ),
    );

    try {
      await onToggleTaskItem?.(item.id, nextDone);
    } catch (error) {
      commitLocalItems((prev) =>
        prev.map((x) => (x.id === item.id ? oldItem : x)),
      );
      throw error;
    }
  }

  async function deleteItem(item: any) {
    if (item._pending || isTempId(item.id)) return;

    commitLocalItems((prev) => prev.filter((x) => x.id !== item.id));

    if (managingItem?.id === item.id) {
      setManagingItem(null);
    }

    try {
      await onDeleteTaskItem?.(item.id);
    } catch (error) {
      commitLocalItems((prev) => [...prev, item]);
      throw error;
    }
  }

  async function updateItem(input: UpdateTaskItemInput) {
    let oldItem: any = null;

    commitLocalItems((prev) =>
      prev.map((item) => {
        if (item.id !== input.itemId) return item;

        oldItem = item;

        return {
          ...item,
          title: input.title,
          assignedToUserId: input.assignedToUserId ?? null,
          assignedToUser: findUser(users, input.assignedToUserId),
          priority: input.priority ?? item.priority,
          dueAt: input.dueAt ?? null,
        };
      }),
    );

    try {
      await onUpdateTaskItem?.(input);
    } catch (error) {
      if (oldItem) {
        commitLocalItems((prev) =>
          prev.map((item) => (item.id === input.itemId ? oldItem : item)),
        );
      }

      throw error;
    }
  }

  async function addChecklist(taskItemId: string, title: string) {
    if (isTempId(taskItemId)) return;

    const clean = title.trim();
    if (!clean) return;

    const tempChecklistId = tempId("checklist");

    const pendingChecklist = {
      id: tempChecklistId,
      taskItemId,
      title: clean,
      note: null,
      isDone: false,
      doneAt: null,
      _uiState: "creating",
    };

    commitLocalItems((prev) =>
      prev.map((item) =>
        item.id === taskItemId
          ? {
            ...item,
            status: "TODO",
            isDone: false,
            checklists: [...(item.checklists ?? []), pendingChecklist],
          }
          : item,
      ),
    );

    setExpandedItemIds((prev) => ({ ...prev, [taskItemId]: true }));

    try {
      const result = await onAddTaskItemChecklist?.(taskItemId, clean);
      const created = result?.checklist ?? result?.data ?? null;

      if (!created?.id) {
        throw new Error("Server chưa trả checklist đã tạo.");
      }

      commitLocalItems((prev) =>
        prev.map((item) =>
          item.id === taskItemId
            ? {
              ...item,
              status: "TODO",
              isDone: false,
              checklists: (item.checklists ?? []).map((row: any) =>
                row.id === tempChecklistId
                  ? {
                    ...created,
                    _uiState: null,
                  }
                  : row,
              ),
            }
            : item,
        ),
      );

      return result;
    } catch (error) {
      commitLocalItems((prev) =>
        prev.map((item) =>
          item.id === taskItemId
            ? {
              ...item,
              checklists: (item.checklists ?? []).filter(
                (row: any) => row.id !== tempChecklistId,
              ),
            }
            : item,
        ),
      );

      throw error;
    }
  }

  async function toggleChecklist(checklistId: string, isDone: boolean) {
    if (isTempId(checklistId)) return;

    let oldRow: any = null;

    commitLocalItems((prev) =>
      prev.map((item) => ({
        ...item,
        checklists: (item.checklists ?? []).map((row: any) => {
          if (row.id !== checklistId) return row;

          oldRow = row;

          return {
            ...row,
            isDone,
            doneAt: isDone ? new Date().toISOString() : null,
            _uiState: "updating",
          };
        }),
      })),
    );

    try {
      await onToggleTaskItemChecklist?.(checklistId, isDone);

      commitLocalItems((prev) =>
        prev.map((item) => ({
          ...item,
          checklists: (item.checklists ?? []).map((row: any) =>
            row.id === checklistId
              ? {
                ...row,
                _uiState: null,
              }
              : row,
          ),
        })),
      );
    } catch (error) {
      if (oldRow) {
        commitLocalItems((prev) =>
          prev.map((item) => ({
            ...item,
            checklists: (item.checklists ?? []).map((row: any) =>
              row.id === checklistId ? oldRow : row,
            ),
          })),
        );
      }

      throw error;
    }
  }

  async function updateChecklistTitle(checklistId: string, title: string) {
    if (isTempId(checklistId)) return;

    const clean = title.trim();
    if (!clean) return;

    let oldRow: any = null;

    commitLocalItems((prev) =>
      prev.map((item) => ({
        ...item,
        checklists: (item.checklists ?? []).map((row: any) => {
          if (row.id !== checklistId) return row;

          oldRow = row;

          return {
            ...row,
            title: clean,
            _uiState: "updating",
          };
        }),
      })),
    );

    try {
      await onUpdateTaskItemChecklistTitle?.(checklistId, clean);

      commitLocalItems((prev) =>
        prev.map((item) => ({
          ...item,
          checklists: (item.checklists ?? []).map((row: any) =>
            row.id === checklistId
              ? {
                ...row,
                _uiState: null,
              }
              : row,
          ),
        })),
      );
    } catch (error) {
      if (oldRow) {
        commitLocalItems((prev) =>
          prev.map((item) => ({
            ...item,
            checklists: (item.checklists ?? []).map((row: any) =>
              row.id === checklistId ? oldRow : row,
            ),
          })),
        );
      }

      throw error;
    }
  }

  async function deleteChecklist(checklistId: string) {
    if (isTempId(checklistId)) return;

    let deletedRow: any = null;
    let deletedTaskItemId: string | null = null;

    commitLocalItems((prev) =>
      prev.map((item) => ({
        ...item,
        checklists: (item.checklists ?? []).map((row: any) => {
          if (row.id !== checklistId) return row;

          deletedRow = row;
          deletedTaskItemId = item.id;

          return {
            ...row,
            _uiState: "deleting",
          };
        }),
      })),
    );

    try {
      await onDeleteTaskItemChecklist?.(checklistId);

      commitLocalItems((prev) =>
        prev.map((item) =>
          item.id === deletedTaskItemId
            ? {
              ...item,
              checklists: (item.checklists ?? []).filter(
                (row: any) => row.id !== checklistId,
              ),
            }
            : item,
        ),
      );
    } catch (error) {
      if (deletedRow && deletedTaskItemId) {
        commitLocalItems((prev) =>
          prev.map((item) =>
            item.id === deletedTaskItemId
              ? {
                ...item,
                checklists: (item.checklists ?? []).map((row: any) =>
                  row.id === checklistId
                    ? {
                      ...deletedRow,
                      _uiState: null,
                    }
                    : row,
                ),
              }
              : item,
          ),
        );
      }

      throw error;
    }
  }

  return (
    <section
      className="border-y border-l-4 border-slate-200 border-l-slate-400 bg-slate-100 px-4 py-4"
      onClick={(event) => event.stopPropagation()}
    >
      {canAddTaskItem ? (
        <TaskItemCreateBar
          task={task}
          users={users}
          pending={pending}
          onSubmit={addTaskItem}
        />
      ) : null}

      <div className="space-y-2">
        {localItems.map((item) => (
          <TaskItemRow
            key={item.id}
            item={item}
            canCancel={canCancelTaskItem}
            onManage={setManagingItem}
            onToggle={toggleItem}
            onDelete={deleteItem}
            onPreview={previewState.openPreview}
            expanded={Boolean(expandedItemIds[item.id])}
            onToggleExpand={(row) =>
              setExpandedItemIds((prev) => ({
                ...prev,
                [row.id]: !prev[row.id],
              }))
            }
            onAddTaskItemChecklist={addChecklist}
            onToggleTaskItemChecklist={toggleChecklist}
            onUpdateTaskItemChecklistTitle={updateChecklistTitle}
            onDeleteTaskItemChecklist={deleteChecklist}
          />
        ))}

        <TaskExecutionGroup
          serviceRequests={orphanExecutions.serviceRequests}
          technicalIssues={orphanExecutions.technicalIssues}
          otherExecutions={orphanExecutions.otherExecutions}
          onPreview={previewState.openPreview}
        />

        {!localItems.length &&
          !orphanExecutions.serviceRequests.length &&
          !orphanExecutions.technicalIssues.length &&
          !orphanExecutions.otherExecutions.length ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-4 py-4 text-sm text-slate-400">
            Chưa có task item hoặc nghiệp vụ nào.
          </div>
        ) : null}
      </div>

      <SubtaskManageModal
        open={Boolean(managingItem)}
        task={task}
        item={managingItem}
        users={users}
        canEdit={canAddTaskItem}
        onClose={() => setManagingItem(null)}
        onSave={updateItem}
        onLinked={(execution) => {
          if (execution?.taskItemId) {
            commitLocalItems((prev) =>
              prev.map((item) =>
                item.id === execution.taskItemId
                  ? {
                    ...item,
                    executions: [...(item.executions ?? []), execution],
                  }
                  : item,
              ),
            );
          }

          setManagingItem(null);
        }}
      />

      <BusinessEntityPreviewModal
        open={previewState.open}
        preview={previewState.preview}
        loading={previewState.loading}
        error={previewState.error}
        onClose={previewState.closePreview}
      />
    </section>
  );
}