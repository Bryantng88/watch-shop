"use client";

import { useState, useTransition } from "react";
import { Link2 } from "lucide-react";
import { useNotify } from "@/domains/shared/feedback/AppToastProvider";
import { linkTaskExecutionAction } from "../../actions/task-execution.actions";

const TARGET_OPTIONS = [
  { value: "WATCH", label: "Watch" },
  { value: "ORDER", label: "Order" },
  { value: "SHIPMENT", label: "Shipment" },
  { value: "PAYMENT", label: "Payment" },
  { value: "SERVICE_REQUEST", label: "Service Request" },
  { value: "TECHNICAL_ISSUE", label: "Technical Issue" },
  { value: "ACQUISITION", label: "Acquisition" },
  { value: "WORK_CASE", label: "Phiếu xử lý" },
] as const;

export default function TaskDomainActions({
  task,
  checklistItemId,
  onDone,
}: {
  task: any;
  checklistItemId?: string | null;
  onDone?: () => void;
}) {
  const notify = useNotify();
  const [isPending, startTransition] = useTransition();

  const [targetType, setTargetType] = useState<(typeof TARGET_OPTIONS)[number]["value"]>("ORDER");
  const [targetId, setTargetId] = useState("");
  const [note, setNote] = useState("");

  function submit() {
    const cleanTargetId = targetId.trim();

    if (!cleanTargetId) {
      notify.error("Vui lòng nhập ID / mã nghiệp vụ cần link");
      return;
    }

    startTransition(async () => {
      try {
        await linkTaskExecutionAction({
          taskId: task.id,
          checklistItemId: checklistItemId || null,
          targetType,
          targetId: cleanTargetId,
          note: note.trim() || null,
        });

        notify.success("Đã link nghiệp vụ");
        setTargetId("");
        setNote("");
        onDone?.();
      } catch (error: any) {
        notify.error(error?.message || "Không link được nghiệp vụ");
      }
    });
  }

  return (
    <div className="space-y-3">
      <div className="grid gap-2 md:grid-cols-[180px_minmax(0,1fr)]">
        <select
          value={targetType}
          onChange={(e) => setTargetType(e.target.value as any)}
          className="h-10 rounded-2xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-slate-400"
        >
          {TARGET_OPTIONS.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>

        <input
          value={targetId}
          onChange={(e) => setTargetId(e.target.value)}
          placeholder="Dán ID / mã / refNo nghiệp vụ..."
          className="h-10 rounded-2xl border border-slate-200 bg-white px-4 text-sm outline-none focus:border-slate-400"
        />
      </div>

      <input
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Ghi chú link nghiệp vụ..."
        className="h-10 w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm outline-none focus:border-slate-400"
      />

      <button
        type="button"
        disabled={isPending}
        onClick={submit}
        className="inline-flex h-10 items-center gap-2 rounded-2xl bg-slate-950 px-4 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
      >
        <Link2 className="h-4 w-4" />
        Link nghiệp vụ
      </button>
    </div>
  );
}