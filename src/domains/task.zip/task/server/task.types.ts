import type { TaskKind, TaskPriority, TaskSource, TaskStatus } from "@prisma/client";

export type TaskViewKey = "mine" | "assigned" | "delegated" | "all";

export type TaskListFilters = {
  view?: TaskViewKey;
  q?: string;
  status?: TaskStatus | "OPEN" | "ALL";
  priority?: TaskPriority | "ALL";
  kind?: TaskKind | "ALL";
  page?: number;
  pageSize?: number;
};

export type TaskDomainLinksInput = {
  watchId?: string | null;
  orderId?: string | null;
  shipmentId?: string | null;
  acquisitionId?: string | null;
  serviceRequestId?: string | null;
  technicalIssueId?: string | null;
  paymentId?: string | null;
};

export type CreateTaskInput = TaskDomainLinksInput & {
  title: string;
  description?: string | null;
  source?: TaskSource;
  kind?: TaskKind;
  priority?: TaskPriority;
  dueAt?: Date | string | null;
  assignedToUserId?: string | null;
};

export type UpdateTaskInput = TaskDomainLinksInput & {
  title?: string;
  description?: string | null;
  kind?: TaskKind;
  priority?: TaskPriority;
  dueAt?: Date | string | null;
  assignedToUserId?: string | null;
};

export type CompleteRelatedTasksInput = TaskDomainLinksInput & {
  kind: TaskKind;
  completedByUserId?: string | null;
};
