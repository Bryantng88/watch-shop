"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import {
  Plus,
  ArrowLeft,
  Wrench,
  ClipboardList,
  ImageIcon,
} from "lucide-react";

import {
  ServiceIssueManageModal,
  type IssueBoardCatalogs,
  type IssueItem,
} from "@/domains/service/ui/issue-board";
import type { ServiceRequestDetailViewModel } from "@/domains/service/ui/detail/types";

type IssueBoardPayload = {
  items: IssueItem[];
  counts: {
    pendingConfirm: number;
    ready: number;
    inProgress: number;
    done: number;
    readyToCloseSrCount?: number;
  };
  catalogs?: IssueBoardCatalogs;
};

function imgUrl(value?: string | null) {
  if (!value) return null;
  if (value.startsWith("http://") || value.startsWith("https://")) return value;
  if (value.startsWith("/")) return value;
  return `/api/media/${value}`;
}

export default function ServiceRequestDetailClient({
  detail,
  issueBoard,
}: {
  detail: ServiceRequestDetailViewModel;
  issueBoard: IssueBoardPayload;
}) {
  const router = useRouter();
  const [issueModalOpen, setIssueModalOpen] = React.useState(false);

  const sr = detail.serviceRequest;
  const image = imgUrl(sr.primaryImageUrlSnapshot);
  const issueCount = issueBoard.items?.length ?? 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => router.push("/admin/services")}
          className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50"
        >
          <ArrowLeft className="h-4 w-4" />
          Quay lại
        </button>

        <button
          type="button"
          onClick={() => setIssueModalOpen(true)}
          className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800"
        >
          <Plus className="h-4 w-4" />
          Tạo / quản lý issue
        </button>
      </div>

      <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex items-start gap-4">
          <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-2xl bg-slate-100">
            {image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={image}
                alt={sr.modelSnapshot ?? "Service item"}
                className="h-full w-full object-cover"
              />
            ) : (
              <ImageIcon className="h-6 w-6 text-slate-400" />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600">
                {sr.status}
              </span>

              <span className="rounded-full bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-700">
                {sr.priority || "NORMAL"}
              </span>

              {sr.refNo ? (
                <span className="text-xs text-slate-400">{sr.refNo}</span>
              ) : null}
            </div>

            <h1 className="mt-2 text-2xl font-bold text-slate-950">
              {sr.modelSnapshot || "Service Request"}
            </h1>

            <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-sm text-slate-500">
              <span>SKU: {sr.skuSnapshot || "-"}</span>
              <span>KTV: {sr.technicianNameSnap || sr.technician?.name || "-"}</span>
              <span>Vendor: {sr.vendorNameSnap || "-"}</span>
            </div>
          </div>
        </div>

        {sr.notes ? (
          <div className="mt-5 rounded-2xl border border-slate-100 bg-slate-50 p-4 text-sm text-slate-600">
            {sr.notes}
          </div>
        ) : null}
      </section>

      <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
          <div>
            <h2 className="font-semibold text-slate-950">Technical issues</h2>
            <p className="mt-1 text-sm text-slate-500">
              Tạo và xử lý các hạng mục kỹ thuật của phiếu này.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setIssueModalOpen(true)}
            className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800"
          >
            <Plus className="h-4 w-4" />
            Tạo issue
          </button>
        </div>

        {issueCount === 0 ? (
          <button
            type="button"
            onClick={() => setIssueModalOpen(true)}
            className="m-5 flex w-[calc(100%-2.5rem)] flex-col items-center justify-center rounded-3xl border border-dashed border-slate-200 bg-slate-50 px-6 py-10 text-center hover:bg-slate-100"
          >
            <Wrench className="h-8 w-8 text-slate-400" />
            <div className="mt-3 font-semibold text-slate-800">
              Chưa có issue kỹ thuật
            </div>
            <div className="mt-1 text-sm text-slate-500">
              Bấm để tạo issue đầu tiên cho phiếu service này.
            </div>
          </button>
        ) : (
          <div className="divide-y divide-slate-100">
            {issueBoard.items.map((item) => (
              <div key={item.id} className="flex items-center gap-3 px-5 py-4">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-50 text-blue-700">
                  <ClipboardList className="h-4 w-4" />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-slate-950">
                    {item.summary || item.area || "Technical issue"}
                  </div>
                  <div className="mt-0.5 text-xs text-slate-500">
                    {item.executionStatus} · {item.actionMode || "INTERNAL"}
                  </div>
                </div>

                <div className="text-sm font-semibold text-slate-600">
                  {item.actualCost ? `${Number(item.actualCost).toLocaleString("vi-VN")}đ` : "0đ"}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <ServiceIssueManageModal
        open={issueModalOpen}
        onClose={() => {
          setIssueModalOpen(false);
          router.refresh();
        }}
        currentServiceRequestId={sr.id}
        serviceRefNo={sr.refNo}
        items={issueBoard.items}
        counts={issueBoard.counts}
        catalogs={{
          ...(issueBoard.catalogs ?? {}),
          technicalDetailCatalogOptions:
            issueBoard.catalogs?.technicalDetailCatalogOptions ??
            (issueBoard as any).technicalDetailCatalogOptions ??
            [],
        }}
      />
    </div>
  );
}