"use client";

import * as React from "react";
import { CreditCard } from "lucide-react";
import { useRouter } from "next/navigation";
import PaymentWorkspace from "@/domains/payment/ui/PaymentWorkspace";
import { useNotify } from "@/domains/shared/feedback/AppToastProvider";

export default function ServicePaymentButton({
  serviceRequestId,
  refNo,
  title,
  totalCost,
}: {
  serviceRequestId: string;
  refNo?: string | null;
  title?: string | null;
  totalCost: number;
}) {
  const router = useRouter();
  const notify = useNotify();
  const [open, setOpen] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);

  async function postPayment(payload: any) {
    setSubmitting(true);
    try {
      const res = await fetch(`/api/admin/service-requests/${serviceRequestId}/payment`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json?.error || "Không thể xử lý payment service.");
      notify.success({ title: "Đã cập nhật payment service" });
      router.refresh();
    } catch (error: any) {
      notify.error({ title: "Payment service thất bại", message: error?.message || "Đã có lỗi xảy ra." });
      throw error;
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
      >
        <CreditCard className="h-4 w-4" />
        Payment service
      </button>

      <PaymentWorkspace
        open={open}
        submitting={submitting}
        onClose={() => setOpen(false)}
        onUpdated={() => router.refresh()}
        owner={{
          type: "SERVICE",
          id: serviceRequestId,
          code: refNo,
          title,
          direction: "OUT",
          totalAmount: totalCost,
          remainingAmount: null,
          listEndpoint: `/api/admin/service-requests/${serviceRequestId}/payment`,
        }}
        onCreatePayment={(payload) => postPayment(payload)}
        onCompletePayment={(payload) => postPayment({ ...payload, action: "complete" })}
        onCancelPayment={(payload) => postPayment({ ...payload, action: "cancel", cancelPaymentId: payload.paymentId })}
      />
    </>
  );
}
