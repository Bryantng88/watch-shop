import {
  completePaymentApplication,
  createPaymentApplication,
  getServicePaymentSummaryApplication,
  listServicePaymentsApplication,
  cancelPaymentApplication,
} from "@/domains/payment/application";

export function listServiceRequestPaymentsApplication(serviceRequestId: string) {
  return listServicePaymentsApplication(serviceRequestId);
}

export function getServiceRequestPaymentSummaryApplication(serviceRequestId: string) {
  return getServicePaymentSummaryApplication(serviceRequestId);
}

export function createServiceRequestPaymentApplication(input: {
  serviceRequestId: string;
  amount?: number | null;
  method?: string | null;
  purpose?: string | null;
  note?: string | null;
  markPaidNow?: boolean | null;
}) {
  return createPaymentApplication({
    ownerType: "SERVICE",
    ownerId: input.serviceRequestId,
    amount: input.amount,
    method: input.method,
    purpose: input.purpose ?? "MAINTENANCE_COST",
    note: input.note,
    markPaidNow: input.markPaidNow,
  });
}

export const completeServiceRequestPaymentApplication = completePaymentApplication;
export const cancelServiceRequestPaymentApplication = cancelPaymentApplication;
