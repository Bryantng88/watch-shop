import {
  assignVendorForServiceRequest,
  bulkAssignVendorAndCreateMaintenance,
  completeServiceRequest,
  createMaintenanceRecordForServiceRequest,
  createTechnicalChecksFromProducts,
  getAdminServiceRequestList,
  getMaintenancePanelByServiceRequest,
  getMaintenanceRecordsByServiceRequest,
  getServiceRequestDetailRepo,
  getTechnicianOptions,
  postServiceRequests,
} from "../server";
import type { ServiceRequestSearchInput } from "../shared";

export function getAdminServiceRequestListApplication(input: ServiceRequestSearchInput) {
  return getAdminServiceRequestList(input);
}
export function createTechnicalChecksFromProductsApplication(input: Parameters<typeof createTechnicalChecksFromProducts>[0]) {
  return createTechnicalChecksFromProducts(input);
}
export function postServiceRequestsApplication(ids: string[]) {
  return postServiceRequests(ids);
}
export function completeServiceRequestApplication(input: Parameters<typeof completeServiceRequest>[0]) {
  return completeServiceRequest(input);
}
export function bulkAssignVendorAndCreateMaintenanceApplication(input: Parameters<typeof bulkAssignVendorAndCreateMaintenance>[0]) {
  return bulkAssignVendorAndCreateMaintenance(input);
}
export function assignVendorForServiceRequestApplication(input: Parameters<typeof assignVendorForServiceRequest>[0]) {
  return assignVendorForServiceRequest(input);
}
export function getMaintenancePanelByServiceRequestApplication(serviceRequestId: string) {
  return getMaintenancePanelByServiceRequest(serviceRequestId);
}
export function getMaintenanceRecordsByServiceRequestApplication(serviceRequestId: string) {
  return getMaintenanceRecordsByServiceRequest(serviceRequestId);
}
export function createMaintenanceRecordForServiceRequestApplication(input: Parameters<typeof createMaintenanceRecordForServiceRequest>[0]) {
  return createMaintenanceRecordForServiceRequest(input);
}
export function getTechnicianOptionsApplication() {
  return getTechnicianOptions();
}
export function getServiceRequestDetailRepoApplication(serviceRequestId: string) {
  return getServiceRequestDetailRepo(serviceRequestId);
}
