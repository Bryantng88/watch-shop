"use client";

import { CreditCard, Truck, WalletMinimal, HandCoins, BanknoteArrowDown } from "lucide-react";
import { ReserveType } from "@prisma/client";
import { normalizeReserveType } from "@/domains/order/shared/order-reserve-type";
import { DomainSignalIcon } from "./DomainSignalIcon";

export function getOrderReserveTypeIconConfig(reserveType?: string | null) {
  const type = normalizeReserveType(reserveType);

  if (type === ReserveType.COD) {
    return {
      type,
      label: "COD",
      title: "COD - thu phần còn lại khi giao hàng",
      Icon: Truck,
    };
  }
  if (type === ReserveType.DEPOSIT) {
    return { type, label: "Deposit", title: "Deposit - có cọc", Icon: BanknoteArrowDown };
  }

  return { type, label: "Thanh toán full", title: "Thanh toán full", Icon: CreditCard };
}

export default function OrderReserveTypeIcon({ reserveType, withLabel = false, className }: any) {
  const config = getOrderReserveTypeIconConfig(reserveType);
  const Icon = config.Icon;

  return (
    <DomainSignalIcon
      title={config.title}
      label={config.label}
      withLabel={withLabel}
      icon={<Icon />}
      className={className}
    />
  );
}