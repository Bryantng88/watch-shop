"use client";

import { Building2, Globe2, Watch } from "lucide-react";
import { DomainSignalIcon } from "./DomainSignalIcon";

export function getOrderSourceIconConfig(source?: string | null) {
  const value = String(source ?? "").toUpperCase();

  if (value === "WEB") return { label: "Web", title: "Nguồn đơn: Web", Icon: Globe2 };
  if (value === "WATCH" || value === "WATCH_QUICK_ORDER") {
    return { label: "Tạo từ watch", title: "Nguồn đơn: Tạo từ watch", Icon: Watch };
  }

  return { label: "Tạo tay", title: "Nguồn đơn: Tạo tay", Icon: Building2 };
}

export default function OrderSourceIcon({ source, withLabel = false, className }: any) {
  const config = getOrderSourceIconConfig(source);
  const Icon = config.Icon;

  return (
    <DomainSignalIcon
      title={config.title}
      label={config.label}
      withLabel={withLabel}
      icon={<Icon />}
      className={className}
    />
  );
}